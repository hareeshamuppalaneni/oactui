### Getting Started
Softwares Need to run the React App: 
Install NodeJS 14 or above, better way to install NodeJs is via NVM (Node Version Manager) which provides CLI to change the node version easily.

Once you have Node !4 in local machine and backend running at 8080 port.

To Get Started please install node modules -> `npm install`
For Local changes run `npm run start:local`

If you face issues with node modules and or missing module in the file, Please delete the `package-lock.json` file and `node_modules` folder from the project directory. Then retry above command, `npm install` and once node modules are installed, please run local server `npm run start:local`

