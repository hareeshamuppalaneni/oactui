import React from 'react';
import { HeaderTab, LoginNavBar, SubHeaderText } from 'components';
import { SystemAdmin } from 'containers';
import { useLocation } from 'react-router-dom';

import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { fetchUserDetail } from 'slices';

export default () => {
  const location = useLocation();

  const dispatch = useDispatch();
  const userDetails = useSelector((state) => state.userDetail);

  useEffect(() => {
    dispatch(fetchUserDetail(location.state.userDetail.localUser));
  }, []);

  return (
    <div>
      <LoginNavBar userDetails={userDetails} />
      <SystemAdmin />
    </div>
  );
};
