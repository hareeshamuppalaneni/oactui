import React from "react";
import Home from "views/home/Home";
import { NavBar } from "components";

export default () => {
  return (
    <>
      <NavBar />
      <Home />
    </>
  );
};
