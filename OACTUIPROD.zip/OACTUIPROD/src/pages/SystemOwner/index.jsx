import React from "react";
import { HeaderTab, LoginNavBar, SubHeaderText } from "components";
import { SystemOwner } from "containers";
import { useLocation } from "react-router-dom";

import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { fetchSystemOwnerTableDetails, fetchUserDetail } from "slices";
import CONFIGS from "configs";
import Cookies from "js-cookie";
import _ from 'underscore';

export default () => {
  const location = useLocation();

  const dispatch = useDispatch();
  const userDetails = useSelector((state) => state.userDetail);

  useEffect(() => {
    const currentUser =
      Cookies.get("localUser") || location.state?.userDetail?.localUser;
    // If the Cookie Expiries the page should route back to login page

    if (_.isNull(Cookies.get('localUser')) || _.isUndefined(Cookies.get('localUser'))) {
      window.location.href = '/oact';
    } else {
      dispatch(fetchUserDetail(currentUser));
      dispatch(fetchSystemOwnerTableDetails(currentUser));
    }
  }, []);

  return (
    <div>
      <LoginNavBar />
      <SystemOwner />
    </div>
  );
};
