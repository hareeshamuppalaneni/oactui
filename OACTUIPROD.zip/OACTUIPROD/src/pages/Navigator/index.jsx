import React from 'react';
import { useEffect, useState } from 'react';
import CONFIGS from 'configs';
import Cookies from 'js-cookie';
import { useDispatch, useSelector } from 'react-redux';

import { fetchUserDetail, setLocalUser } from 'slices';
import { roleMapperToPage } from 'utils'
import { USER_ROLES } from '../../labels';

import { useNavigate, useSearchParams, useLocation } from 'react-router-dom';

export default () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const location = useLocation();
  let navigate = useNavigate();
  const dispatch = useDispatch();
  const userDetails = useSelector((state) => state.userDetail);

  useEffect(() => {
    const checkIfAnyUserExist = location.state.userDetail.localUser || userDetails.localUser;

    const currentRoles = userDetails.userRoles || location.state.userDetail.userRoles;
    // const currentRoute = USER_ROLES[roleMapperToPage(currentRoles[0])];
    const currentRoute = USER_ROLES[currentRoles[0]];
    if (currentRoles) {
      const userDetail = {
        ...userDetails,
        localUser: checkIfAnyUserExist || userDetails?.userInformation?.emailAddressText
      };
      navigate(CONFIGS.ROUTES[currentRoute], { state: { userDetail } });
    }
  }, [userDetails]);

  // useEffect(() => {});
  return <></>;
};
