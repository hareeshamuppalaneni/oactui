export const USER_ROLES = Object.freeze({
  SAM: 'SUB_ACCOUNT_MANAGER',
  SA: 'SYSTEM_ADMIN',
  AM: 'ACCOUNT_MANAGER',
  CC: 'CERTIFICATION_COORDINATOR',
  SO: 'SYSTEM_OWNER',
  SP: 'SYSTEM_POC'
});

export const USER_ROLES_LABELS = Object.freeze({
  SAM: 'Sub Account Manager',
  SA: 'System Admin',
  AM: 'Account Manager',
  CC: 'Certification Coordinator',
  SO: 'System Owner',
  SP: 'System POC'
});

/**

Mace.Christopher.S@dol.gov System owner
Wilson.Cory@dol.gov SubAccount manager
Sherfy.Elizabeth@dol.gov Account manager
Kumar.Manish@dol.gov System admin
Tookey.Robert.B@dol.gov SystemPOC
Barnett.Zachary@dol.gov	 CC 339
Goodhall.Yvonne@dol.gov	 System POC 338
Chin.Yenyin@dol.gov	 System POC 337
Max.Andrews@dol.gov
Young.Rita@dol.gov - Account Manager
Nielander.Debra@dol.gov
Andrews.max@dol.gov

Edit = <FontAwesomeIcon icon="fas fa-edit" />
Notify = <FontAwesomeIcon icon="far fa-envelope" />
Upload = <FontAwesomeIcon icon="fas fa-upload" />
Column Settings = <FontAwesomeIcon icon="fas fa-cog" />
Past Due = <FontAwesomeIcon icon="fas fa-exclamation-circle" />
3 days till due = <FontAwesomeIcon icon="fas fa-exclamation-triangle" />
7 days till due = <FontAwesomeIcon icon="fas fa-bell" />
Ellipsis = <FontAwesomeIcon icon="fas fa-ellipsis-h" />
Signature = <FontAwesomeIcon icon="fas fa-file-signature" />
XLS Document = <FontAwesomeIcon icon="fas fa-file-excel" />
Certificate PDF Document = <FontAwesomeIcon icon="fas fa-file-pdf" />


 */
