import React, { useRef, useEffect } from 'react';
import {
  solid,
  regular,
  brands,
  icon,
} from "@fortawesome/fontawesome-svg-core/import.macro";
import { useDispatch, useSelector } from 'react-redux';
import {
  Modal, ModalToggleButton, ModalHeading,
  ModalFooter, ButtonGroup, ModalRef, Alert, GridContainer,
  Table, DatePicker,
  Grid,
  Header,
  Title,
  FormGroup,
  Label,
  FileInput,
  ModalOpenLink,
  Button
} from '@trussworks/react-uswds';
import { FILES } from "assests";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faDownload } from "@fortawesome/free-solid-svg-icons";
import { TextInput, PrimaryButton } from 'components';
import { IMAGES } from 'assets';
import { Container, Row, Col } from 'react-bootstrap';

import Dropzone from "react-dropzone";

const newHead = [
  { name: "Application Name" },
  { name: "System Owner" },
  { name: "Certification Coordinator" },
  { name: "Account Manager" },
  { name: "Sub Account Manager" },
  { name: "Documents" }
];

import '@trussworks/react-uswds/lib/uswds.css'
import '@trussworks/react-uswds/lib/index.css'


const gridStyles = {
  borderRadius: '0px',
  background: '#F0F0F0',
  height: ' 123px',
  padding: '20px',
};

const modalStyles = {
  height: '993px',
  width: '1340px',
  left: '274px',
  top: '53px',
  borderRadius: '0px',
};

const divStyling = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
};

const alertStyling = {
  padding: '20px'
};

const footerStyling = {
  padding: '20px',
  border: `1px solid #AEB0B5`,
  background: '#F0f0f0'
}

import './CreateReviewCycle.css'


import { fetchApplicationList, setCycleName, setStartDate, setEndDate, setFileReferences } from 'slices'
import { uploadFile, uploadFilesToCreateCycle, createCycleReview } from 'services';
import { useState } from 'react';
import { Button as MainButtonModal } from 'react-bootstrap';
import { CERTIFICATE_COORDINATOR_TEXTS } from 'labels';

export default ({ modalForwardRef }) => {

  const [files, setFiles] = useState([]);
  const [checkFilesUpload, setFilesUplaod] = useState([]);

  const dispatch = useDispatch();

  const createCycleState = useSelector((state) => state.createCycle);
  const { cycleName, applications, startDate, endDate, cycleStateId } = createCycleState;

  const applicationOptions = applications.options;

  console.log("createCycleState => ", createCycleState)

  useEffect(() => {
    dispatch(fetchApplicationList());
  }, []);

  const modalRef = useRef(null);
  /**

   */

  const uploadFile = async (event, index) => {
    event.preventDefault();
    // console.log("File => ", event.target);
    let files = event.target.files;
    console.log("files => ", files);
    let reader = new FileReader();
    let file;
    let tempFiles = [];
    for (let i = 0; i < files.length; i++) {
      (function (file) {
        var reader = new FileReader();
        reader.onload = (file) => {
          tempFiles[i] = reader.result;
        }
        reader.readAsDataURL(file)
      })(files[i]);
    }

    try {
      const response = await uploadFilesToCreateCycle(files[0]);
      const newFilesList = [...checkFilesUpload];
      newFilesList[index] = { success: true, fileName: files[0].name };
      setFilesUplaod(newFilesList);
      dispatch(setFileReferences({ index, reference: response }))
    } catch(error) {
      const newFilesList = [...checkFilesUpload];
      newFilesList[index] = { error: true, fileName: files[0].name };
      setFilesUplaod(newFilesList);
    }  
    
  };

  const renderFileInputComponent = (fileObject, index) => {
    const airaLabel = `You have selected the file: ${fileObject?.fileName}`

    if(fileObject?.success) {
      return (
        <div className="usa-file-input">
                <div className="usa-file-input__target">
                  <div className="usa-file-input__preview-heading">Selected file
                    <span className="usa-file-input__choose">Change file</span>
                  </div><div className="usa-file-input__instructions display-none" aria-hidden="true">
                    <span className="usa-file-input__drag-text">Drag file here or </span>
                    <span className="usa-file-input__choose">choose from folder</span>
                  </div>
                  <div className="usa-file-input__preview" aria-hidden="true">
                    <img id="img_userdataimg_template__2exlsx-1666201229" 
                    src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" 
                    alt="" className="usa-file-input__preview-image usa-file-input__preview-image--excel" />
                    {fileObject?.fileName}
                    <div>
                    </div>
                  </div>
                  <div className="usa-file-input__box"></div>
                  <input id="file-input-single" className="usa-file-input__input" type="file" name="file-input-single" aria-live="polite" 
                  aria-label={airaLabel} data-default-aria-label="No file selected" 
                  onChange={(event) => uploadFile(event, index)} />
                </div>
              </div>
      )
    }

    else if(fileObject?.error) {
      return (
        <div className="usa-form-group usa-form-group--error">
        <span className="usa-error-message" id="file-input-error-alert">File Not Suppoted or Have some errors </span>
        <div className="usa-file-input"><div className="usa-file-input__target">
          <div className="usa-file-input__instructions" aria-hidden="true">
            <span className="usa-file-input__drag-text">Drag file here or </span>
            <span className="usa-file-input__choose">choose from folder</span>
          </div><div className="usa-file-input__box">
          </div>
          <input id="file-input-error" className="usa-file-input__input"
            type="file" name="file-input-error" aria-describedby="file-input-error-hint"
            aria-live="polite" aria-label="No file selected" data-default-aria-label="No file selected" />
        </div>
        </div>
      </div>
      )
    } 
    else {
      return (
        <div data-testid="file-input" className="usa-file-input"><div data-testid="file-input-droptarget" className="usa-file-input__target">
        <div data-testid="file-input-instructions" className="usa-file-input__instructions" aria-hidden="true">
          <span className="usa-file-input__drag-text">Drag file here or </span><span className="usa-file-input__choose">choose from folder</span>
        </div><div data-testid="file-input-box" className="usa-file-input__box">
        </div>
        <input type="file" data-testid="file-input-input" name="file-input-single" id="file-input-single" className="usa-file-input__input"
          onChange={(event) => uploadFile(event, index)}
        />
      </div>
      </div>
      )
    }

  }




  const createCycleBag = (applicationsList) => {

    const cycleBag = [];
    const isoFormatStartDate = new Date(startDate);
    const isoFormatEndDate = new Date(endDate);
    const formattedStartDate = isoFormatStartDate.toISOString();
    const formattedEndDate = isoFormatEndDate.toISOString();

    applicationsList.forEach((eachApplication) => {
      const { application, accessControlHierarchyPocId, fileRefernceId } = eachApplication;
      cycleBag.push({
        "cycleDueDate": formattedEndDate,
        "cycleHirerchyId": application.accessControlHierarchyId, // application.accessControlHierarchyId
        "cycleHirerchyPocId": accessControlHierarchyPocId, // accessControlHierarchyPocId
        "cycleName": cycleName,
        "cycleStartDate": formattedStartDate,
        "cycleStateId": cycleStateId,
        fileRefernceId
      })
    });
    return cycleBag;
  }

  const submitCycleReview = async (applications) => {
    const tempBag = createCycleBag(applications);

    const request = {
      "auditData": {
        "lastModifiedUserId": 123,
        "lockControlNumber": 0
      },
      "cycleDataBag": tempBag
    };

    const response = await createCycleReview(request);
    console.log("Submitted => ", response)

  };

  const onClickSubmit = (event, applicationData) => {
    submitCycleReview(applicationData);
  }

  return (
    <>
      <ModalOpenLink modalRef={modalRef}>
        <MainButtonModal
          variant="success"
        >
          <span>
            <FontAwesomeIcon icon={regular("circle-play")} style={{ paddingRight: '10px' }} />
            {CERTIFICATE_COORDINATOR_TEXTS.CREATE_CYCLE}
          </span>
        </MainButtonModal>
      </ModalOpenLink>
      <Modal
        isLarge
        ref={modalRef}
        // forceAction
        aria-labelledby="modal-2-heading"
        aria-describedby="modal-2-description"
        id="example-modal-2"
      // className='theme-modal-lg-content-max-width'
      >
        <ModalHeading id="modal-2-heading">
          Create Review Cycle
        </ModalHeading>
        <div style={gridStyles}>
          <Grid row>
            <Grid col={5}>
              Cycle Name:
              <TextInput
                style={{ marginTop: '.5rem' }}
                onChange={(event) => {
                  dispatch(setCycleName(event.target.value));
                }}
                value={cycleName}
              />
            </Grid>
            <Grid col={3} className="start-date-container">
              {"Start Date:"}
              <DatePicker
                onChange={(event) => dispatch(setStartDate(event))}
                defaultValue={'2022-10-06'}
              />
            </Grid>
            <Grid col={3}>
              {"Due Date:"}
              <DatePicker
                onChange={(event) => dispatch(setEndDate(event))}
                defaultValue={'2022-11-12'}
              />
            </Grid>
          </Grid>
        </div>
        <div className='alert-container' style={alertStyling}>
          <Title>
            Applications
          </Title>
          <Alert type="info" heading="Download Template" headingLevel="h4">
            For Proper injection, data should be properply formatted using OSHA template. Don't have a template?
            <span style={{
              paddingLeft: '10px'
            }}>
              <a
                href={FILES.USER_DATA_EXCEL_FILE}
                download="UserdataTemplate.xlsx"
              >
                <FontAwesomeIcon icon={faDownload} />
                &nbsp;
                <span>Download Template</span>
              </a>
            </span>
            <div>
              Note: At present system is accepting properply formatted .xls files only. Use Above template in case you do not have formatted data.
            </div>

          </Alert>

          <Table bordered={false} style={{ margin: "1.5em 0px ", width: 'max-content' }} >
            <thead>
              <tr>
                {newHead.map((eachHead, index) => {
                  return <th key={index}>{eachHead.name}</th>;
                })}
              </tr>
            </thead>
            <tbody>
              {renderApplicationData()}
            </tbody>
          </Table>

        </div>


        <ModalFooter style={footerStyling}>


          <ButtonGroup>
            <ModalToggleButton modalRef={modalRef}
              closer
              unstyled
            >
              <Button
                onClick={(event) => {
                  // event.preventDefault();
                  submitCycleReview(applicationOptions);

                }}>

                Create Cycle
              </Button>

            </ModalToggleButton>
            <ModalToggleButton
              modalRef={modalRef}
              closer
              unstyled
              className="padding-105 text-center">
              Cancel
            </ModalToggleButton>

          </ButtonGroup>
        </ModalFooter>
      </Modal>
    </>
  )
}