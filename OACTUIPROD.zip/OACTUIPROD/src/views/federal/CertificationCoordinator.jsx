import { Button } from "@trussworks/react-uswds";
import { Table } from "../../components";
import { IMAGES } from 'assets';
import { Container, Row, Col } from 'react-bootstrap';
import { Button, GridContainer, Grid } from '@trussworks/react-uswds';



const CertificationCoordinator = () => {
  return (
    <div className="App usa-banner__inner">
      {/* <div className="page-title">
        <h2>OSHA Account Certification Tool</h2>
      </div> */}
      <div>
        <h3 className="file-upload-h3">Certification Coordinator</h3>
        <div className="container">
          <div className="row">
            <div className="col col-lg-2">
              {/* <Button style={{ backgroundColor: "#5BB775", fontSize: "14px" }}>
                Create Review Cycle
              </Button> */}
            </div>
            <div style={{ padding: "5px" }}>
              <Table />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CertificationCoordinator;
