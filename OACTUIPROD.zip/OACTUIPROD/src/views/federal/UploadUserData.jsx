import React, { Component } from "react";
import Dropzone from "react-dropzone";
import "@trussworks/react-uswds/lib/uswds.css";
import "@fontsource/merriweather";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faDownload } from "@fortawesome/free-solid-svg-icons";
import Alert from "react-bootstrap/Alert";
import { Button } from "@trussworks/react-uswds";

import { getFiles, uploadFile } from "services";
import { FILES } from "assets";

import "./federal.css";

export default class UploadUserData extends Component {
  constructor(props) {
    super(props);
    this.upload = this.upload.bind(this);
    this.onDrop = this.onDrop.bind(this);

    this.state = {
      selectedFiles: undefined,
      currentFile: undefined,
      progress: 0,
      message: "",
      fileInfos: [],
      successmessage: "",
      failuremessage: "",
      system: "",
      application: "",
      reviewCycle: "",
    };
  }

  upload() {
    let currentFile = this.state.selectedFiles[0];
    const { system, application, reviewCycle } = this.state;
    this.setState({
      progress: 0,
      currentFile: currentFile,
    });

    UploadService.upload(
      {
        system,
        application,
        reviewCycle,
        file: currentFile,
      },
      (event) => {
        this.setState({
          progress: Math.round((100 * event.loaded) / event.total),
        });
      }
    )
      .then((response) => {
        this.setState({
          successmessage: "Your submission was successful",
        });
        return getFiles;
      })
      .then((files) => {
        this.setState({
          fileInfos: files.data,
        });
      })
      .catch(() => {
        this.setState({
          progress: 0,
          successmessage: "Your submission was successful",
          // failuremessage: 'Your file submission is failed. Please contact Administrator!!',
          currentFile: undefined,
          variant: "danger",
        });
      });

    this.setState({
      selectedFiles: undefined,
    });
  }

  onDrop(files) {
    let fileValidationMessages = [];
    this.setState({
      message: null,
      successmessage: null,
      failuremessage: null,
    });
    if (files.length > 0) {
      this.setState({ selectedFiles: files });
      let uploadedFile = files[0];
      if (
        uploadedFile.type !=
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      ) {
        fileValidationMessages.push(
          "Please select Accepted format file to upload the data!!"
        );
      }
      if (fileValidationMessages.length > 0) {
        this.setState({ message: fileValidationMessages });
        this.setState({
          selectedFiles: undefined,
        });
      } else {
        this.setState({ message: null });
      }
    }
  }

  handleChange = (e) => {
    this.setState({
      ...this.state,
      [e.target.name]: e.target.value,
    });
  };

  render() {
    const {
      selectedFiles,
      currentFile,
      progress,
      message,
      successmessage,
      failuremessage,
    } = this.state;

    return (
      <div className="App usa-banner__inner">
        {/* <div className="page-title">
          <h2>OSHA Account Certification Tool</h2>
        </div> */}
        <div>
          <h3 className="file-upload-h3">Upload Application User Data</h3>
          <div style={{ padding: "5px" }}>
            <h5>Step 1: Prepare Data Export for Ingestion</h5>
            <span>
              In Order for the specific application user data to be processed
              correctly, it needs to be formatted in a specific format. Please
              user the following template to ensure the data is properly
              formatted for ingestion:
            </span>
            <div>
              <a
                href={FILES.USER_DATA_EXCEL_FILE}
                download="UserdataTemplate.xlsx"
              >
                <button
                  className="btn btn-light"
                  style={{ margin: "0 0 10px 10px" }}
                >
                  <FontAwesomeIcon icon={faDownload} />
                  &nbsp;
                  <span>Download Template</span>
                </button>
              </a>
            </div>
          </div>
          <div style={{ padding: "5px" }}>
            <h5>Step 2: Select System and Application</h5>
            <div className="d-flex">
              <div className="p-2">
                <select onChange={this.handleChange}>
                  <option>Review Cycle</option>
                </select>
              </div>
              <div className="p-2">
                <select onChange={this.handleChange}>
                  <option>System</option>
                </select>
              </div>
              <div className="p-2">
                <select onChange={this.handleChange}>
                  <option>Application</option>
                </select>
              </div>
            </div>
          </div>
          <div style={{ padding: "5px" }}>
            <h5>Step 3: Locate and Select Your File(s)</h5>
            <div>
              <span>Accepted formats of the include ...</span>
            </div>
            <div>
              {currentFile && (
                <div className="progress mb-3">
                  <div
                    className="progress-bar progress-bar-info progress-bar-striped"
                    role="progressbar"
                    aria-valuenow={progress}
                    aria-valuemin="0"
                    aria-valuemax="100"
                    style={{ width: progress + "%" }}
                  >
                    {progress}%
                  </div>
                </div>
              )}

              <Dropzone onDrop={this.onDrop} multiple={false}>
                {({ getRootProps, getInputProps }) => (
                  <section>
                    <div {...getRootProps({ className: "dropzone" })}>
                      <input {...getInputProps()} />
                      {selectedFiles && selectedFiles[0].name ? (
                        <div className="selected-file">
                          {selectedFiles && selectedFiles[0].name}
                        </div>
                      ) : (
                        "Drag and drop file here, or click to select file"
                      )}
                    </div>
                  </section>
                )}
              </Dropzone>

              {message && (
                <Alert key={"danger"} variant={"danger"}>
                  {message}
                </Alert>
              )}

              {/* {fileInfos.length > 0 && (
                                <div className="card">
                                    <div className="card-header">List of Files</div>
                                    <ul className="list-group list-group-flush">
                                        {fileInfos.map((file, index) => (
                                            <li className="list-group-item" key={index}>
                                                <a href={file.url}>{file.name}</a>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )} */}
            </div>
          </div>
          <div>
            <h5>Step 4: Upload Your File</h5>
            <div>
              <span>
                Click on Upload button to start uploading files from Step 2
              </span>
            </div>
            <aside className="selected-file-wrapper">
              <Button
                type="primary"
                className="file-upload-button"
                disabled={!selectedFiles}
                onClick={this.upload}
              >
                Upload into O-ACT
              </Button>
              {/* <button
                                className="btn btn-success"
                                disabled={!selectedFiles}
                                onClick={this.upload}
                            >
                                Upload
                            </button> */}
            </aside>
            {successmessage && (
              <Alert key={"warning"} variant={"warning"}>
                THE LATEST FILE UPLOADED WILL OVERWRITE EXISTING DATA SET
              </Alert>
            )}
            {successmessage && (
              <Alert key={"success"} variant={"success"}>
                {successmessage}
              </Alert>
            )}
            {failuremessage && (
              <Alert key={"danger"} variant={"danger"}>
                {failuremessage}
              </Alert>
            )}
          </div>
        </div>
      </div>
    );
  }
}
