export const flattenObject = (obj) => {
  const flattened = {};

  Object.keys(obj).forEach((key) => {
    const value = obj[key];

    if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
      Object.assign(flattened, flattenObject(value));
    } else {
      flattened[key] = value;
    }
  });

  return flattened;
};

const mapper = {
  'Application Name': 'applicationName',
  'First Name': 'firstName',
  'Last Name': 'lastName',
  Office: 'officeName',
  'Account Status': 'accountStatus',
  'User Type': 'userType',
  'Last Login Date': 'lastLoginDate',
  'Review Result': 'reviewResults',
  'User Email Address': 'userEmailAddress',
  'Account Creation Date': 'accountCreationDate',
  Comments: 'comments'
};

export const filterAccountManager = (tableDetails, cols) => {

  const flatObj = flattenObject(tableDetails);
  
  const arrangedValues = {};
  arrangedValues['Action'] = null;
  cols.forEach((eachCol) => {
    arrangedValues[mapper[eachCol]] = flatObj[mapper[eachCol]]
    // arrangedValues.push(flatObj[mapper[eachCol]]);
  });
  // console.log('Response in UTILS arrangedValues', arrangedValues);
  return arrangedValues;
};

export const parseAccountManagerTable = (tableDetails) => {
  return tableDetails.map((eachRow) => {
    const flatObj = flattenObject((eachRow));
    // flatObj.stateName = 'With System Owner'
    return {...flatObj };
  });
  
};

const getDisplayedSelectedRows = () => {

}

function printPageDisplayedRows(event) {
  var rowCount = event.api.getDisplayedRowCount();
  var lastGridIndex = rowCount - 1;
  var currentPage = event.api.paginationGetCurrentPage();
  var pageSize = event.api.paginationGetPageSize();
  var startPageIndex = currentPage * pageSize;
  var endPageIndex = (currentPage + 1) * pageSize - 1;

  if (endPageIndex > lastGridIndex) {
    endPageIndex = lastGridIndex;
  }

  const currentPageRows = []
  for (var i = startPageIndex; i <= endPageIndex; i++) {
    var rowNode = event.api.getDisplayedRowAtIndex(i);
    currentPageRows.push(rowNode.data);
  }

  console.log("const currentPageRows = []", currentPageRows)
}
