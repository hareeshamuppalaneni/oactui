export const createTableDataForApplications = (selectedData) => {
  const filterData = [];
  selectedData.forEach((eachData, index) => {
    const currentData = eachData.hierarchyPOCBag[0];
    filterData[index] = [];
    filterData[index][0] = { name: eachData.name };
    filterData[index][1] = { name: currentData.systemOwner };
    filterData[index][2] = { name: currentData.certCoOrdinator };
    filterData[index][3] = { name: currentData.accountManager };
    filterData[index][4] = { name: currentData.subaccountManager };
  });
  return filterData;
};

export const checkForAllRequiredFields = (creatCycleData) => {
  const { agency, cycleName, startDate, endDate, systems, subSystems, applications } =
    creatCycleData;

  if (
    agency.selected.length > 0 &&
    cycleName.length > 0 &&
    startDate.length > 0 &&
    endDate.length > 0 &&
    systems.selected.length > 0 &&
    subSystems.selected.length > 0 &&
    applications.selected.length > 0
  ) {
    console.log('Came Here');
    return false;
  } else {
    return true;
  }
};

export const createCycleBag = (createCycleState) => {
  const applicationsList = createCycleState.applications.options;
  const { startDate, endDate, cycleName, cycleStateId } = createCycleState;
  const cycleBag = [];
  const isoFormatStartDate = new Date(startDate);
  const isoFormatEndDate = new Date(endDate);
  const formattedStartDate = isoFormatStartDate.toISOString();
  const formattedEndDate = isoFormatEndDate.toISOString();

  applicationsList.forEach((eachApplication) => {
    const { application, accessControlHierarchyPocId, fileRefernceId } = eachApplication;
    cycleBag.push({
      cycleDueDate: formattedEndDate,
      cycleHirerchyId: application.accessControlHierarchyId, // application.accessControlHierarchyId
      cycleHirerchyPocId: accessControlHierarchyPocId, // accessControlHierarchyPocId
      cycleName: cycleName,
      cycleStartDate: formattedStartDate,
      cycleStateId: cycleStateId,
      fileRefernceId
    });
  });
  return cycleBag;
};
