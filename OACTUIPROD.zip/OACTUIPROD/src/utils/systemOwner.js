const flattenObject = (obj) => {
  const flattened = {};

  Object.keys(obj).forEach((key) => {
    const value = obj[key];

    if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
      Object.assign(flattened, flattenObject(value));
    } else {
      flattened[key] = value;
    }
  });

  return flattened;
};

const mapper = {
  System: 'systemName',
  Application: 'applicationName',
  'Account Manager': 'accountManager',
  'Days till Due': 'daysTillDueDate',
  'Current Task': 'descriptionText',
  'Certification Coordinator': 'certCoOrdinator',
  'Start Date': 'cycleStartDate',
  'Due Date': 'dueDate'
};

export const filterSystemOwner = (tableDetails, cols) => {
  const flatObj = flattenObject(tableDetails);
  // console.log('Response in UTILS flatObj', flatObj);
  const arrangedValues = {};
  arrangedValues['Action'] = null;
  arrangedValues['Documents (ADD)'] = null;
  cols.forEach((eachCol) => {
    arrangedValues[mapper[eachCol]] = flatObj[mapper[eachCol]];
    // arrangedValues.push(flatObj[mapper[eachCol]]);
  });
  // console.log('Response in UTILS arrangedValues', arrangedValues);
  return arrangedValues;
};

export const parseSystemOwnerTable = (tableDetails) => {
  return tableDetails.map((eachRow) => {
    const flatObj = flattenObject((eachRow));
    // flatObj.stateName = 'With System Owner'
    // Add Space between Account Manager
    flatObj.accountManager = flatObj.accountManager.split(',').join(',  ')
    return {...flatObj };
  });
  
};
