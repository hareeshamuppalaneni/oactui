import React from 'react';

import './SubHeaderText.css';

export default ({ text = '' }) => {
  return (
    // <div className="App usa-banner__inner">
      <h3 className="sub-header-text-container">{text}</h3>
    // </div>
  );
};
