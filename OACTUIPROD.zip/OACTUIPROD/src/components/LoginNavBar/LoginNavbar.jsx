import React from 'react';
import { LoginMenuBar } from 'components';

export default function LoginNavbar() {
  return (
    <>
      <div>
        <div>
          <div className="department-tag">
            {/* <div className='usa-banner__inner'> */}
            <span className="department-logo">
                    <img src="https://www.dol.gov/themes/opa_theme/img/Agency_DOL_Logo_dark.svg" alt="U.S. Department of Labor"/>
              <p>U.S. DEPARTMENT OF LABOR</p>
            </span>
            {/* </div> */}
          </div>
        </div>
        <LoginMenuBar />
      </div>
    </>
  );
}
