import React, { useState, useEffect } from 'react';
import { ExtendedNav, Logo, MegaMenu } from '@trussworks/react-uswds';
import { NavMenuButton } from '@trussworks/react-uswds';
import { Header } from '@trussworks/react-uswds';
import { Search } from '@trussworks/react-uswds';
import { useSelector, useDispatch } from 'react-redux';
import { fetchUserDetail } from 'slices';
import CONFIGS from 'configs';
import { USER_ROLES_LABELS, USER_ROLES } from '../../labels';
import { roleMapperToPage } from 'utils';
import { IMAGES } from 'assets';
import { Container, Row, Col } from 'react-bootstrap';

const NavBarTextColorStyles = {
  color: '#ffffff'
};

import './LoginNavbar.css'

export default function LoginMenuBar() {
  const userDetailsStore = useSelector((state) => state.userDetail);
  const { userInformation, userRoles } = userDetailsStore;

  const {
    HOME,
    FEDERAL,
    FILE_UPLOAD,
    SUB_ACCOUNT_MANAGER,
    SYSTEM_ADMIN,
    CERTIFICATION_COORDINATOR,
    ACCOUNT_MANAGER,
    SYSTEM_OWNER,
    SYSTEM_POC
  } = CONFIGS.ROUTES;

  const dispatch = useDispatch();
  const [expanded, setExpanded] = useState(false);
  const [navBarMenuItems, setNavBarMenuItems] = useState(userRoles);

  /**
   * Temporray being called here, until we figure out the rotuing for React
   */
  // const loginUserDetails = () => {
  //   dispatch(fetchUserDetail());
  // };

  useEffect(() => {}, [userRoles]);

  const onClick = () => setExpanded((prvExpanded) => !prvExpanded);

  const signOutElement = [
    <a href="#linkOne" key="one">
      <span>
        {userInformation.firstName} {userInformation.lastName}
      </span>
    </a>,
    <a href="/oact" key="two">
      <span>Sign Out</span>
    </a>
  ];

  const [isOpen, setIsOpen] = useState([false, false]);
  const menuItems = [];
  const RenderNavBarItems = () => {
    // console.log('Came Here');

    const filteredUserRoles = new Set([...userRoles]);
    const customFilterSet = new Set();
    console.log('filteredUserRoles =>', filteredUserRoles);
    Array.from(filteredUserRoles).map((eachRole, index) => {
      const mapperRole = roleMapperToPage(eachRole);
      customFilterSet.add(mapperRole);
    });

    return Array.from(customFilterSet).map((eachRole, index) => {
      return (
        <a href={CONFIGS.ROUTES[USER_ROLES[roleMapperToPage(eachRole)]]} key={index}>
          <span style={{color: 'white'}}>{USER_ROLES_LABELS[roleMapperToPage(eachRole)]}</span>
        </a>
      );
    });

  };

  return (
    <>
      <div className="navMenu" >
        {/*<div className={`usa-overlay ${expanded ? 'is-visible' : ''}`}></div>*/}
        {/*<div className={`usa-overlay ${expanded ? 'is-visible' : ''}`}></div>*/}
        <Header extended={true} >
          <div className="usa-navbar" style={{ margin: `auto 3%`, width: `95%` }}>
            <NavMenuButton onClick={onClick} label="Menu" style={{ margin: `auto 1.5rem`, width: `95%` }}/>
          </div>

          <h1 className="search-tagline">Occupational Safety and Health Administration</h1>

    	  <ExtendedNav
            className="custom-navBar"
            primaryItems={RenderNavBarItems()}
            secondaryItems={signOutElement}
            mobileExpanded={expanded}
            onToggleMobileNav={onClick}
          ></ExtendedNav>
        </Header>
      </div>
    </>
  );
}
