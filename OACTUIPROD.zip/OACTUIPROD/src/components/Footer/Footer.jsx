import React, { useState } from 'react';
import { Footer } from '@trussworks/react-uswds';
import { FooterNav } from '@trussworks/react-uswds';
import { Logo } from '@trussworks/react-uswds';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro' // <-- import styles to be used
import { faFacebookF } from '@fortawesome/free-brands-svg-icons'
import { faTwitter } from '@fortawesome/free-brands-svg-icons';
import { faInstagram } from '@fortawesome/free-brands-svg-icons';
import { faYoutube } from '@fortawesome/free-brands-svg-icons';
import { PrimaryNav } from '@trussworks/react-uswds'
import { faLinkedin } from '@fortawesome/free-brands-svg-icons';

import { IMAGES } from 'assets';

import './footer.css';

export default function FooterMenu() {
  const footerMenuItems = [
    <a href="#" target='_blank' className='footer-link-option' key="one">
      <span>Site Map</span>
    </a>,
    <a href="#linkTwo" className='footer-link-saperator' key="two">
      <span>|</span>
    </a>,
    <a href="" target='_blank' className='footer-link-option' key="two">
      <span>Important Website Notice</span>
    </a>,
    <a href="#linkFour" className='footer-link-saperator' key="two">
      <span>|</span>
    </a>,
    <a href="#" target='_blank' className='footer-link-option' key="three">
      <span>Privacy &amp; security Statment</span>
    </a>,
  ]

  const [
    isOpen,
    setIsOpen
  ] = useState([false])

  return (
    <>
      <Footer
        size="big"
        primary={
          <div className="grid-container">
            <div className="grid-row grid-gap">
              <div className="tablet:grid-col-12">
                <FooterNav
                  size="big"
                  links={[
                    [
                      <Logo
                        size="big"
                        image={
                          <img
                            className="usa-footer__logo-img"
                            alt="img alt text"
                            src={IMAGES.DOL_LOGO}
                          />
                        }
                      />,
                      <div>

                        <span className='tag-line-footer'>Occupational Safety &amp; Health Administration</span> <br /> <br />
                        <span className='tag-line-footer-secondary'>An agency within the U.S. Department of Labor</span> <br /> <br />
                        <span className='tag-line-footer-secondary'>200 Constitution Ave NW</span> <br />
                        <span className='tag-line-footer-secondary'>Washington, DC 20210</span> <br />


                        <span className='tag-line-footer'></span>
                      </div>,
                      <div>
                        <a tel="8003216742" className='number-link'>(800) 321-6742 (OSHA)</a> <br />
                        <a href="#" className='number-link'> TTY</a>
                      </div>,
                      <a href="https://www.osha.gov" title="https://www.osha.gov" target='_blank'>www.osha.gov</a>
                    ],
                    [
                      <span className='footer-list-header'>FEDERAL GOVERNMENT</span>,
                      <a href="https://www.whitehouse.gov/" title="White House" target='_blank' className='footer-menu'>White House</a>,
                      <a href="https://www.dol.gov/coronavirus" title="Coronavirus Resources" target='_blank' className='footer-menu'>Coronavirus Resources</a>,
                      <a href="https://www.dol.gov/general/disasterrecovery" title="Disaster Recovery Assistance" target='_blank' className='footer-menu'>Disaster Recovery Assistance</a>,
                      <a href="https://www.disasterassistance.gov/" title="DisasterAssistance.gov" target='_blank' className='footer-menu'>DisasterAssistance.gov</a>,
                      <a href="https://www.usa.gov/" title="USA.gov" target='_blank' className='footer-menu'>USA.gov</a>,
                      <a href="https://www.dol.gov/agencies/oasam/centers-offices/civil-rights-center/cummings-antidiscrimination-act-2020" title="Notification of EEO Violations" target='_blank' className='footer-menu'>Notification of EEO Violations</a>,
                      <a href="https://www.dol.gov/agencies/oasam/centers-offices/civil-rights-center/resports/notification-and-federal-employee-antidiscrimination-retaliation-act-of-2002" title="No Fear Act Data" target='_blank' className='footer-menu'>No Fear Act Data</a>,
                      <a href="https://osc.gov/" title="U.S. Office of Special Counsel" target='_blank' className='footer-menu'>U.S. Office of Special Counsel</a>,
                    ],
                    [
                      <span className='footer-list-header'>OCCUPATIONAL SAFTEY & HEALTH</span>,
                      <a href="https://www.osha.gov/faq" title="Frequently Asked Questions" target='_blank' className='footer-menu'>Frequently Asked Questions</a>,
                      <a href="https://www.osha.gov/a-z" title="A-Z index" target='_blank' className='footer-menu'>A-Z index</a>,
                      <a href="https://www.osha.gov/foia" title="Freedom of Information Act - OSHA" target='_blank' className='footer-menu'>Freedom of Information Act - OSHA</a>,
                      <a href="https://www.osha.gov/quicktakes/" title="Read the OSHA Newsleetter" target='_blank' className='footer-menu'>Read the OSHA Newsleetter</a>,
                      <a href="https://www.osha.gov/quicktakes/#subscribe" title="Subscribe to the OSHA Newsletter" target='_blank' className='footer-menu'>Subscribe to the OSHA Newsletter</a>,
                      <a href="https://www.osha.gov/publications" title="OSHA Publications" target='_blank' className='footer-menu'>OSHA Publications</a>,
                      <a href="https://www.oig.dol.gov/" title="Office inspector General" target='_blank' className='footer-menu'>Office inspector General</a>,
                    ],
                    [
                      <span className='footer-list-header'>ABOUT THIS SITE</span>,
                      <a href="https://www.dol.gov/general/foia" title="Freedom of information Act - DOL" target='_blank' className='footer-menu'>Freedom of information Act - DOL</a>,
                      <a href="https://www.dol.gov/general/disclaim" title="Disclaimers" target='_blank' className='footer-menu'>Disclaimers</a>,
                      <a href="https://www.dol.gov/general/aboutdol/file-formats" title="Plug-ins Used on DOL.gov" target='_blank' className='footer-menu'>Plug-ins Used on DOL.gov</a>,
                      <a href="https://www.dol.gov/general/aboutdol/accessibility" title="Accessibility Statement" target='_blank' className='footer-menu'>Accessibility Statement</a>,
                    ],
                  ]}
                />
              </div>
            </div>
          </div>
        }
        secondary={<>
          <div className="usa-footer__primary-container grid-row">
            <div className="mobile-lg:grid-col-6 footer-menu-div">
              <div className='social-link-div'>
                <a href='#' className='footer-menu'>Connect With DOL</a>
              </div>
              <div className='social-link-div social-link-menu'>
                <a href='#' className='social-media-icons'>
                  <FontAwesomeIcon  className='social-media-icon' icon={faFacebookF} /></a>
              </div>
              <div className='social-link-div social-link-menu'>
                <a href='#' className='social-media-icons'>
                  <FontAwesomeIcon className='social-media-icon' icon={faTwitter} />
                </a>
              </div>
              <div className='social-link-div social-link-menu'>
                <a href='#' target='_blank' className='social-media-icons'>
                  <FontAwesomeIcon  className='social-media-icon' icon={faInstagram} />
                </a>
              </div>
              <div className='social-link-div social-link-menu'>
                <a href='#' target='_blank' className='social-media-icons'>
                  <FontAwesomeIcon className='social-media-icon' icon={faLinkedin} />
                </a>
              </div>
              <div className='social-link-div social-link-menu'>
                <a href='#' target='_blank' className='social-media-icons'>
                  <FontAwesomeIcon   className='social-media-icon' icon={faYoutube} />
                </a>
              </div>
            </div>
            <div className="tablet:grid-col-6">
              <PrimaryNav items={footerMenuItems} onToggleMobileNav={''} />
            </div>
          </div>
        </>}
      />
    </>
  );
}
