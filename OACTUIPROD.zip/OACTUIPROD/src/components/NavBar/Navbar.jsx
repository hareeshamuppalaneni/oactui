import React from 'react';
import { MenuBar } from 'components';

export default function Navbar() {
  return (
    <>
      <div className='.grid-container'>
        <div className='department-tag'>
          {/*<div className='usa-banner__inner'>*/}
            <span className="department-logo">
                    <img src="https://www.dol.gov/themes/opa_theme/img/Agency_DOL_Logo_dark.svg" alt="U.S. Department of Labor"/>
              <p>U.S. DEPARTMENT OF LABOR</p>{/*these are for next page after login ONLY*/}
            </span>
          {/*</div>*/}
        </div>
        <MenuBar />
      </div>
    </>
  );
}
