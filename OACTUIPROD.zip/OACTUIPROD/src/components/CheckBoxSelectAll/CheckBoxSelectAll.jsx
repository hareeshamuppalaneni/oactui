import React, { useEffect, useState } from 'react';

export default (params) => {
  const [checked, setChecked] = useState(false);
  const onCheckClicked = () => {
    console.log('onCheckboxClick()');

    var rowCount = params.api.getDisplayedRowCount();
    var lastGridIndex = rowCount - 1;
    var currentPage = params.api.paginationGetCurrentPage();
    var pageSize = params.api.paginationGetPageSize();
    var startPageIndex = currentPage * pageSize;
    var endPageIndex = (currentPage + 1) * pageSize - 1;

    if (endPageIndex > lastGridIndex) {
      endPageIndex = lastGridIndex;
    }

    params.api.selectAll = !params.api.selectAll;

    for (var i = startPageIndex; i <= endPageIndex; i++) {
      var rowNode = params.api.getDisplayedRowAtIndex(i);
      rowNode.setSelected(params.api.selectAll);
    }
  };

  useEffect(() => {
    console.log(`Init HeaderComponent`);

    // params = headerParams;

    var rowCount = params.api.getDisplayedRowCount();
    var lastGridIndex = rowCount - 1;
    var currentPage = params.api.paginationGetCurrentPage();
    var pageSize = params.api.paginationGetPageSize();
    var startPageIndex = currentPage * pageSize;
    var endPageIndex = (currentPage + 1) * pageSize - 1;

    if (endPageIndex > lastGridIndex) {
      endPageIndex = lastGridIndex;
    }

    //Count selected rows
    var cptSelected = 0;
    for (var i = startPageIndex; i <= endPageIndex; i++) {
      var rowNode = params.api.getDisplayedRowAtIndex(i);
      cptSelected += rowNode.selected ? 1 : 0;
    }

    //Check the checkbox if all the rows are selected
    var cptRows = endPageIndex + 1 - startPageIndex;
    params.api.selectAll = cptSelected && cptRows <= cptSelected;
  });

  const CheckBoxChecked = () => {
    return (
      <div
        className="ag-header-cell ag-header-cell-sortable ag-focus-managed"
        role="columnheader"
        tabindex="-1"
        aria-colindex="1"
        col-id="0"
        aria-sort="none"
        aria-description="Press Space to toggle all rows selection (checked) Press ENTER to sort."
        style={{ left: '0px', width: '40px' }}
      >
        <div className="ag-header-cell-resize" role="presentation"></div>
        <div
          role="presentation"
          className="ag-labeled ag-label-align-right ag-checkbox ag-input-field ag-header-select-all"
          aria-hidden="true"
        >
          <div
            className="ag-input-field-label ag-label ag-hidden ag-checkbox-label"
            role="presentation"
          ></div>
          <div
            className="ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper ag-checked"
            role="presentation"
          >
            <input
              className="ag-input-field-input ag-checkbox-input"
              type="checkbox"
              id="ag-173-input"
              aria-label="Press Space to toggle all rows selection (checked)"
              tabindex="-1"
              onChange={onCheckClicked}
              onClick={() => setChecked(!checked)}
            />
            {/* <input
              className="ag-input-field-input ag-checkbox-input"
              type="checkbox"
              id="ag-1846-input"
              aria-label="Press Space to toggle all rows selection (unchecked)"
              tabindex="-1"
              onChange={onCheckClicked}
              checked={true}
            /> */}
          </div>
        </div>
        <div className="ag-header-cell-comp-wrapper" role="presentation">
          <div className="ag-cell-label-container" role="presentation">
            <div className="ag-header-cell-label" role="presentation">
              <span className="ag-header-cell-text"></span>
              <span
                className="ag-header-icon ag-header-label-icon ag-filter-icon ag-hidden"
                aria-hidden="true"
              >
                <span
                  className="ag-icon ag-icon-filter"
                  unselectable="on"
                  role="presentation"
                ></span>
              </span>
              <span className="ag-sort-indicator-container">
                <span
                  className="ag-sort-indicator-icon ag-sort-order ag-hidden"
                  aria-hidden="true"
                ></span>
                <span
                  className="ag-sort-indicator-icon ag-sort-ascending-icon ag-hidden"
                  aria-hidden="true"
                >
                  <span
                    className="ag-icon ag-icon-asc"
                    unselectable="on"
                    role="presentation"
                  ></span>
                </span>
                <span
                  className="ag-sort-indicator-icon ag-sort-descending-icon ag-hidden"
                  aria-hidden="true"
                >
                  <span
                    className="ag-icon ag-icon-desc"
                    unselectable="on"
                    role="presentation"
                  ></span>
                </span>
                <span
                  className="ag-sort-indicator-icon ag-sort-mixed-icon ag-hidden"
                  aria-hidden="true"
                >
                  <span
                    className="ag-icon ag-icon-none"
                    unselectable="on"
                    role="presentation"
                  ></span>
                </span>
                <span
                  className="ag-sort-indicator-icon ag-sort-none-icon ag-hidden"
                  aria-hidden="true"
                >
                  <span
                    className="ag-icon ag-icon-none"
                    unselectable="on"
                    role="presentation"
                  ></span>
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const CheckBoxUnChecked = () => {
    return (
      <div
        className="ag-header-cell ag-header-cell-sortable ag-focus-managed"
        role="columnheader"
        tabindex="-1"
        aria-colindex="1"
        col-id="1"
        aria-sort="none"
        aria-description="Press Space to toggle all rows selection (unchecked) Press ENTER to sort."
        style={{ left: '0px', width: '40px' }}
      >
        <div className="ag-header-cell-resize" role="presentation"></div>
        <div
          role="presentation"
          className="ag-labeled ag-label-align-right ag-checkbox ag-input-field ag-header-select-all"
          aria-hidden="true"
        >
          <div
            className="ag-input-field-label ag-label ag-hidden ag-checkbox-label"
            role="presentation"
          ></div>
          <div
            //   ref="eWrapper"
            className="ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper"
            role="presentation"
          >
            <input
              // ref="eInput"
              className="ag-input-field-input ag-checkbox-input"
              type="checkbox"
              id="ag-1846-input"
              aria-label="Press Space to toggle all rows selection (unchecked)"
              tabindex="-1"
              onChange={onCheckClicked}
              onClick={() => setChecked(!checked)}
            />
          </div>
        </div>
        <div className="ag-header-cell-comp-wrapper" role="presentation">
          <div className="ag-cell-label-container" role="presentation">
            <div className="ag-header-cell-label" role="presentation">
              <span className="ag-header-cell-text"></span>
              <span
                className="ag-header-icon ag-header-label-icon ag-filter-icon ag-hidden"
                aria-hidden="true"
              >
                <span
                  className="ag-icon ag-icon-filter"
                  unselectable="on"
                  role="presentation"
                ></span>
              </span>
              <span className="ag-sort-indicator-container">
                <span
                  className="ag-sort-indicator-icon ag-sort-order ag-hidden"
                  aria-hidden="true"
                ></span>
                <span
                  className="ag-sort-indicator-icon ag-sort-ascending-icon ag-hidden"
                  aria-hidden="true"
                >
                  <span
                    className="ag-icon ag-icon-asc"
                    unselectable="on"
                    role="presentation"
                  ></span>
                </span>
                <span
                  className="ag-sort-indicator-icon ag-sort-descending-icon ag-hidden"
                  aria-hidden="true"
                >
                  <span
                    className="ag-icon ag-icon-desc"
                    unselectable="on"
                    role="presentation"
                  ></span>
                </span>
                <span
                  className="ag-sort-indicator-icon ag-sort-mixed-icon ag-hidden"
                  aria-hidden="true"
                >
                  <span
                    className="ag-icon ag-icon-none"
                    unselectable="on"
                    role="presentation"
                  ></span>
                </span>
                <span
                  className="ag-sort-indicator-icon ag-sort-none-icon ag-hidden"
                  aria-hidden="true"
                >
                  <span
                    className="ag-icon ag-icon-none"
                    unselectable="on"
                    role="presentation"
                  ></span>
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  console.log('Checked =>', checked);

  //   return checked ? CheckBoxChecked() : CheckBoxUnChecked();

  return (
    <div
      role="presentation"
      className="ag-labeled ag-label-align-right ag-checkbox ag-input-field ag-header-select-all"
      aria-hidden="true"
    >
      <div
        className="ag-input-field-label ag-label ag-hidden ag-checkbox-label"
        role="presentation"
      ></div>
      <div
        //   ref="eWrapper"
        className="ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper"
        role="presentation"
      >
        <input
          // ref="eInput"
          className="ag-input-field-input ag-checkbox-input"
          type="checkbox"
          id="ag-1846-input"
          aria-label="Press Space to toggle all rows selection (unchecked)"
          tabindex="-1"
        //   onChange={onCheckClicked}
        //   onClick={() => setChecked(!checked)}
          checked={checked}
        />
      </div>
    </div>
  );
};

{
  /* <div
  className="ag-header-cell ag-header-cell-sortable ag-focus-managed"
  role="columnheader"
  tabindex="-1"
  aria-colindex="1"
  col-id="0"
  aria-sort="none"
  aria-description="Press Space to toggle all rows selection (checked) Press ENTER to sort."
  style={{ left: '0px', width: '40px' }}
>
  <div className="ag-header-cell-resize" role="presentation"></div>
  <div
    role="presentation"
    className="ag-labeled ag-label-align-right ag-checkbox ag-input-field ag-header-select-all"
    aria-hidden="true"
  >
    <div
      className="ag-input-field-label ag-label ag-hidden ag-checkbox-label"
      role="presentation"
    ></div>
    <div
      className="ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper ag-checked"
      role="presentation"
    >
      <input
        className="ag-input-field-input ag-checkbox-input"
        type="checkbox"
        id="ag-173-input"
        aria-label="Press Space to toggle all rows selection (checked)"
        tabindex="-1"
      />
    </div>
  </div>
  <div className="ag-header-cell-comp-wrapper" role="presentation">
    <div className="ag-cell-label-container" role="presentation">
      <div className="ag-header-cell-label" role="presentation">
        <span className="ag-header-cell-text"></span>
        <span
          className="ag-header-icon ag-header-label-icon ag-filter-icon ag-hidden"
          aria-hidden="true"
        >
          <span className="ag-icon ag-icon-filter" unselectable="on" role="presentation"></span>
        </span>
        <span className="ag-sort-indicator-container">
          <span
            className="ag-sort-indicator-icon ag-sort-order ag-hidden"
            aria-hidden="true"
          ></span>
          <span
            className="ag-sort-indicator-icon ag-sort-ascending-icon ag-hidden"
            aria-hidden="true"
          >
            <span className="ag-icon ag-icon-asc" unselectable="on" role="presentation"></span>
          </span>
          <span
            className="ag-sort-indicator-icon ag-sort-descending-icon ag-hidden"
            aria-hidden="true"
          >
            <span className="ag-icon ag-icon-desc" unselectable="on" role="presentation"></span>
          </span>
          <span className="ag-sort-indicator-icon ag-sort-mixed-icon ag-hidden" aria-hidden="true">
            <span className="ag-icon ag-icon-none" unselectable="on" role="presentation"></span>
          </span>
          <span className="ag-sort-indicator-icon ag-sort-none-icon ag-hidden" aria-hidden="true">
            <span className="ag-icon ag-icon-none" unselectable="on" role="presentation"></span>
          </span>
        </span>
      </div>
    </div>
  </div>
</div>; */
}

{
  /* <div className="ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper">
<input
  onClick={onCheckClicked}
  type={'checkbox'}
  checked={params.api.selectAll}
  className="ag-input-field-input ag-checkbox-input"
></input>
</div> */
}

{
  /* <div className="ag-cell ag-cell-not-inline-editing ag-cell-normal-height ag-cell-focus" aria-colindex="1" tabindex="-1" role="gridcell" col-id="1" aria-describedby="cell-1-574" style="left: 0px; width: 40px;"><div className="ag-cell-wrapper" role="presentation"><div className="ag-selection-checkbox" role="presentation">
                <div role="presentation" ref="eCheckbox" className="ag-labeled ag-label-align-right ag-checkbox ag-input-field">
                <div  className="ag-input-field-label ag-label ag-hidden ag-checkbox-label" role="presentation"></div>
                <div ref="eWrapper" className="ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper" role="presentation">
                    <input ref="eInput" className="ag-input-field-input ag-checkbox-input" type="checkbox" id="ag-1557-input" aria-label="Press Space to toggle row selection (unchecked)" tabindex="-1" />
                </div>
            </div>
            </div><span role="presentation" id="cell-1-574" className="ag-cell-value"></span></div></div> */
}
