import React from 'react';
import './HeaderTab.css'

export default ({ text= "" }) => {
    return <h2 className="header-tab-component">{text}</h2>
};
