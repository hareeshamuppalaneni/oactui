import React from 'react';

// import Dropdown from 'react-bootstrap/Dropdown';
// import DropdownButton from 'react-bootstrap/DropdownButton';
// import { Dropdown  } from 'react-bootstrap';
import { Dropdown } from '@trussworks/react-uswds';

const DropDownTextSelect = ({ defaultText = 'Select', menuItems = [], style = {}, onSelect, className = "usa-form", selectClassName = "usa-select" }) => {
  return (

    // <Dropdown style={style} variant="light">
    //   <Dropdown.Toggle id="dropdown-basic">
    //     {defaultText}
    //   </Dropdown.Toggle>

    //   <Dropdown.Menu>
    //     {menuItems.map((eachItem, index) => {
    //       return (<Dropdown.Item as="button" key={index} onClick={onSelect}>{eachItem}</Dropdown.Item>)
    //     })}
    //   </Dropdown.Menu>
    // </Dropdown>
    // <DropdownButton id="dropdown-item-button" title={defaultText} style={style} >
    //   <Dropdown.ItemText>{defaultText}</Dropdown.ItemText>
    //   {menuItems.map((eachItem, index) => {
    //     return (<Dropdown.Item as="button" key={index}>{eachItem}</Dropdown.Item>)
    //   })}
    // </DropdownButton>
    <Dropdown id="input-dropdown" name="input-dropdown" style={{ minWidth: '220px', margin: '1.5em 0px 0px 0px', ...style }} onChange={onSelect}>
      <option value>{defaultText}</option>
      {menuItems.map((eachItem, index) => {
        if(eachItem.accessControlHierarchyId) {
          const { accessControlHierarchyId, name } = eachItem;
          return (<option key={index} value={index}>{name}</option>)
        } else {
          return (<option key={index} value={eachItem}>{eachItem}</option>)
        }

      })}
    </Dropdown>
  //   <Dropdown id="input-dropdown" name="input-dropdown"  style={{ minWidth: '200px', ...style }} radioGroup='Select'>
  //        <option value>{defaultText}</option>
  //        {menuItems.map((eachItem, index) => {
  //         return (<option key={index} value={eachItem}>{eachItem}</option>)
  //       })}
  // </Dropdown>
      //   <Dropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
      //   <Dropdown.DropdownToggle caret>
      //     Dropdown
      //   </Dropdown.DropdownToggle>
      //   <Dropdown.DropdownMenu>
      //     <Dropdown.DropdownItem header>Header</Dropdown.DropdownItem>
      //     <Dropdown.DropdownItem disabled>Action</Dropdown.DropdownItem>
      //     <Dropdown.DropdownItem>Another Action</Dropdown.DropdownItem>
      //     <Dropdown.DropdownItem divider />
      //     <Dropdown.DropdownItem>Another Action</Dropdown.DropdownItem>
      //   </Dropdown.DropdownMenu>
      // </Dropdown>
    // <form style={{ minWidth: '200px', ...style }} onChange={onSelect} className={className}>
    //   <select className={selectClassName} name="options" id="options">
    //     <option value>{defaultText}</option>
    //     {menuItems.map((eachItem, index) => {
    //       return (<option key={index} value={eachItem}>{eachItem}</option>)
    //     })}
    //   </select>
    // </form>
  );
}

export default DropDownTextSelect;