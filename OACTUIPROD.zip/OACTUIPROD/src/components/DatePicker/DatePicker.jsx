import { DatePicker, Form, Label, FormGroup, TextInput } from '@trussworks/react-uswds';
import React from 'react';
import './DatePicker.css'

export default (props) => {
    return (
        <Form onSubmit={function noRefCheck() { }} style={{ minWidth: '200px' }} className="datepicker-container">
            <FormGroup>
                <DatePicker
                    aria-describedby="appointment-date-hint"
                    aria-labelledby="appointment-date-label"
                    id="appointment-date"
                    name="appointment-date"
                    {...props}
                />
            </FormGroup>
        </Form>
    )
}

