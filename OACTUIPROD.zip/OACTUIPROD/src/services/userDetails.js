import axios from 'axios';
// import configs from 'configs';
import commonFetch from './commonFetch';

export const getLoggedInUserDetails = async (emailAddress) => {
  const userDetails = await commonFetch({
    url: 'who-am-i',
    method: 'get',
    params: {
      identifier: emailAddress || 'Nielander.Debra@dol.gov' // For default, just added for testing
    }
  });
  return userDetails;
};
