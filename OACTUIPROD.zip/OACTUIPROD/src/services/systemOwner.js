import axios from 'axios';
import commonFetch from './commonFetch';

export const getSystemOwnerData = async (emailAddress) => {
  const SystemOwnerTableData = await commonFetch({
    url: 'certification-cycles',
    method: 'get',
    params: {
      email: emailAddress || 'Young.Rita@dol.gov' // For default, just added for testing
    }
  });
  console.log('Response from System Owner API', SystemOwnerTableData);
  return SystemOwnerTableData;
};

export const downloadAttestPDFFile = async (body) => {
  try {
    const response = await axios({
      url: process.env.REACT_APP_API_ENDPOINT + 'certification-cycles/fetchAttestaionPDF',
      method: 'GET',
      params: body,
      responseType: 'blob',
      headers: {
        'Access-Control-Allow-Origin': '*'
      },
      timeout: '10000'
    });

    return response.data;
  } catch (error) {
    return error;
  }
};

export const downloadExcelFile = async (body) => {
  try {
    const response = await axios({
      url: process.env.REACT_APP_API_ENDPOINT + 'notify/excel',
      method: 'GET',
      params: body,
      responseType: 'blob',
      headers: {
        'Access-Control-Allow-Origin': '*'
      },
      timeout: '10000'
    });

    return response.data;
  } catch (error) {
    return error;
  }
};
