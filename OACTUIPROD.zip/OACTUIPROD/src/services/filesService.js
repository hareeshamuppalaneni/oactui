import { commonFetch } from 'services';

export const uploadFile = (params, onUploadProgress) => {
  let formData = new FormData();
  formData.append('file', params.file);
  formData.append('application', params.application);
  formData.append('system', params.system);
  formData.append('reviewCycle', params.reviewCycle);
  const config = {
    body: formData,
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    onUploadProgress
  };
  return commonFetch('/upload', config, 'post');
};

export const getFiles = () => {
  return commonFetch('/files');
};

export const uploadFilesToCreateCycle = (file, certId, userLogin) => {
  let formData = new FormData();
  formData.append('file', file);
  formData.append('metadata', certId);

  formData.append('userId', userLogin);
  // formData.append('application', params.application);
  // formData.append('system', params.system);
  // formData.append('reviewCycle', params.reviewCycle);
  const config = {
    body: formData,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
    // onUploadProgress
  };
  const fileReferenceString = commonFetch({
    url: 'uploadFile',
    method: 'post',
    data: formData,
    headers: config.headers
  });
  console.log('fileReferenceString =>', fileReferenceString);
  return fileReferenceString;
};
