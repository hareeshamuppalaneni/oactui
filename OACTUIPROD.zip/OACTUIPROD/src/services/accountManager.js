import { commonFetch } from 'services';

export const getAccountManagerTableData = async (emailAddress) => {
  const tableDetails = await commonFetch({
    url: 'certification-item-details',
    method: 'get',
    params: {
      loginEmail: emailAddress || 'Young.Rita@dol.gov' // For default, just added for testing
    }
  });
  console.log('Response from Item Details', tableDetails);
  return await tableDetails;
};


export const editAccountManager =  async (body) => {
  const editResponse = await commonFetch({
    url: `certification-item-details/edit-items`,
    method: 'put',
    data: body
  });

  console.log('Response from Edit Account Manager', editResponse);
  return await editResponse;
};

export const certifyAccountManager = async (body) => {
  const certifyResponse = await commonFetch({
    url: `certification-item-details/edit-items`,
    method: 'put',
    data: body
  });
  console.log('Response from Certify Account Manager', certifyResponse);
  return await certifyResponse;
}

export const getAttestationList = async (emailAddress) => {
  const applicationList = await commonFetch({
    url: `certification-cycles/attestation`,
    method: 'get',
    params: {
      email: emailAddress
    }
  });

  console.log('Response from Get Attestation List', applicationList);
  return await applicationList;
};

export const postAttestationList = async (body) => {
  console.log('Request From Post Attestation ', body);
  const responseOfPost = await commonFetch({
    url: `certification-cycles/attestation`,
    method: 'post',
    data: body
  });

  console.log('Response from Post Attestation List', responseOfPost);
  return await responseOfPost;
};


/**
 * 
 * @param {Request Body} body 
 * { "email": "string","itemsList": [0] }
 * @returns Promise
 */
export const undoActionAccountManager =  async (body) => {
  const undoResponse = await commonFetch({
    url: `certification-item-details/undo-items`,
    method: 'put',
    data: body
  });

  console.log('Response from Undo Action Account Manager', undoResponse);
  return await undoResponse;
};
