import commonFetch from './commonFetch';

export const getLoginEmailAddress = async () => {
    const loginEmailAddress = await commonFetch({ url: 'auth/login', method: 'get' });
    return loginEmailAddress;
}