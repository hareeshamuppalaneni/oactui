import axios from 'axios';
import commonAxios from 'configs/commonAxios';

export default async (configs) => {
    try {
        const response = await commonAxios({...configs});
        // We might need to change this
        return response.data;
    } catch (error) {
        // We need to create custom error handling, which can help us find out the path for the erros.
        throw error;
    }
};
