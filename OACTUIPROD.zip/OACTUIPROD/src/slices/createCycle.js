import { createSlice } from '@reduxjs/toolkit';
import { createCycleBag } from 'utils';
import { Table, TextInput, Icon } from '@trussworks/react-uswds';
import {
  getSystemList,
  getSubSystemList,
  getApplicationList,
  createCyclePost,
  getCyclesList,
  getCreateCycleReviewList,
  uploadFilesToCreateCycle,
  createCycleReview,
  onsubmitCertificateData,
  uploadFileData,
  notifyUsersService
} from 'services';

const initialCycleCreationState = {
  cycleName: '',
  startDate: '',
  endDate: '',
  cycleId: 1,
  applications: {
    options: [],
    selected: []
  },
  cycleList: [],
  filesSelected: [],
  createCycleSuccess: null,
  filterCertificateData: [],
  records: [],
  loading: true,
  editSuccess: null,
  selectedData: [],
  selectAll: false,
  filterTableData: []
};

const initialState = {
  filterCol: ['Action', 'Documents (ADD)'],
  tableData: [],
  filterTableData: [],
  loading: true,
  selectedData: [],
  selectAll: false
};

export const createCycleSlice = createSlice({
  name: 'createCycleDetails',
  initialState: initialCycleCreationState,
  reducers: {
    resetCreateCycleData: (state, action) => {
      return {
        ...initialCycleCreationState
      };
    },
    selectAgency: (state, action) => {
      state.agency.selected = [action.payload];
    },
    setCycleName: (state, action) => {
      state.cycleName = action.payload;
    },
    setStartDate: (state, action) => {
      state.startDate = action.payload;
    },
    setEndDate: (state, action) => {
      state.endDate = action.payload;
    },
    setCycleStateId: (state, action) => {
      state.cycleId = action.payload;
    },
    setCreateSuccess: (state, action) => {
      state.createCycleSuccess = action.payload;
    },
    // loadSystem: (state, action) => {
    //     state.systems.options = action.payload;
    // },
    // setSubSystemOptions: (state, action) => {
    //     state.subSystems.options = action.payload;
    // },
    setApplicationsOptions: (state, action) => {
      state.applications.options = action.payload;
    },
    // setSubSystem: (state, action) => {
    //     state.subSystems.selected = action.payload;
    // },
    // selectSystem: (state, action) => {
    //     state.systems.selected = [action.payload];
    //     // Reset the state
    //     state.subSystems = initialCycleCreationState.subSystems;
    //     state.applications = initialCycleCreationState.applications;
    // },
    // selectSubSystem: (state, action) => {
    //     state.subSystems.selected = [action.payload];
    //     // Reset the state
    //     state.applications = initialCycleCreationState.applications;
    // },
    selectApplication: (state, action) => {
      state.applications.selected = [...state.applications.selected, action.payload];
    },
    setFilterCertificateData: (state, action) => {
      state.filterCertificateData = action.payload;
    },
    setRecords: (state, action) => {
      state.records = action.payload;
    },
    setEdit: (state, action) => {
      state.edit = action.payload;
    },
    // setModalSuccess: (state, action) => {
    //     state.modalSuccess = true;
    //     state.modalError = false;
    // },
    // setModalError: (state, action) => {
    //     state.modalError = true;
    //     state.modalSuccess = false;
    // },
    setCycleList: (state, action) => {
      state.cycleList = action.payload;
    },
    setFileReferences: (state, action) => {
      const { index, reference } = action.payload;
      const tempApplication = JSON.parse(JSON.stringify(state.applications.options));
      tempApplication[index] = {
        ...tempApplication[index],
        fileRefernceId: reference
      };

      return {
        ...state,
        applications: {
          options: tempApplication,
          selected: []
        }
      };
    },
    setFileObject: (state, action) => {
      const { index, fileObject } = action.payload;
      const tempApplication = JSON.parse(JSON.stringify(state.applications.options));
      tempApplication[index] = {
        ...tempApplication[index],
        fileObject: fileObject
      };

      return {
        ...state,
        applications: {
          options: tempApplication,
          selected: []
        }
      };
    },
    setEditSuccess: (state, action) => {
      state.editSuccess = action.payload;
    },
    setNotifySuccess: (state, action) => {
      state.notifySuccess = action.payload;
    },
    setLoadingForCC: (state, action) => {
      state.loading = action.payload;
    },
    setCCSelectData: (state, action) => {
      state.selectedData = { ...action.payload };
    },
    setCCSelectAll: (state, action) => {
      state.selectAll = !state.selectAll;
    },
    setCCResetSelectAll: (state, action) => {
      state.selectedData = {}
      state.selectAll = false
    }
  }
});

// Action creators are generated for each case reducer function
export const {
  resetCreateCycleData,
  setCycleName,
  setStartDate,
  setEndDate,
  loadSystem,
  setSubSystemOptions,
  setApplicationsOptions,
  selectSystem,
  selectSubSystem,
  selectAgency,
  selectApplication,
  setModalSuccess,
  setModalError,
  setCycleList,
  setFileReferences,
  setCycleStateId,
  setFileObject,
  setCreateSuccess,
  setFilterCertificateData,
  setRecords,
  setEdit,
  setEditSuccess,
  setLoadingForCC,
  setCCSelectData,
  setCCSelectAll,
  setNotifySuccess,
  setCCResetSelectAll
} = createCycleSlice.actions;

// Middleware to call APIs and dispatch Redux actions
// export const fetchSystemList = () => async (dispatch, getState) => {
//     const systemList = await getSystemList();
//     console.log('System List', systemList);
//     dispatch(loadSystem(systemList));
// };

// export const fetchSubSystemList = () => async (dispatch, getState) => {
//     const currentState = getState();
//     const systemOptions = currentState.createCycle.systems.options;
//     const selectedSystem = currentState.createCycle.systems.selected[0];
//     const subSystemList = await getSubSystemList(systemOptions[selectedSystem].accessControlHierarchyId);
//     console.log("subSystemList => ", subSystemList);
//     dispatch(setSubSystemOptions(subSystemList))
// };
export const onSelectCCRow = (index) => async (dispatch, getState) => {
  console.log("ss",index)
  const currentState = getState();
  const currentCCState = currentState.createCycle;
  const { filterTableData, tableData, selectAll, selectedData, filterCertificateData,records } = currentCCState;
  const currentTableData = JSON.parse(JSON.stringify(records));
  if (Array.isArray(index)) {
    const selectedValues = {};
    for await (const [index, values] of currentTableData.entries()) {
      selectedValues[index] = !selectAll;
    }
    dispatch(setCCSelectData(selectedValues));
    dispatch(setCCSelectAll());
  } else {
    const currentSelectedData = JSON.parse(JSON.stringify(selectedData));
    console.log("sss",currentSelectedData)
    dispatch(
      setCCSelectData({ ...currentSelectedData, [index]: currentSelectedData[index] ? false : true })
    );
  }
};

export const fetchApplicationList = (currentUser) => async (dispatch, getState) => {
  const applicationList = await getCreateCycleReviewList(currentUser);
  const { cycleData } = applicationList[0];
  const startDate = cycleData.lifeCycleData.beginEffectiveDate;
  const dueDate = cycleData.lifeCycleData.endEffectiveDate;
  dispatch(setCycleStateId(cycleData.stndCycleId));
  dispatch(setCycleName(cycleData.descriptionText));
  dispatch(setStartDate(startDate));
  dispatch(setEndDate(dueDate));
  dispatch(setApplicationsOptions(applicationList));
};

export const createCycleCreationSubmit = () => async (dispatch, getState) => {
  const currentState = getState();
  const response = await createCyclePost(currentState.createCycle);
  console.log('response in Slice => ', response);
  dispatch(resetCreateCycleData);

  if (response.name) {
    dispatch(setModalSuccess());
  } else {
    dispatch(setModalError());
  }
};

export const fetchCycleList = (email) => async (dispatch, getState) => {
  const response = await getCyclesList(email);
  console.log('Cycle response => ', response, getState());
  dispatch(setCycleList(response));
  dispatch(setEditSuccess(null));
  dispatch(setNotifySuccess(null));
  dispatch(setLoadingForCC(false));
};

export const onSearch = (value, col) => async (dispatch, getState) => {
  const currentState = getState();
  const currentTableData = currentState.createCycle.cycleData;
  const currentKey = Object.keys(currentTableData[0])[col];
  let filterTableData;
  if (value=="sort"){
     filterTableData = [...currentTableData].sort((a, b) => (a[currentKey] < b[currentKey] ? -1 : 1));
  }else{
  filterTableData = currentTableData.filter((eachRow) => {

    return eachRow[currentKey].toLowerCase().startsWith(value.toLowerCase());
  });
}
  dispatch(setFilterCertificateData(filterTableData));
};
export const onsubmitCertData =(obj)=> async (dispatch,getState) => {
 const response = await onsubmitCertificateData(obj)
 dispatch(setEdit(null))

};
export const notifyUsers =(obj)=> async (dispatch,getState) => {

  console.log("Notify User list"+JSON.stringify(obj));

  try{
  //   const currentState = getState();
  //   const currentCCState = currentState.createCycle;
  //   const { filterTableData, tableData, selectAll, selectedData, filterCertificateData,records } = currentCCState;
  //   let inputArray=[]
  // for (const key in selectedData){
  //   if(selectedData[key]){
  //
  //     let data=records[key].Action
  //     console.log(data.certificationCycleId)
  //     inputArray.push(data.certificationCycleId)
  //   }
  // }
  // let response=await notifyUsersService(inputArray);

  let response=await notifyUsersService(obj);

  if(response.error){
    alert("Notify User has errored.\n"+JSON.stringify(obj));
    //debugger;
    dispatch(setNotifySuccess(false));
    dispatch(setLoadingForCC(false));
  }else{
    alert("Notify User success.\n"+JSON.stringify(obj));
  dispatch(setNotifySuccess(true));
  }
  dispatch(fetchCycleList(getState().userDetail?.userInformation?.loginId));
  // selectedData!=undefined&& selectedData.map((e,index)=>{
  //     console.log(e,index)
  //   })

} catch (error) {
    //debugger;
    alert("Notify User Exception Errored.\n"+JSON.stringify(obj));
  dispatch(setNotifySuccess(false));
  dispatch(setLoadingForCC(false));
  dispatch(fetchCycleList(getState().userDetail?.userInformation?.loginId));
  throw error;
}

 };

export const uploadFileDataCertificate = (file, id) => async (dispatch, getState) => {
  let userId = getState().userDetail.userInformation.oshaUserId;
  await uploadFileData(file, id, userId);
};

export const uploadFileForCreateCycle = (files, index) => async (dispatch, getState) => {
  console.log('files => ', files);
  const currentState = getState();
  const currentCreateCycleState = currentState.createCycle;
  const currentUserDetails = currentState.userDetail;
  let reader = new FileReader();
  let file;
  let tempFiles = [];
  for (let i = 0; i < files.length; i++) {
    (function (file) {
      var reader = new FileReader();
      reader.onload = (file) => {
        tempFiles[i] = reader.result;
      };
      reader.readAsDataURL(file);
    })(files[i]);
  }

  try {
    const response = await uploadFileData(files[0], currentCreateCycleState.cycleList[index], currentUserDetails.userInformation.loginId);
    const fileObject = { success: true, fileName: files[0].name };
    dispatch(setFileObject({ index, fileObject }));
    dispatch(setFileReferences({ index, reference: response }));
   dispatch(fetchCycleList(getState().userDetail?.userInformation?.loginId));
  } catch (error) {
    const fileObject = { error: true, fileName: files[0].name };
    dispatch(setFileObject({ index, fileObject }));
  }
};

export const submitCreateCycle = () => async (dispatch, getState) => {
  const currentState = getState();
  const employeeNumber = currentState.userDetail.employeeNumber;
  const applicationOptions = currentState.createCycle.applications.options;
  const createCycleState = currentState.createCycle;
  const tempBag = createCycleBag(createCycleState);

  const request = {
    auditData: {
      lastModifiedUserId: employeeNumber,
      lockControlNumber: 0
    },
    cycleDataBag: tempBag
  };

  const response = await createCycleReview(request);

  if (response.error) {
    dispatch(setCreateSuccess(false));
  } else {
    dispatch(setCreateSuccess(true));
  }
};

export const editCycleDetails = (obj) => async (dispatch, getState) => {
  try {
    const currentState = getState();
    const { userDetail } = currentState;
    const response = await onsubmitCertificateData(obj);
    dispatch(setEdit(null));
    dispatch(setEditSuccess(true));
    dispatch(setLoadingForCC(true));
    dispatch(fetchCycleList(userDetail?.userInformation?.loginId));
  } catch (error) {
    dispatch(setEditSuccess(false));
    throw error;
  }
};

export default createCycleSlice.reducer;
