import React, { useEffect } from 'react';
import '@trussworks/react-uswds/lib/uswds.css';
import '@trussworks/react-uswds/lib/index.css';
import '@fontsource/merriweather';

import Cookies from 'js-cookie';
import _ from 'underscore';

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { GovBanner } from '@trussworks/react-uswds';
import CONFIGS from 'configs';
import {
  CertificationCoordinatorPage,
  HomePage,
  FederalPage,
  UploadFilePage,
  AccountManagerPage,
  SubAccountManagerPage,
  SystemAdmin,
  SystemOwner,
  SystemPOC,
  Navigator
} from 'pages';
import { Footer } from 'components';
// Bootstrap CSS
import 'bootstrap/dist/css/bootstrap.min.css';
// Bootstrap Bundle JS
import 'bootstrap/dist/js/bootstrap.bundle.min';
// import "bootstrap-select/dist/css/bootstrap-select.min.css"
// import "bootstrap-select/dist/js/bootstrap-select.js"
import './App.css';

function App() {
  const {
    ROOT,
    HOME,
    FEDERAL,
    FILE_UPLOAD,
    CERTIFICATION_COORDINATOR,
    ACCOUNT_MANAGER,
    SUB_ACCOUNT_MANAGER,
    SYSTEM_ADMIN,
    SYSTEM_OWNER,
    SYSTEM_POC,
    NAVIGATOR
  } = CONFIGS.ROUTES;

  useEffect(() => {
    console.log("_.isNull(Cookies.get('localUser')) => ", _.isNull(Cookies.get('localUser')));
    console.log("_.isUndefined(Cookies.get('localUser')) => ", _.isUndefined(Cookies.get('localUser')))
    if (_.isUndefined(Cookies.get('localUser'))) {
      window.location.href = '/oact';
    }
  }, []);

  return (
    <>
      <GovBanner />
      <Router>
        <Routes>
          <Route exact path={HOME} element={<HomePage />} />
          <Route exact path={FEDERAL} element={<FederalPage />} />
          <Route exact path={FILE_UPLOAD} element={<UploadFilePage />} />
          <Route
            exact
            path={CERTIFICATION_COORDINATOR}
            element={<CertificationCoordinatorPage />}
          />
          <Route exact path={ACCOUNT_MANAGER} element={<AccountManagerPage />} />
          <Route exact path={SUB_ACCOUNT_MANAGER} element={<AccountManagerPage />} />
          <Route exact path={SYSTEM_ADMIN} element={<CertificationCoordinatorPage />} />
          <Route exact path={SYSTEM_OWNER} element={<SystemOwner />} />
          <Route exact path={SYSTEM_POC} element={<CertificationCoordinatorPage />} />
          <Route exact path={NAVIGATOR} element={<Navigator />} />
        </Routes>
      </Router>
      <Footer />
    </>
  );
}

export default App;
