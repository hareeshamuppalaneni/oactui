import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import RenderFileUpload from "../CreateCycle/FileUpload";

const UploadModal = ({rowIndex})=>{

    //alert("***** level 1:");
    //debugger;

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    return (
        <>
            <button className="btn" onClick={handleShow}><i className="fa fa-upload"></i></button>

            {/*<Button variant="primary" onClick={handleShow}>*/}
            {/*    Launch static backdrop modal*/}
            {/*</Button>*/}

            <Modal
                show={show}
                onHide={handleClose}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Header closeButton>
                    <Modal.Title>File Upload</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                      <RenderFileUpload
                        myRowIndex={rowIndex}
                      ></RenderFileUpload>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default UploadModal;
