import CertificateCoordinator from './CertificateCoordinate';

export default CertificateCoordinator;