import {
  Bell,
  Upload,
  Exclamation,
  Flag,
  FiletypeXlsx,
} from "react-bootstrap-icons";
import RenderFileUpload from "containers/CreateCycle/FileUpload";
import commonFetch from "../../services/commonFetch";
import { FileInput } from "@trussworks/react-uswds";

export function parseData(data, setEdit) {
  let parseData = [];
  data.forEach((element) => {
    parseData.push({
      Action: element,
      upload: <span></span>,
      Cycle: element?.name || "",
      application: element?.pocData?.applicationName || "",
      start_Date: element?.cycleStartDate || "",
      due_Date: element?.dueDate || "",
      days_due: "",
      system_Owner: element?.pocData?.systemOwner || "",
      agency: element?.pocData?.accountManagerOfc || "",

      Coordinator: element?.pocData?.certCoOrdinator || "",
      account_Manager: element?.pocData?.accountManager || "",
      sub_account_Manager: element?.pocData?.subaccountManager || "",
    });
  });
  return parseData;
}

const formatDueDays = (cell, row) => {
  let cellTag =
    cell >= 50 ? (
      <>
        <a style={{ color: "red" }}>
          {" "}
          <Exclamation />
          {cell} days overdue
        </a>
      </>
    ) : cell >= 20 && cell < 50 ? (
      <>
        <a style={{ color: "orange" }}>
          {" "}
          <Flag />
          {cell} days overdue
        </a>
      </>
    ) : (
      <>
        {cell && (
          <a style={{ color: "orange" }}>
            {" "}
            <Bell />
            {cell} days overdue
          </a>
        )}
      </>
    );
  return cellTag == "" ? cell : cellTag;
};

export const columns = [
  "Action",
  "Upload",
  "Cycle",
  "Application",
  "Start Date",
  "Due Date",
  "Days till Due",
  "System Owner",
  "Coordinator",
  "Account Manager",
  "Sub Account Manager",

  "Agency",
];
