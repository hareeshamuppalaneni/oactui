import React from "react";
import { Alert } from "@trussworks/react-uswds";
import { useSelector } from "react-redux";

const RenderAlert = (props) => {
  if (props.isSuccess === true) {
    return (
      <>
        <Alert
          type="success"
          heading="Success status"
          headingLevel="h4"
          style={{ marginBottom: "20px " }}
        >
          {props.message}
        </Alert>
      </>
    );
  } else if (props.isSuccess === false) {
    return (
      <>
        <Alert
          type="error"
          heading="Error status"
          headingLevel="h4"
          style={{ marginBottom: "20px " }}
        >
          {props.message}
        </Alert>
      </>
    );
  } else {
    return null;
  }
};

export default RenderAlert;
