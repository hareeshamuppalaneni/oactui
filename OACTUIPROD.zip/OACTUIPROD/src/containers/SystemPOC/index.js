import SystemPOC from './SystemPOC';

export default SystemPOC;