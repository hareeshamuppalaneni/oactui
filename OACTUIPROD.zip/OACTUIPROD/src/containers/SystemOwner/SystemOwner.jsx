import React, { useRef, useCallback } from 'react';
import { useSelector } from 'react-redux';
import { SubHeaderText, HeaderTab } from 'components';
import Spinner from 'react-bootstrap/Spinner';
import SystemOwnerTable from './SystemOwnerTable';
import { Button, GridContainer, Grid } from '@trussworks/react-uswds';
import { IMAGES } from 'assets';
import { Container, Row, Col } from 'react-bootstrap';
import BulkActions from './SystemOwnerBulkAction';
import RenderAlertMessage from './SystemOwnerAlert';
import './SystemOwner.css';

export default () => {
  const gridRef = useRef();
  const systemOwnerData = useSelector((state) => state.systemOwner);

  const spinnerStyle = {
    marginLeft: '45%',
    marginRight: '45%',
    marginTop: '5%',
    marginBottom: '5%'
  };

  const onPageSizeChanged = useCallback(() => {
    var value = document.getElementById('page-size').value;
    gridRef.current.api.paginationSetPageSize(Number(value));
  }, []);

  return (
    <>
      <div style={{ margin: `auto auto`, width: `95%` }}>
        <div>
          <Grid row>
            <Grid col={10}>
              <SubHeaderText text={'System Owner'} />
            </Grid>
            <Grid col={2}>
              {/* <Row> */}
                <Col md={{ span: 2, offset: 4 }}>
                  <img className="oact__logo-img" alt="img alt text" src={IMAGES.MAIN_OACT_LOGO} />
                </Col>
              {/* </Row> */}
            </Grid>
          </Grid>
          <RenderAlertMessage />
          <Grid row style={{ display: 'flow-root', marginBottom: '-25px' }}>
            {/* <Grid col={10} className="system-owner-bulk-action-button-container"> */}
              <BulkActions gridRef={gridRef} />
            {/* </Grid> */}
            {/* <Grid col={2} className="system-owner-bulk-action-button-container"> */}
              <span className="example-header" style={{ float: 'right'}}>
                Page Size:&nbsp;
                <select onChange={onPageSizeChanged} id="page-size">
                  <option value="10">
                    10
                  </option>
                  <option value="25">25</option>
                  <option value="50">50</option>
                  <option value="100" selected={true}>100</option>
                </select>
              </span>
            {/* </Grid> */}
            {/* <Grid col={4}>{RenderAttestation()}</Grid> */}
          </Grid>
        </div>
        {/* <EditModal /> */}
      </div>
      {systemOwnerData.loading ? (
        <Spinner animation="border" role="status" style={spinnerStyle}>
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      ) : (
        // <div className="App usa-banner__inner" style={{ display: 'block' }}>
        <SystemOwnerTable gridRef={gridRef} />
        // </div>
      )}
    </>
  );
};
