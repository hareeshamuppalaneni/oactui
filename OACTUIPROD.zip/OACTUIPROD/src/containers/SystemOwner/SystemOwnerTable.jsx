import React, { useCallback, useMemo, useRef } from 'react';
import { Table, TextInput, Icon } from '@trussworks/react-uswds';
import { useSelector, useDispatch } from 'react-redux';
import { TableWithFilter } from 'components';
import {
  setSystemOwnerSelectData,
  certifySingleSystemOwner,
  onClickDownloadAttestPDFFile,
  onClickDownloadExcelFile
} from 'slices';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faFileSignature,
  faFileExcel,
  faFilePdf,
  faEllipsis,
  faExclamationCircle,
  faExclamationTriangle,
  faBell
} from '@fortawesome/free-solid-svg-icons';
const FilePresent = Icon.FilePresent;
const Verified = Icon.Verified;
const Edit = Icon.Edit;

import { CheckBox } from 'components';

import { AgGridReact } from 'ag-grid-react';
// import 'ag-grid-enterprise';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

const ActionIconsStyle = {
  color: '#0075BF',
  cursor: 'pointer',
  marginLeft: '20px'
};

const EllipsisIconsStyle = {
  ...ActionIconsStyle,
  // pointerEvents: 'none',
  cursor: 'not-allowed'
};

const normalDueDaysStyle = {
  // marginLeft: '20px',
  // textAlign: 'center'
};

const CertificationIconStyle = {
  marginLeft: '20px'
};

const PastDueDateIconStyle = {
  marginLeft: '20px'
  // color: 'red'
};

const ThreeDaysIconStyle = {
  marginLeft: '20px'
  // color: 'salmon'
};
const SevenDaysIconStyle = {
  marginLeft: '10px'
  // color: 'golden'
};

export default ({ gridRef }) => {
  // const gridRef = useRef();
  const dispatch = useDispatch();
  const systemOwnerState = useSelector((state) => state.systemOwner);
  const { tableHeadCols, tableData, filterTableData, selectedData } = systemOwnerState;
  const onSearch = (value, col) => {
    dispatch(onSearchTable(value, col));
  };

  const ActionElements = (props) => {
    let tempStyles = {
      marginLeft: '20px'
    };

    if (props?.data?.stateName === 'Completed') {
      tempStyles.color = '#999999';
      tempStyles.pointerEvents = 'none';
    }

    return (
      <span
        className="system-owner-bulk-action-button-container"
        onClick={() => dispatch(certifySingleSystemOwner(props.data))}
        // style={ConditionalStyles()}
        title="Certification"
        style={tempStyles}
      >
        <FontAwesomeIcon
          icon={faFileSignature}
          className="system-owner-bulk-action-button-text-container"
        />
      </span>
    );
  };

  const DocumentElement = (props) => {
    if (props?.data?.stateName === 'Completed' || props?.data?.stateName === 'With System Owner') {
      return (
        <>
          <span
            style={ActionIconsStyle}
            title="Download Excel"
            onClick={() => dispatch(onClickDownloadExcelFile(props?.data))}
          >
            <FontAwesomeIcon icon={faFileExcel} />
          </span>
          <span
            style={ActionIconsStyle}
            title="Download Attest PDF"
            onClick={() => dispatch(onClickDownloadAttestPDFFile(props?.data))}
          >
            <FontAwesomeIcon icon={faFilePdf} />
          </span>
        </>
      );
    } else {
      return (
        <>
          <span style={EllipsisIconsStyle} title="Pending State">
            <FontAwesomeIcon icon={faEllipsis} />
          </span>
        </>
      );
    }
  };

  function between(x, min, max) {
    return x >= min && x <= max;
  }

  const DaysTillDueElement = (props) => {
    // props.data.daysTillDueDate = -6;
    if (Number(props.data.daysTillDueDate) < 0) {
      return (
        <span style={{ ...normalDueDaysStyle, color: '#d54309' }}>
          {Number(props.data.daysTillDueDate)}
          <span style={{ ...SevenDaysIconStyle, color: '#d54309' }}>
            <FontAwesomeIcon icon={faExclamationCircle} />
          </span>
        </span>
      );
    }

    if (3 >= Number(props.data.daysTillDueDate) && Number(props.data.daysTillDueDate) >= 0) {
      return (
        <span style={{ ...normalDueDaysStyle, color: '#000000' }}>
          {Number(props.data.daysTillDueDate)}
          <span style={{ ...SevenDaysIconStyle, color: '#fa9441' }}>
            <FontAwesomeIcon icon={faExclamationTriangle} />
          </span>
        </span>
      );
    }

    if (7 >= Number(props.data.daysTillDueDate) && Number(props.data.daysTillDueDate) > 3) {
      return (
        <span style={{ ...normalDueDaysStyle, color: '#000000' }}>
          {Number(props.data.daysTillDueDate)}
          <span style={{ ...SevenDaysIconStyle, color: '#ffbe2e' }}>
            <FontAwesomeIcon icon={faBell} />
          </span>
        </span>
      );
    }

    return <span style={normalDueDaysStyle}>{Number(props.data.daysTillDueDate)}</span>;
  };

  function printPageDisplayedRows(event) {
    // console.log('Testing => ', gridRef.current.api.getSelectedRecords());
    // console.log('Testing => ', gridRef.current.api.getCurrentViewRecords());
    var rowCount = event.api.getDisplayedRowCount();
    var lastGridIndex = rowCount - 1;
    var currentPage = event.api.paginationGetCurrentPage();
    var pageSize = event.api.paginationGetPageSize();
    var startPageIndex = currentPage * pageSize;
    var endPageIndex = (currentPage + 1) * pageSize - 1;

    if (endPageIndex > lastGridIndex) {
      endPageIndex = lastGridIndex;
    }

    const currentPageRows = [];
    for (var i = startPageIndex; i <= endPageIndex; i++) {
      var rowNode = event.api.getDisplayedRowAtIndex(i);
      currentPageRows.push(rowNode.data);
    }

    return currentPageRows;
  }

  function isFirstColumn(params) {
    console.log('params =>', printPageDisplayedRows(params));
    var displayedColumns = params.columnApi.getAllDisplayedColumns();
    var thisIsFirstColumn = displayedColumns[0] === params.column;
    console.log('thisIsFirstColumn =>', thisIsFirstColumn);
    return thisIsFirstColumn;
  }

  const resetPaginationSelection = (self) => {
    console.log('self =>', self);
    //Deselect previously selected rows to reset selection
    // self.api.deselectAll();

    //Initialize pagination data
    let paginationSize = self.api.paginationGetPageSize();
    let currentPageNum = self.api.paginationGetCurrentPage();
    let totalRowsCount = self.api.getDisplayedRowCount();

    //Calculate current page row indexes
    let currentPageRowStartIndex = currentPageNum * paginationSize;
    let currentPageRowLastIndex = currentPageRowStartIndex + paginationSize;
    if (currentPageRowLastIndex > totalRowsCount) currentPageRowLastIndex = totalRowsCount;

    for (let i = 0; i < totalRowsCount; i++) {
      //Set isRowSelectable=true attribute for current page rows, and false for other page rows
      let isWithinCurrentPage = i >= currentPageRowStartIndex && i < currentPageRowLastIndex;
      self.api.getDisplayedRowAtIndex(i).setRowSelectable(isWithinCurrentPage);
    }
  };

  const onGridReady = (params) => {
    // console.log("Params =>", params);
    // console.log("Gridref =>", gridRef);
    // console.log("params.current.api =>", params.current.api);
    params.api.addEventListener('paginationChanged', (e) => {
      //Reset rows selection based on current page
      resetPaginationSelection(params);
    });
  };

  const colDefs = [
    {
      headerCheckboxSelection: true,
      checkboxSelection: true,
      maxWidth: 40,
      showDisabledCheckboxes: true,
      headerCheckboxSelectionFilteredOnly: true,
      // headerComponent: CheckBox,

      // cellRendererFramework: CheckBox
      // headerCheckboxSelection: (params) => {
      //   const displayedColumns = params.columnApi.getAllDisplayedColumns();
      //   return displayedColumns[0] === params.column;
      // }
    },
    {
      field: 'action',
      headerName: 'Action',
      cellRendererFramework: ActionElements,
      maxWidth: 100,
      sortable: false,
      resizable: true,
      maxWidth: 120,
      cellClass: 'grid-cell-centered'
    },
    {
      field: 'document',
      headerName: 'Document',
      cellRendererFramework: DocumentElement,
      sortable: false,
      resizable: true,
      maxWidth: 120
    },
    {
      field: 'systemName',
      headerName: 'System',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150,
      tooltipField: 'systemName'
    },
    {
      field: 'applicationCode',
      headerName: 'App',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150,
      tooltipField: 'applicationName'
    },
    {
      field: 'accountManager',
      headerName: 'Account Manager',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150,
      tooltipField: 'accountManager'
    },
    {
      field: 'daysTillDueDate',
      headerName: 'Days Till Due',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 120,
      tooltipField: 'daysTillDueDate',
      cellRendererFramework: DaysTillDueElement,
      cellStyle: { textAlign: 'center', marginLeft: '-16px' }
    },

    {
      field: 'descriptionText',
      tooltipField: 'stateName',
      headerName: 'Current Task',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'certCoOrdinator',
      tooltipField: 'certCoOrdinator',
      headerName: 'Cert. Coordinator',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'cycleStartDate',
      tooltipField: 'cycleStartDate',
      headerName: 'Start Date',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150,
      cellStyle: { textAlign: 'center', marginLeft: '-16px' }
    },
    {
      field: 'dueDate',
      tooltipField: 'dueDate',
      headerName: 'Due Date',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150,
      cellStyle: { textAlign: 'center', marginLeft: '-16px' }
    }
  ];

  const paginationNumberFormatter = useCallback((params) => {
    return '[' + params.value.toLocaleString() + ']';
  }, []);

  const gridStyle = useMemo(() => ({ width: '100%' }), []);

  const statusBar = useMemo(() => {});

  const defaultColDef = useMemo(() => ({
    // sortable: true,
    flex: 1,
    //maxWidth: 160,
    resizable: true,
    floatingFilter: true,
    sortable: true,
    domLayout: 'autoHeight'
    // headerCheckboxSelection: isFirstColumn,
    // checkboxSelection: isFirstColumn
  }));

  const onSelectChange = (event) => {
    // gridRef.current.api.refreshHeader();
    // console.log('gridRef.current.api.getSelectedRows() => ', gridRef.current.api.getSelectedRows());
    dispatch(setSystemOwnerSelectData(gridRef.current.api.getSelectedRows()));
  };

  // Disable the Check Box for StateName is Completed
  const isRowSelectable = (props) => {
    return props?.data?.stateName !== ('Completed' || 'Certified');
  };

  const applyPageSizeSetByUser = useCallback((params) => {
    var value = document.getElementById('page-size').value;
    gridRef.current.api.paginationSetPageSize(Number(value));
  }, []);

  return (
    <div className="system-owner-page-layout-container">
      {}
      <div className="ag-theme-alpine" style={{ height: '100%', width: '100%' }}>
        <AgGridReact
          ref={gridRef}
          rowData={tableData}
          columnDefs={colDefs}
          defaultColDef={defaultColDef}
          rowSelection={'multiple'}
          suppressRowClickSelection={true}
          onSelectionChanged={onSelectChange}
          // onRowSelected={onRowSelectChange}
          pagination={true}
          paginationNumberFormatter={paginationNumberFormatter}
          suppressPaginationPanel={false}
          enableBrowserTooltips={true}
          isRowSelectable={isRowSelectable}
          onGridReady={onGridReady}
          // rowGroupPanelShow={"always"}
          // pivotPanelShow={"always"}
          // enableRangeSelection={true}
          // enableRangeHandle={true}
          // frameworkComponents={{
          //   PaginationComponent,
          //   PaginationStatusBar
          // }}
          // alwaysShowVerticalScroll={false}
          // suppressVerticalScroll={false}
          // rowBuffer={50}
          // statusBar={{
          //   statusPanels: [
          //     // { statusPanel: 'RefreshStatusBar', align: 'left' },
          //     // { statusPanel: 'agAggregationComponent', align: 'left' },
          //     { statusPanel: 'PaginationComponent' },
          //     { statusPanel: 'PaginationStatusBar' }
          //   ]
          // }}
          suppressHorizontalScroll={false}
          onFirstDataRendered={applyPageSizeSetByUser}
        ></AgGridReact>
      </div>
    </div>
  );

  // return (
  //   <>
  //     <TableWithFilter
  //       tableHead={tableHeadCols}
  //       tableData={filterTableData.length === 0 ? tableData : filterTableData}
  //       onSearchFilter={onSearch}
  //       ActionElement={ActionElement}
  //       DocumentElement={DocumentElement}
  //       setSelectValues={onSelect}
  //       selectedData={selectedData}
  //     />
  //   </>
  // );
};
