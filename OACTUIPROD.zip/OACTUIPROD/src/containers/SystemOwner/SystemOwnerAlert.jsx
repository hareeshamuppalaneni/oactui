import React from 'react';
import { useSelector } from 'react-redux';
import { Alert } from '@trussworks/react-uswds';
import { ACCOUNT_MANAGER_ALERT_ACTIONS } from 'labels';
import _ from 'underscore';

import './SystemOwner'

export default () => {
  const currentSystemOwnerState = useSelector((state) => state.systemOwner);
  const {  messageStatus, selectedData } =
  currentSystemOwnerState;

//   const AlertMessage = ({ status, message }) => {
//     return (
//       <Alert type={status ? 'success' : 'error'} headingLevel="h4" slim>
//         {message}
//       </Alert>
//     );
//   };

  return (
    <>
      {!_.isNull(messageStatus.status) ? (
        <Alert type={messageStatus.status ? 'success' : 'error'} headingLevel="h4" slim className="system-owner-alert-container">
          {messageStatus.message}
        </Alert>
      ) : null}
    </>
  );
};
