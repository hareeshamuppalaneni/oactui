import SubAccountManager from './SubAccountManager';

export default SubAccountManager;