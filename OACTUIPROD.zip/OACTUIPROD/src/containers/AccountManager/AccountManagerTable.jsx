import React, { useMemo, useCallback, useRef, useEffect } from 'react';
import { Table, TextInput, Icon } from '@trussworks/react-uswds';
import { useSelector, useDispatch } from 'react-redux';
import { TableWithFilter } from 'components';
import {
  setCurrentAction,
  setModalOpen,
  setSelectData,
  setGridApi,
  certifySingleUser,
  setUndoActionSelectedRows,
  setUndoActionModal
} from 'slices';
import { ACCOUNT_MANAGER_ALERT_ACTIONS } from 'labels';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faPenToSquare,
  faCheckCircle as solidCircle,
  faCog,
  faUndoAlt
} from '@fortawesome/free-solid-svg-icons';
import { faCheckCircle as regularCircle } from '@fortawesome/free-regular-svg-icons';

import { AgGridReact } from 'ag-grid-react';
// import 'ag-grid-enterprise';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import CheckBoxrender from './CheckBoxrender';
import PaginationComponent from './AccountManagerPagination';
import PaginationStatusBar from './PaginationStatusBar';
const Edit = Icon.Edit;

const ActionIconsStyle = {
  color: '#0075BF',
  cursor: 'pointer',
  marginLeft: '10px'
};

export default ({ gridRef }) => {
  const dispatch = useDispatch();
  const accountManagerState = useSelector((state) => state.accountManager);
  const { tableHeadCols, tableData, filterTableData, selectedData } = accountManagerState;
  const onSearch = (value, col) => {
    dispatch(onSearchTable(value, col));
  };

  function printPageDisplayedRows(event) {
    // console.log('Testing => ', gridRef.current.api.getSelectedRecords());
    // console.log('Testing => ', gridRef.current.api.getCurrentViewRecords());
    var rowCount = event.api.getDisplayedRowCount();
    var lastGridIndex = rowCount - 1;
    var currentPage = event.api.paginationGetCurrentPage();
    var pageSize = event.api.paginationGetPageSize();
    var startPageIndex = currentPage * pageSize;
    var endPageIndex = (currentPage + 1) * pageSize - 1;

    if (endPageIndex > lastGridIndex) {
      endPageIndex = lastGridIndex;
    }

    const currentPageRows = [];
    for (var i = startPageIndex; i <= endPageIndex; i++) {
      var rowNode = event.api.getDisplayedRowAtIndex(i);
      currentPageRows.push(rowNode.data);
    }

    return currentPageRows;

    console.log('const currentPageRows = []', currentPageRows);
  }

  const onSelectChange = (event) => {
    // event.api.refreshHeader();
    // console.log('OnChange Select => ', printPageDisplayedRows(event));
    // console.log('event.api.isFilterActive() => ', event);
    // // console.log('event.api.isFilterActive() => ', event.api.isFilterActive());
    // console.log('printPageDisplayedRows(event).length ', printPageDisplayedRows(event).length);
    // console.log('gridRef.current.api.getSelectedRows().length ',event.api.getSelectedRows().length);
    // gridRef.current.api.setSelectedRow = 10;
    // if (printPageDisplayedRows(event).length <= gridRef.current.api.getSelectedRows().length) {
    //   dispatch(setSelectData(printPageDisplayedRows(event)));
    // } else {
    //   dispatch(setSelectData(gridRef.current.api.getSelectedRows()));
    // };
    dispatch(setSelectData(gridRef.current.api.getSelectedRows()));
  };

  const onClickSingleEdit = (data) => {
    dispatch(setCurrentAction(ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_EDIT));
    dispatch(setSelectData([data]));
    dispatch(setModalOpen(true));
    // gridRef.current.api.deselectAll();
  };

  const onClickSingleNotify = (data) => {
    // dispatch(setCurrentAction(ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_CERTIFY));
    dispatch(setSelectData([data]));
    // dispatch(setModalOpen(true));
    // gridRef.current.api.deselectAll();
    dispatch(certifySingleUser(data));
  };

  const onClickSingleUndoAction = (data) => {
    dispatch(setUndoActionModal(true));
    dispatch(setSelectData([data]))
  }

  useEffect(() => {}, []);

  const ActionElements = (props) => {
    const RenderCertifiedIcon = () => {
      if (props?.data?.stateName === ('Completed' || 'Certified')) {
        return (
          <>
            <span
              className="certified-button-icon-container"
              style={{ marginLeft: '10px' }}
              title="Certified"
            >
              <FontAwesomeIcon icon={solidCircle} color={'green'} />
            </span>
            {/* <span
              style={ActionIconsStyle}
              onClick={() => onClickSingleEdit(props.data)}
              title="Edit User"
            >
              <FontAwesomeIcon icon={faPenToSquare} />
            </span> */}
            <span
              style={ActionIconsStyle}
              onClick={() => onClickSingleUndoAction(props.data)}
              title="Undo Certify Action"
            >
              <FontAwesomeIcon icon={faUndoAlt} />
            </span>
          </>
        );
      } else {
        return (
          <>
            <span
              style={ActionIconsStyle}
              onClick={() => onClickSingleNotify(props.data)}
              title="Pending"
            >
              <FontAwesomeIcon icon={regularCircle} />
            </span>
            <span
              style={ActionIconsStyle}
              onClick={() => onClickSingleEdit(props.data)}
              title="Edit User"
            >
              <FontAwesomeIcon icon={faPenToSquare} />
            </span>
          </>
        );
      }
    };
    return RenderCertifiedIcon();
  };

  // const isFirstColumn = (params) => {
  //   var displayedColumns = params.columnApi.getAllDisplayedColumns();
  //   var displayRows = params.rowApi.getAllDisplayedRows();
  //   var thisIsFirstColumn = displayedColumns[0] === params.column;
  //   return thisIsFirstColumn;
  // };

  const resetPaginationSelection = (self) => {
    console.log('self =>', self);
    //Deselect previously selected rows to reset selection
    // self.api.deselectAll();

    //Initialize pagination data
    let paginationSize = self.api.paginationGetPageSize();
    let currentPageNum = self.api.paginationGetCurrentPage();
    let totalRowsCount = self.api.getDisplayedRowCount();

    //Calculate current page row indexes
    let currentPageRowStartIndex = currentPageNum * paginationSize;
    let currentPageRowLastIndex = currentPageRowStartIndex + paginationSize;
    if (currentPageRowLastIndex > totalRowsCount) currentPageRowLastIndex = totalRowsCount;

    for (let i = 0; i < totalRowsCount; i++) {
      //Set isRowSelectable=true attribute for current page rows, and false for other page rows
      let isWithinCurrentPage = i >= currentPageRowStartIndex && i < currentPageRowLastIndex;
      self.api.getDisplayedRowAtIndex(i).setRowSelectable(isWithinCurrentPage);
    }
  };

  const onGridReady = (params) => {
    // console.log("Params =>", params);
    // console.log("Gridref =>", gridRef);
    // console.log("params.current.api =>", params.current.api);
    params.api.addEventListener('paginationChanged', (e) => {
      //Reset rows selection based on current page
      resetPaginationSelection(params);
    });
  };

  const colDefs = [
    {
      // field: 'selectAll',
      headerCheckboxSelection: true,
      checkboxSelection: true,
      maxWidth: 40,
      headerCheckboxSelectionFilteredOnly: true
      // headerCheckboxSelection: isFirstColumn,
      // checkboxSelection: isFirstColumn,
      // selectAllOnMiniFilter: true,
      // onClick: (params) => {
      //   console.log('Params =>', params);
      // }
      // cellRendererFramework: CheckBoxrender
    },
    {
      field: 'action',
      headerName: 'Action',
      cellRendererFramework: ActionElements,
      maxWidth: 100,
      sortable: true,
      minWidth: 100
    },
    {
      field: 'descriptionText',
      tooltipField: 'descriptionText',
      headerName: 'Task Status',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'applicationCode',
      headerName: 'App',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150,
      tooltipField: 'applicationName'
    },

    {
      field: 'firstName',
      headerName: 'First Name',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150,
      tooltipField: 'firstName'
    },
    {
      field: 'lastName',
      tooltipField: 'lastName',
      headerName: 'Last Name',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'officeName',
      tooltipField: 'officeName',
      headerName: 'Office',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'userType',
      tooltipField: 'userType',
      headerName: 'User Type',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'accountStatus',
      tooltipField: 'accountStatus',
      headerName: 'Account Status',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'lastLoginDate',
      tooltipField: 'lastLoginDate',
      headerName: 'Last Login Date',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'reviewResults',
      tooltipField: 'reviewResults',
      headerName: 'Review Result',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'userEmailAddress',
      tooltipField: 'userEmailAddress',
      headerName: 'User Email Address',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'accountCreationDate',
      tooltipField: 'accountCreationDate',
      headerName: 'Account Creation Date',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    },
    {
      field: 'comments',
      tooltipField: 'comments',
      headerName: 'Comments',
      filter: 'agTextColumnFilter',
      resizable: true,
      minWidth: 150
    }
  ];

  const defaultColDef = useMemo(() => ({
    // sortable: true,
    flex: 1,
    //maxWidth: 160,
    resizable: true,
    floatingFilter: true,
    sortable: true,
    domLayout: 'autoHeight',
    pagination: true
    // paginationAutoPageSize: true
  }));

  const paginationNumberFormatter = useCallback((params) => {
    return '[' + params.value.toLocaleString() + ']';
  }, []);
  const onPageSizeChanged = useCallback(() => {
    var value = document.getElementById('page-size').value;
    console.log('Page Number => ', value);
    gridRef.current.api.paginationSetPageSize(Number(value));
  }, []);

  const gridStyle = useMemo(() => ({ width: '100%' }), []);

  const statusBar = useMemo(() => {});



  useEffect(() => {
    dispatch(setGridApi(gridRef?.current?.api));
    // setAutoHeight();
  }, []);

  // auto height will get the grid to fill the height of the contents,   // so the grid div should have no height set, the height is dynamic.   document.querySelector('#myGrid').style.height = ''; }
  const applyPageSizeSetByUser = useCallback((params) => {
    var value = document.getElementById('page-size').value;
    gridRef.current.api.paginationSetPageSize(Number(value));
  }, []);

  return (
    <div className="account-manager-page-layout-container">
      {}
      <div className="ag-theme-alpine" style={{ height: '100%', width: '100%' }}>
        <AgGridReact
          ref={gridRef}
          rowData={tableData}
          columnDefs={colDefs}
          defaultColDef={defaultColDef}
          rowSelection={'multiple'}
          suppressRowClickSelection={true}
          onSelectionChanged={onSelectChange}
          pagination={true}
          paginationNumberFormatter={paginationNumberFormatter}
          suppressPaginationPanel={false}
          enableBrowserTooltips={true}
          onGridReady={onGridReady}
          // paginationAutoPageSize={true}
          // rowGroupPanelShow={"always"}
          // pivotPanelShow={"always"}
          // enableRangeSelection={true}
          // enableRangeHandle={true}
          // frameworkComponents={{
          //   PaginationComponent,
          //   PaginationStatusBar
          // }}
          // alwaysShowVerticalScroll={false}
          // suppressVerticalScroll={false}
          // rowBuffer={50}
          // statusBar={{
          //   statusPanels: [
          //     // { statusPanel: 'RefreshStatusBar', align: 'left' },
          //     // { statusPanel: 'agAggregationComponent', align: 'left' },
          //     { statusPanel: 'PaginationComponent' },
          //     { statusPanel: 'PaginationStatusBar' }
          //   ]
          // }}
          suppressHorizontalScroll={false}
          onFirstDataRendered={applyPageSizeSetByUser}
        ></AgGridReact>
      </div>
    </div>
  );

  // return (
  //   <>
  //     <TableWithFilter
  //       tableHead={tableHeadCols}
  //       tableData={filterTableData.length === 0 ? tableData : filterTableData}
  //       onSearchFilter={onSearch}
  //       ActionElement={ActionElement}
  //       setSelectValues={onSelect}
  //       selectedData={selectedData}
  //     />
  //   </>
  // );
};
