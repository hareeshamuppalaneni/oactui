import AccountManager from './AccountManager';

import { default as AccountManagerTable } from './AccountManagerTable';
export default AccountManager;