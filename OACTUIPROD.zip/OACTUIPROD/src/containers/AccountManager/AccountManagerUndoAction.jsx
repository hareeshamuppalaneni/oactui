import { Alert } from '@trussworks/react-uswds';
import React from 'react';

import { useSelector, useDispatch } from 'react-redux';
import { Modal, Button } from 'react-bootstrap';
import { setUndoActionModal, undoBulkUsers, undoSingleUser } from 'slices';

export default () => {
  const dispatch = useDispatch();
  const accountManagerState = useSelector((state) => state.accountManager);

  const selectedRows = accountManagerState.selectedData;

  const onCloseModal = () => {
    dispatch(setUndoActionModal(false));
  };

  const onClickProceedWithUndo = () => {
    if (selectedRows.length === 1) {
      dispatch(undoSingleUser(selectedRows[0]));
    } else {
      dispatch(undoBulkUsers());
    }

    dispatch(setUndoActionModal(false));
  };

  const RenderMessageText = () => {
    if (selectedRows.length === 1) {
      return `Are you sure you want to undo the Certify action for 1 User?`;
    } else {
      return `Are you sure you want to undo the certify action for all the ${selectedRows.length} Users`;
    }
  };

  return (
    <Modal show={accountManagerState.undoAction} onHide={() => onCloseModal()} centered>
      <Modal.Body>
        <Alert type="warning" heading="Warning" headingLevel="h4">
          {RenderMessageText()}
        </Alert>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={() => onCloseModal()}>
          {'Cancel'}
        </Button>
        <Button variant="primary" onClick={() => onClickProceedWithUndo()}>
          {'Proceed'}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};
