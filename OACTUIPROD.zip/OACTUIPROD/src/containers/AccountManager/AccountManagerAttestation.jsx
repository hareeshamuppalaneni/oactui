import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Button, Dropdown, GridContainer, Grid } from '@trussworks/react-uswds';
import { selectAttestation, fetchSignAttestation } from 'slices';
import { ACCOUNT_MANAGER_LABELS } from 'labels';
import underscore from 'underscore';

const buttonStyles = {
  justifyContent: 'center',
  display: 'flex',
  alignItems: 'center',
  borderRadius: '0px',
  height: '40px',
  margin: '0px',
  width: '100%'
};

export default () => {
  const dispatch = useDispatch();
  const currentAccountManagerState = useSelector((state) => state.accountManager);
  const { attestationList, selectedAttestation } = currentAccountManagerState;

  const selectApplication = (event) => {
    // We don't need to trigger onchange for default text
    if (event?.target?.value !== ACCOUNT_MANAGER_LABELS.DROPDOWN_LABEL) {
      dispatch(selectAttestation(JSON.parse(event?.target?.value)));
    } else {
      dispatch(selectAttestation({}));
    }
  };

  useEffect(() => {
    // Select by Default for single attestation
    if (attestationList.length === 1) {
      dispatch(selectAttestation(attestationList[0]));
    }
  }, [attestationList]);

  // Added Default Text based on the attestation length
  const dispatchDefaultTextForAttestation = () => {
    if (attestationList.length === 1) {
      return null;
    } else if (attestationList.length === 0) {
      return <option>{ACCOUNT_MANAGER_LABELS.NO_OPTION_FOR_DROPDOWN}</option>;
    } else {
      return <option>{ACCOUNT_MANAGER_LABELS.DROPDOWN_LABEL}</option>;
    }
  };

  return (
    <>
      <Grid row style={{ alignItems: 'baseline', marginBottom: '10px' }}>
        <Grid col={6}>
          <Dropdown onChange={(event) => selectApplication(event)}>
            {dispatchDefaultTextForAttestation()}
            {attestationList?.map((eachApplication, index) => {
              return (
                <option key={index} value={JSON.stringify(eachApplication)}>
                  {eachApplication?.cycleName}
                </option>
              );
            })}
          </Dropdown>
        </Grid>
        <Grid col={6}>
          <Button
            className="sign-certificate-button-container"
            disabled={underscore.isEmpty(selectedAttestation)}
            // disabled={underscore.isEmpty(selectedAttestation) && (attestationList.length > 1 || attestationList.length === 0)}
            onClick={() => dispatch(fetchSignAttestation())}
            style={buttonStyles}
          >
            {ACCOUNT_MANAGER_LABELS.BUTTON_TEXT}
          </Button>
        </Grid>
      </Grid>
    </>
  );
};
