import React, { useState } from "react";
// import { span, spanButton, Typography } from "@material-ui/core";

const PaginationStatusBar = ({ api }) => {
  const [pageSize, setPageSize] = useState(api.paginationGetPageSize());
  const [currentPage, setCurrentPage] = useState(
    api.paginationGetCurrentPage()
  );
  const [totalPage, setTotalPage] = useState(api.paginationGetTotalPages());
  const [rowCount, setRowCount] = useState(api.paginationGetRowCount());
  const [previousDisable, setPreviousDisable] = useState(true);
  const [previousColor, setPreviousColor] = useState("disabled");
  const [nextDisable, setNextDisable] = useState(false);
  const [nextColor, setNextColor] = useState("secondary");

  api.addEventListener("paginationChanged", (params) => {
    setPageSize(params.api.paginationGetPageSize());
    setCurrentPage(params.api.paginationGetCurrentPage());
    setTotalPage(params.api.paginationGetTotalPages());
    setRowCount(params.api.paginationGetRowCount());

    handlePagination();
  });

  const handlePagination = () => {
    if (api.paginationGetCurrentPage() === 0) {
      setPreviousDisable(true);
      setPreviousColor("disabled");
    } else {
      setPreviousDisable(false);
      setPreviousColor("secondary");
    }

    if (api.paginationGetCurrentPage() + 1 === api.paginationGetTotalPages()) {
      setNextDisable(true);
      setNextColor("disabled");
    } else {
      setNextDisable(false);
      setNextColor("secondary");
    }
  };

  return (
    <div className="flex item-center mr-0" style={{ height: "42px" }}>
      <div className="flex  items-center">
        <span className="mr-12">
          {currentPage * pageSize + 1} to{" "}
          {(currentPage + 1) * pageSize > rowCount
            ? rowCount
            : (currentPage + 1) * pageSize}{" "}
          of {rowCount}
        </span>

        <div
          size="small"
          disabled={previousDisable}
          onClick={() => api.paginationGoToFirstPage()}
        >
          <span color={previousColor}>first_page</span>
        </div>

        <div
          size="small"
          disabled={previousDisable}
          onClick={() => api.paginationGoToPreviousPage()}
        >
          <span color={previousColor}>chevron_left</span>
        </div>

        <span className="mx-8">
          Page {currentPage + 1} of {totalPage}
        </span>

        <div
          size="small"
          disabled={nextDisable}
          onClick={() => api.paginationGoToNextPage()}
        >
          <span color={nextColor}>chevron_right</span>
        </div>

        <div
          size="small"
          disabled={nextDisable}
          onClick={() => api.paginationGoToLastPage()}
        >
          <span color={nextColor}>last_page</span>
        </div>
      </div>
    </div>
  );
};

export default PaginationStatusBar;
