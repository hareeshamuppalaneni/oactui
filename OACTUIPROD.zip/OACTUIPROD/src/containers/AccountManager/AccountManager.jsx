import React, { useRef, useCallback } from 'react';
import { useSelector } from 'react-redux';
import { SubHeaderText } from 'components';
import Spinner from 'react-bootstrap/Spinner';
import AccountManagerTable from './AccountManagerTable';
import { Button, GridContainer, Grid } from '@trussworks/react-uswds';
import { IMAGES } from 'assets';
import { Container, Row, Col } from 'react-bootstrap';
import BulkActions from './AccountManagerBulkActions';
import AttestationContainer from './AccountManagerAttestation';
import RenderAlertMessage from './AccountManagerAlert';
import './AccountManager.css';
import EditModal from './AccountManagerModal';
import AccountManagerUndoAction from './AccountManagerUndoAction';

export default () => {
  const gridRef = useRef();
  const accountManagerData = useSelector((state) => state.accountManager);
  const userDetailsState = useSelector((state) => state.userDetail);

  /**
   * We don't need the attestation for Sub Account Manager
   * @returns
   */
  const RenderAttestation = () => {
    if (new Set(userDetailsState.userRoles).has('AM')) {
      return <AttestationContainer />;
    } else {
      return null;
    }
  };

  const spinnerStyle = {
    marginLeft: '45%',
    marginRight: '45%',
    marginTop: '5%',
    marginBottom: '5%'
  };

  const onPageSizeChanged = useCallback(() => {
    var value = document.getElementById('page-size').value;
    console.log('Page Number => ', value);
    gridRef.current.api.paginationSetPageSize(Number(value));
  }, []);
  return (
    <>
      <div style={{ margin: `auto auto`, width: `95%` }}>
        <div>
          <Grid row>
            <Grid col={10}>
              <SubHeaderText text={'Account Manager'} />
            </Grid>
            <Grid col={2}>
              <Row>
                <Col md={{ span: 2, offset: 4 }}>
                  <img className="oact__logo-img" alt="img alt text" src={IMAGES.MAIN_OACT_LOGO} />
                </Col>
              </Row>
            </Grid>
          </Grid>
          <RenderAlertMessage />
          <Grid row style={{ marginBottom: '-15px' }}>
            <Grid col={4} className="account-manager-bulk-action-container" style={{ marginBottom: '-20px' }}>
              <BulkActions gridRef={gridRef} />
            </Grid>
            <Grid col={6}>{RenderAttestation()}</Grid>
            <Grid col={2} style={{ marginTop: 'auto', marginBottom: '-10px' }}>
              <div className="example-header">
                Page Size:&nbsp;
                <select onChange={onPageSizeChanged} id="page-size">
                  <option value="10" >
                    10
                  </option>
                  <option value="25">25</option>
                  <option value="50">50</option>
                  <option value="100" selected={true}>100</option>
                </select>
              </div>
            </Grid>
          </Grid>
        </div>
        <EditModal />
        <AccountManagerUndoAction />
      </div>
      {accountManagerData.loading ? (
        <Spinner animation="border" role="status" style={spinnerStyle}>
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      ) : (
        // <div className="App usa-banner__inner" style={{ display: 'block' }}>
        <AccountManagerTable gridRef={gridRef} />
        // </div>
      )}
    </>
  );
};
