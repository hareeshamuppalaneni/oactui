import SystemAdmin from './SystemAdmin';

export default SystemAdmin;