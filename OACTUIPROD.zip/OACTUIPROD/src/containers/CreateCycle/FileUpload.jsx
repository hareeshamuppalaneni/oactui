import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { uploadFileForCreateCycle } from 'slices'


/**
 * @author Skietech Development Team
 * @param {Int8Array} myRowIndex - Current Index of the File Upload Component
 * @returns
 */
const RenderFileUpload = ({ myRowIndex }) => {
//const RenderFileUpload = (props) => {
//     let myRowIndex = props.two.rowIndex;
    //alert("***** level 2: myRowIndex="+myRowIndex);
    //debugger;
    const applicationOptions = useSelector((state) => state.createCycle.applications.options);
    const fileObject = applicationOptions[myRowIndex]?.fileObject;
    const dispatch = useDispatch();

    const airaLabel = `You have selected the file: ${fileObject?.fileName}`;

    const dispatchOnUpload = (event) => {
        event.preventDefault();
        dispatch(uploadFileForCreateCycle(event.target.files, myRowIndex))
    }

    if (fileObject?.success) {
        return (
            <div className="usa-file-input">
                <div className="usa-file-input__target">
                    <div className="usa-file-input__preview-heading">Selected file
                        <span className="usa-file-input__choose">Change file</span>
                    </div><div className="usa-file-input__instructions display-none" aria-hidden="true">
                        <span className="usa-file-input__drag-text">Drag file here or </span>
                        <span className="usa-file-input__choose">choose from folder</span>
                    </div>
                    <div className="usa-file-input__preview" aria-hidden="true">
                        <img id="img_userdataimg_template__2exlsx-1666201229"
                            src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                            alt="" className="usa-file-input__preview-image usa-file-input__preview-image--excel" />
                        {fileObject?.fileName}
                        <div>
                        </div>
                    </div>
                    <div className="usa-file-input__box"></div>
                    <input id="file-input-single" className="usa-file-input__input" type="file" name="file-input-single" aria-live="polite"
                        aria-label={airaLabel} data-default-aria-label="No file selected"
                        onChange={(event) => dispatchOnUpload(event)} />
                </div>
            </div>
        )
    }

    else if (fileObject?.error) {
        return (
            <div className="usa-form-group usa-form-group--error">
                <span className="usa-error-message" id="file-input-error-alert">File Not Suppoted or Have some errors </span>
                <div className="usa-file-input"><div className="usa-file-input__target">
                    <div className="usa-file-input__instructions" aria-hidden="true">
                        <span className="usa-file-input__drag-text">Drag file here or </span>
                        <span className="usa-file-input__choose">choose from folder</span>
                    </div><div className="usa-file-input__box">
                    </div>
                    <input id="file-input-error" className="usa-file-input__input"
                        type="file" name="file-input-error" aria-describedby="file-input-error-hint"
                        aria-live="polite" aria-label="No file selected" data-default-aria-label="No file selected"
                        onChange={(event) => dispatchOnUpload(event)} />
                </div>
                </div>
            </div>
        )
    }
    else {
        return (
            <div data-testid="file-input" className="usa-file-input"><div data-testid="file-input-droptarget" className="usa-file-input__target">
                <div data-testid="file-input-instructions" className="usa-file-input__instructions" aria-hidden="true">
                    <span className="usa-file-input__drag-text">Drag file here or </span><span className="usa-file-input__choose">choose from folder</span>
                </div><div data-testid="file-input-box" className="usa-file-input__box">
                </div>
                <input type="file" data-testid="file-input-input" name="file-input-single" id="file-input-single" className="usa-file-input__input"
                    onChange={(event) => dispatchOnUpload(event)}
                />
            </div>
            </div>
        )
    }

};

export default RenderFileUpload;
