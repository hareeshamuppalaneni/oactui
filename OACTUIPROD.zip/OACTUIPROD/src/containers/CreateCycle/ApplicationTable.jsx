import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FileUploadComponent from "./FileUpload";

const RenderApplicationTable = () => {
  const applicationOptions = useSelector(
    (state) => state.createCycle.applications.options
  );
  if (applicationOptions.length > 0) {
    return applicationOptions.map((eachApplicationDetails, index) => {
      if (eachApplicationDetails.application != undefined) {
        const name = eachApplicationDetails.application.name;
        const systemOwner = eachApplicationDetails.systemOwner;
        const certCoordinator = eachApplicationDetails.certCoOrdinator;
        const accountManager = eachApplicationDetails.accountManager;
        const subaccountManager = eachApplicationDetails.subaccountManager;

        return (
          <tr key={index}>
            <td>{name}</td>
            <td>{systemOwner}</td>
            <td>{certCoordinator}</td>
            <td>{accountManager}</td>
            <td>{subaccountManager}</td>
            <td
              style={{
                width: "399px",
              }}
            >
              <FileUploadComponent currentIndex={index} />
            </td>
          </tr>
        );
      } else {
        return null;
      }
    });
  }
};

export default RenderApplicationTable;
