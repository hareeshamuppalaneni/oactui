import { createSlice } from '@reduxjs/toolkit';

import { getLoggedInUserDetails } from 'services';
import { checkUserRoleMapper } from 'utils';

const initialUserDetailsState = {
  userInformation: {
    employeeNumber: '',
    firstName: '',
    lastName: '',
    loginId: ''
  },
  roleInformation: [],
  userRoles: [],
  localUser: ''
};

export const loggedInUserDetailSlice = createSlice({
  name: 'loggedInUserdetails',
  initialState: initialUserDetailsState,
  reducers: {
    fetchLoggedInUserDetails: (state, action) => {
      return {
        ...state,
        userInformation: action.payload.userInformation,
        roleInformation: action.payload.roleInformation
      };
    },
    setUserRoles: (state, action) => {
      state.userRoles = action.payload;
    },
    setLocalUser: (state, action) => {
      return {
        ...state,
        localUser: action.payload
      };
    }
  }
});

// Action creators are generated for each case reducer function
export const { fetchLoggedInUserDetails, setUserRoles, setLocalUser } =
  loggedInUserDetailSlice.actions;

// Middleware to call APIs and dispatch Redux actions
export const fetchUserDetail = (emailAddress) => async (dispatch, getState) => {
  const userDetail = await getLoggedInUserDetails(emailAddress);
  // const { userInformation, roleInformation } = userDetail;
  dispatch(setUserRoles(checkUserRoleMapper(userDetail?.roleInformation)));
  dispatch(fetchLoggedInUserDetails(userDetail));

  console.log("USer details iN LoggdIn =>", userDetail)
};

export const fetchAuthModule = () => async (dispatch, getState) => {
  const loginAuthModuleResponse = await getLoginEmailAddress();
  return loginAuthModuleResponse;
};

export default loggedInUserDetailSlice.reducer;
