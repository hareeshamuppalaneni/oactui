import { createSlice } from '@reduxjs/toolkit';
import FileDownload from 'js-file-download';

import {
  getSystemOwnerData,
  postAttestationList,
  downloadExcelFile,
  downloadAttestPDFFile
} from 'services';
import { checkUserRoleMapper, parseSystemOwnerTable } from 'utils';
import { filterSystemOwner } from 'utils/systemOwner';

const initialSystemOwnerState = {
  tableHeadCols: [
    'Action',
    'Documents (ADD)',
    'System',
    'Application',
    'Account Manager',
    'Days till Due',
    'Current Task',
    'Certification Coordinator',
    'Start Date',
    'Due Date'
  ],
  filterCol: ['Action', 'Documents (ADD)'],
  tableData: [],
  filterTableData: [],
  loading: true,
  selectedData: [],
  selectAll: false,
  messageStatus: {
    status: null,
    message: ''
  }
};

export const systemOwnerSlice = createSlice({
  name: 'systemOwner',
  initialState: initialSystemOwnerState,
  reducers: {
    setSystemOwnerTableData: (state, action) => {
      state.tableData = action.payload;
      state.filterTableData = action.payload;
    },
    setSystemOwnerFilterData: (state, action) => {
      state.filterTableData = action.payload;
    },
    setSystemOwnerLoading: (state, action) => {
      state.loading = action.payload;
    },
    setSystemOwnerSelectData: (state, action) => {
      state.selectedData = [...action.payload];
    },
    setSystemOwnerSelectAll: (state, action) => {
      state.selectAll = !state.selectAll;
    },
    setSystemOwnerMessageStatus: (state, action) => {
      state.messageStatus = action.payload;
    }
  }
});

// Action creators are generated for each case reducer function
export const {
  setSystemOwnerTableData,
  setSystemOwnerFilterData,
  setSystemOwnerLoading,
  setSystemOwnerSelectData,
  setSystemOwnerSelectAll,
  setSystemOwnerMessageStatus
} = systemOwnerSlice.actions;

// Middleware to call APIs and dispatch Redux actions
export const fetchSystemOwnerTableDetails = (emailAddress) => async (dispatch, getState) => {
  dispatch(setSystemOwnerLoading(true));
  const currentState = getState();
  const { systemOwner } = currentState;
  const tableDetails = await getSystemOwnerData(emailAddress);
  const parseData = parseSystemOwnerTable(tableDetails);
  dispatch(setSystemOwnerTableData(parseData));
  dispatch(setSystemOwnerLoading(false));
  // const finalCols = JSON.parse(JSON.stringify(systemOwner.tableHeadCols)).filter(item => !systemOwner.filterCol.includes(item));
  // // console.log('Response in Redux Middleware finalCols', finalCols);
  // const filterData = tableDetails.map((eachRow, index) => {
  //   return filterSystemOwner(eachRow, finalCols);
  // });

  // dispatch(setSystemOwnerTableData(filterData));
  // dispatch(setSystemOwnerLoading(false));
};

export const certifyBulkSystemOwner = () => async (dispatch, getState) => {
  const currentState = getState();
  const emailAddress = currentState?.userDetail?.userInformation?.loginId;
  const currentSystemOwnerState = currentState?.systemOwner;

  try {
    let cycleIdList = [];
    for await (const data of currentSystemOwnerState.selectedData) {
      cycleIdList.push(data.certificationCycleId);
    }
    console.log('cycleIdList data =>', cycleIdList);

    const constructBody = {
      cycleId: cycleIdList,
      emailId: emailAddress
    };
    const response = await postAttestationList(constructBody);

    dispatch(
      setSystemOwnerMessageStatus({
        status: true,
        message: `Successfully Certified ${constructBody.length} Cycle`
      })
    );
  } catch (error) {
    dispatch(
      setSystemOwnerMessageStatus({
        status: false,
        message: `${error?.response?.data?.message}: Failed to Certify ${currentSystemOwnerState.length} Cycle`
      })
    );
  }

  dispatch(resetSystemOwnerData());
};

export const certifySingleSystemOwner = (data) => async (dispatch, getState) => {
  const currentState = getState();
  const emailAddress = currentState?.userDetail?.userInformation?.loginId;
  const currentSystemOwnerState = currentState?.systemOwner;

  try {
    const response = await postAttestationList({
      cycleId: [data?.certificationCycleId],
      emailId: emailAddress
    });

    dispatch(
      setSystemOwnerMessageStatus({
        status: true,
        message: `Successfully Certified 1 Cycle`
      })
    );
  } catch (error) {
    dispatch(
      setSystemOwnerMessageStatus({
        status: false,
        message: `${error?.response?.data?.message}: Failed to Certify 1 Cycle`
      })
    );
  }

  dispatch(resetSystemOwnerData());
};

export const resetSystemOwnerData = () => async (dispatch, getState) => {
  const currentState = getState();
  const emailAddress = currentState?.userDetail?.userInformation?.loginId;
  dispatch(fetchSystemOwnerTableDetails(emailAddress));
  setTimeout(() => {
    dispatch(setSystemOwnerMessageStatus({ status: null, message: '' }));
  }, 3000);

  dispatch(setSystemOwnerSelectData([]));
};

export const onClickDownloadAttestPDFFile = (data) => async (dispatch, getState) => {
  try {
    const fileData = await downloadAttestPDFFile({ cycleId: data.certificationCycleId });
    FileDownload(fileData, 'attest.pdf');
    dispatch(
      setSystemOwnerMessageStatus({
        status: true,
        message: `Successfully Downloaded attested file for :${data.name}`
      })
    );
  } catch (error) {
    dispatch(
      setSystemOwnerMessageStatus({
        status: false,
        message: `Failed downloading attested file for :${data.name}  and Error: ${error}`
      })
    );
  }

  setTimeout(() => {
    dispatch(setSystemOwnerMessageStatus({ status: null, message: '' }));
  }, 3000);
};

export const onClickDownloadExcelFile = (data) => async (dispatch, getState) => {
  console.log('Props Data', data);
  try {
    const fileData = await downloadExcelFile({ cycleId: data.certificationCycleId });
    FileDownload(fileData, data.name+'.xlsx');
    dispatch(
      setSystemOwnerMessageStatus({
        status: true,
        message: `Successfully Downloaded Excel file for :${data.name}`
      })
    );
  } catch (error) {
    dispatch(
      setSystemOwnerMessageStatus({
        status: false,
        message: `Failed downloading Excel file for :${data.name}`
      })
    );
  }

  setTimeout(() => {
    dispatch(setSystemOwnerMessageStatus({ status: null, message: '' }));
  }, 3000);
};

export const searchSystemOwnerTable = (text, field) => async (dispatch, getState) => {
  console.log('Values => ', text, field);
  const currentState = getState();
  const currentSystemOwnerState = currentState.systemOwner;
  const { filterTableData, tableData } = currentSystemOwnerState;
  const currentTableData =
    JSON.parse(JSON.stringify(filterTableData)) || JSON.parse(JSON.stringify(tableData));
  const currentKey = Object.keys(currentTableData[0])[field];
  const filteredData = [];
  if (text === '') {
    dispatch(setSystemOwnerFilterData(tableData));
  } else {
    for await (const [index, eachRow] of currentTableData.entries()) {
      if (eachRow[currentKey].toLowerCase().startsWith(text.toLowerCase())) {
        filteredData.push(eachRow);
      }
    }
    dispatch(setSystemOwnerFilterData(filteredData));
  }
};

export const onSelectSystemOwnerRow = (index) => async (dispatch, getState) => {
  const currentState = getState();
  const currentSystemOwnerState = currentState.systemOwner;
  const { filterTableData, tableData } = currentSystemOwnerState;
  const currentTableData = JSON.parse(JSON.stringify(filterTableData));
  const { selectAll, selectedData } = currentSystemOwnerState;
  if (Array.isArray(index)) {
    const selectedValues = {};
    for await (const [index, values] of currentTableData.entries()) {
      selectedValues[index] = !selectAll;
    }
    dispatch(setSystemOwnerSelectData(selectedValues));
    dispatch(setSystemOwnerSelectAll());
  } else {
    const currentSelectedData = JSON.parse(JSON.stringify(selectedData));
    dispatch(
      setSystemOwnerSelectData({
        ...currentSelectedData,
        [index]: currentSelectedData[index] ? false : true
      })
    );
  }
};

export default systemOwnerSlice.reducer;
