import { createSlice } from '@reduxjs/toolkit';
import { filterAccountManager, parseAccountManagerTable } from 'utils';
import { ACCOUNT_MANAGER_ALERT_ACTIONS, ACCOUNT_MANAGER_SUCCESS_LABELS } from 'labels';
import {
  getLoggedInUserDetails,
  getAccountManagerTableData,
  getAttestationList,
  postAttestationList,
  editAccountManager,
  certifyAccountManager,
  undoActionAccountManager
} from 'services';
import Cookies from 'js-cookie';
import { fetchUserDetail } from 'slices';

// const mockData = [
//   {
//     action: null,
//     certified: 'Certified',
//     cycle: 'OSHA Semi Annual',
//     application: 'ITA',
//     firstName: 'Johnathan',
//     lastName: 'Smith',
//     middleName: 'C',
//     emailAddress: 'jsmith@dol.gov',
//     userId: 'jsmith',
//     userType: 'Previlged',
//     accountType: 'Application',
//     accountCreationDate: '10/10/2021 22:10',
//     lastLoginDate: '11/10/2021 10:10',
//     accountStatus: 'Active',
//     reviewStatus: 'No Action',
//     comments: '',
//     agency: 'OSHA',
//     office: 'DTSEM',
//     system: 'ITA',
//     systemOwner: 'Chris Cane',
//     certificationCoordinator: 'Chris Cane',
//     accountManager: 'Johnathan Smith',
//     subAccountManager: 'Johnathan Smith'
//   },
//   {
//     action: null,
//     certified: 'Certified',
//     cycle: 'OSHA Semi Annual',
//     application: 'ITA',
//     firstName: 'Johnathan',
//     lastName: 'Smith',
//     middleName: 'C',
//     emailAddress: 'jsmith@dol.gov',
//     userId: 'jsmith',
//     userType: 'Previlged',
//     accountType: 'Application',
//     accountCreationDate: '10/10/2021 22:10',
//     lastLoginDate: '11/10/2021 10:10',
//     accountStatus: 'Active',
//     reviewStatus: 'No Action',
//     comments: '',
//     agency: 'OSHA',
//     office: 'DTSEM',
//     system: 'ITA',
//     systemOwner: 'Chris Cane',
//     certificationCoordinator: 'Chris Cane',
//     accountManager: 'Johnathan Smith',
//     subAccountManager: 'Johnathan Smith'
//   },
//   {
//     action: null,
//     certified: 'Certified',
//     cycle: 'OSHA Semi Annual',
//     application: 'ITA',
//     firstName: 'Johnathan',
//     lastName: 'Smith',
//     middleName: 'C',
//     emailAddress: 'jsmith@dol.gov',
//     userId: 'jsmith',
//     userType: 'Previlged',
//     accountType: 'Application',
//     accountCreationDate: '10/10/2021 22:10',
//     lastLoginDate: '11/10/2021 10:10',
//     accountStatus: 'Active',
//     reviewStatus: 'No Action',
//     comments: '',
//     agency: 'OSHA',
//     office: 'DTSEM',
//     system: 'ITA',
//     systemOwner: 'Chris Cane',
//     certificationCoordinator: 'Chris Cane',
//     accountManager: 'Johnathan Smith',
//     subAccountManager: 'Johnathan Smith'
//   }
// ];

const initialState = {
  // tableHeadCols: [
  //   'Action',
  //   'Certified',
  //   'Cycle',
  //   'Application',
  //   'First Name',
  //   'Last Name',
  //   'M.I.',
  //   'Email Address',
  //   'User ID',
  //   'User Type',
  //   'Account Type',
  //   'Account Creation Date',
  //   'Last Login Date',
  //   'Account Status',
  //   'Review Results',
  //   'Comments',
  //   'Agency',
  //   'Office',
  //   'System',
  //   'System Owner',
  //   'Certification Coordinator',
  //   'Account Manager',
  //   'Sub-Account Manager'
  // ],
  tableHeadCols: [
    'Action',
    'Application Name',
    'First Name',
    'Last Name',
    'Office',
    'Account Status',
    'User Type',
    'Last Login Date',
    'Review Result',
    'User Email Address',
    'Account Creation Date',
    'Comments'
  ],
  filterCol: ['Action'],
  tableData: [],
  filterTableData: [],
  loading: true,
  attestationList: [],
  selectedAttestation: {},
  messageStatus: {
    status: null,
    message: ''
  },
  openModal: false,
  editModal: {
    selectedStatus: '',
    comments: ''
  },
  currentAction: null,
  selectedData: [],
  selectAll: false,
  gridApi: null,
  undoAction: false,
  undoActionSelectedRows: []
};

export const accountManagerSlice = createSlice({
  name: 'accountManager',
  initialState: initialState,
  reducers: {
    setTableData: (state, action) => {
      state.tableData = action.payload;
      state.filterTableData = action.payload;
    },
    setFilterData: (state, action) => {
      state.filterTableData = action.payload;
    },
    setLoading: (state, action) => {
      state.loading = action.payload || false;
    },
    setAttestationList: (state, action) => {
      state.attestationList = action.payload;
    },
    selectAttestation: (state, action) => {
      state.selectedAttestation = action.payload;
    },
    setMessageStatus: (state, action) => {
      state.messageStatus = action.payload;
    },
    setModalOpen: (state, action) => {
      state.openModal = action.payload;
    },
    setEditModalStatus: (state, action) => {
      state.editModal.selectedStatus = action.payload;
    },
    setEditModalComments: (state, action) => {
      state.editModal.comments = action.payload;
    },
    setCurrentAction: (state, action) => {
      state.currentAction = action.payload;
    },
    setSelectData: (state, action) => {
      state.selectedData = [...action.payload];
      // state.selectedData = { ...action.payload };
    },
    setSelectAll: (state, action) => {
      state.selectAll = !state.selectAll;
    },
    setGridApi: (state, action) => {
      state.gridApi = action.payload;
    },
    setUndoActionModal: (state, action) => {
      state.undoAction = action.payload;
    },
    setUndoActionSelectedRows: (state, action) => {
      state.undoActionSelectedRows = action.payload;
    }
  }
});

// Action creators are generated for each case reducer function
export const {
  setTableData,
  setFilterData,
  setLoading,
  setAttestationList,
  selectAttestation,
  setMessageStatus,
  setEditModalStatus,
  setEditModalComments,
  setCurrentAction,
  setSelectData,
  setSelectAll,
  setModalOpen,
  setGridApi,
  setUndoActionModal,
  setUndoActionSelectedRows
} = accountManagerSlice.actions;

export const getAllApplicationAttestList = (currentUser) => async (dispatch, getState) => {
  dispatch(setAttestationList([]));
  dispatch(selectAttestation({}));
  const currentState = getState();
  const emailAddress = currentState?.userDetail?.userInformation?.loginId;
  const applicationList = await getAttestationList(currentUser || emailAddress);
  dispatch(setAttestationList(applicationList));
};

export const fetchAccountManagerTableDetails = (emailAddress) => async (dispatch, getState) => {
  const currentState = getState();
  const { userDetail, accountManager } = currentState;
  dispatch(setLoading(true));

  try {
    // await dispatch(fetchUserDetail(currentUser));
    const tableDetails = await getAccountManagerTableData(
      emailAddress || userDetail?.userInformation?.loginId
    );
    const parsedData = parseAccountManagerTable(tableDetails);
    dispatch(setTableData(parsedData));
    dispatch(setLoading(false));
  } catch (error) {
    dispatch(
      setMessageStatus({
        status: false,
        message: `${error?.response?.data?.message}: Failed to load the Table Data`
      })
    );
    dispatch(setTableData([]));
    dispatch(setLoading(false));
    setTimeout(() => {
      dispatch(setMessageStatus({ status: null, message: '' }));
    }, 3000);
  }

  const filteredUserRoles = new Set([...userDetail?.userRoles]);
  console.log('USer Details => ', userDetail);
  // if (filteredUserRoles.has('AM')) {
  dispatch(getAllApplicationAttestList(emailAddress || userDetail?.userInformation?.loginId));
  // }
};

export const fetchSignAttestation = () => async (dispatch, getState) => {
  const currentState = getState();
  const emailAddress = currentState?.userDetail?.userInformation?.loginId;
  const currentAccountManagerState = currentState?.accountManager;
  const { selectedAttestation } = currentAccountManagerState;

  dispatch(setCurrentAction(ACCOUNT_MANAGER_ALERT_ACTIONS.ATTESTATION));

  let message = selectedAttestation.cycleName;

  try {
    const response = await postAttestationList({
      cycleId: [selectedAttestation?.cycleId],
      emailId: emailAddress
    });
    dispatch(
      setMessageStatus({
        status: true,
        message: 'Successfully Attestation Process Completed for: ' + message
      })
    );
  } catch (error) {
    dispatch(
      setMessageStatus({ status: false, message: `${error?.response?.data?.message}: ${message}` })
    );
  }

  dispatch(resetAccountManagerData());
};

export const checkForSelectedRows = () => async (dispatch, getState) => {
  const currentState = getState();
  const { accountManager } = currentState;

  if (accountManager.selectedData.length === 0) {
    dispatch(
      setMessageStatus({
        status: false,
        message: `Please select at least one data`
      })
    );
    setTimeout(() => {
      dispatch(setMessageStatus({ status: null, message: '' }));
    }, 3000);
  }
};

export const resetAccountManagerData = () => async (dispatch, getState) => {
  const currentState = getState();
  const userDetails = currentState?.userDetail;
  dispatch(fetchAccountManagerTableDetails(userDetails.emailAddress));
  dispatch(setSelectData([]));
  dispatch(setEditModalStatus(''));
  dispatch(setEditModalComments(''));
  dispatch(setModalOpen(false));
  setTimeout(() => {
    dispatch(setMessageStatus({ status: null, message: '' }));
  }, 3000);
};

export const resetEditModalData = () => async (dispatch, getState) => {
  const currentState = getState();
  const currentAccountManagerState = currentState?.accountManager;
  // currentAccountManagerState?.gridRef?.deselectAll();
  setTimeout(() => {
    dispatch(setMessageStatus({ status: null, message: '' }));
  }, 5000);
  dispatch(selectAttestation({}));
  dispatch(setSelectData([]));
  dispatch(setEditModalStatus(''));
  dispatch(setEditModalComments(''));
  dispatch(setModalOpen(false));
};

export const updateReviewStatus = () => async (dispatch, getState) => {
  const currentState = getState();
  const currentAccountManagerState = currentState?.accountManager;

  if (currentAccountManagerState.selectedData.length === 0) {
    dispatch(checkForSelectedRows());
  } else {
    try {
      const constructBody = currentAccountManagerState.selectedData.map((eachRow) => {
        return {
          cycleItemId: eachRow.cycleItemId,
          reviewComments: currentAccountManagerState?.editModal?.comments,
          reviewStatus: currentAccountManagerState?.editModal?.selectedStatus,
          editOnly: true
        };
      });
      console.log('ConstructBody => ', constructBody);
      const response = await editAccountManager(constructBody);
      dispatch(
        setMessageStatus({
          status: true,
          message: ACCOUNT_MANAGER_SUCCESS_LABELS[ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_EDIT].TEXT
        })
      );
    } catch (error) {
      dispatch(
        setMessageStatus({
          status: false,
          message: `Editing Users Failed: ${error?.response?.data?.message}`
        })
      );
    }
    // dispatch(fetchAccountManagerTableDetails());
    dispatch(resetAccountManagerData());
  }
};

export const certifyUsers = () => async (dispatch, getState) => {
  const currentState = getState();
  const currentAccountManagerState = currentState?.accountManager;

  if (currentAccountManagerState.selectedData.length === 0) {
    dispatch(checkForSelectedRows());
  } else {
    try {
      const constructBody = currentAccountManagerState.selectedData.map((eachRow) => {
        return {
          cycleItemId: eachRow.cycleItemId,
          reviewComments: '',
          reviewStatus: 'No Action',
          editOnly: false
        };
      });
      console.log('ConstructBody => ', constructBody);
      const response = await certifyAccountManager(constructBody);

      dispatch(
        setMessageStatus({
          status: true,
          message:
            ACCOUNT_MANAGER_SUCCESS_LABELS[ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_CERTIFY].TEXT +
            constructBody.length +
            ' Users'
        })
      );
    } catch (error) {
      dispatch(
        setMessageStatus({
          status: false,
          message: `Certifying Failed: ${error?.response?.data?.message}`
        })
      );
    }

    // dispatch(fetchAccountManagerTableDetails());
    dispatch(resetAccountManagerData());
  }
};

export const certifySingleUser = (data) => async (dispatch, getState) => {
  try {
    const constructBody = [
      {
        cycleItemId: data.cycleItemId,
        reviewComments: '',
        reviewStatus: 'No Action',
        editOnly: false
      }
    ];
    console.log('ConstructBody => ', constructBody);
    const response = await certifyAccountManager(constructBody);

    dispatch(
      setMessageStatus({
        status: true,
        message:
          ACCOUNT_MANAGER_SUCCESS_LABELS[ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_CERTIFY].TEXT +
          constructBody.length +
          ' User'
      })
    );
  } catch (error) {
    dispatch(
      setMessageStatus({
        status: false,
        message: `Certifying Failed: ${error?.response?.data?.message}`
      })
    );
  }

  // dispatch(fetchAccountManagerTableDetails());
  dispatch(resetAccountManagerData());
};

export const undoSingleUser = (data) => async (dispatch, getState) => {
  try {
    const currentState = getState();
    const { userDetail, accountManager } = currentState;

    const constructBody = {
      email: userDetail?.userInformation?.loginId || Cookies.get('localUser'),
      itemsList: [accountManager.selectedData[0].cycleItemId]
    };

    console.log('ConstructBody => ', constructBody);
    const response = await undoActionAccountManager(constructBody);

    dispatch(
      setMessageStatus({
        status: true,
        message: `Successfully completed the undo Certify action for the user: ${data.firstName} ${data.lastName} and Application: ${data.applicationName}`
      })
    );
  } catch (error) {
    dispatch(
      setMessageStatus({
        status: false,
        message: `Undo action Failed: ${error?.response?.data?.message}`
      })
    );
  }

  dispatch(resetAccountManagerData());
};

export const undoBulkUsers = () => async (dispatch, getState) => {
  const currentState = getState();
  const { userDetail, accountManager } = currentState;
  if (accountManager.selectedData.length === 0) {
    dispatch(checkForSelectedRows());
  } else {
    try {
      const cycledIdList = [];

      for await (const rows of accountManager.selectedData) {
        cycledIdList.push(rows.cycleItemId);
      }

      const constructBody = {
        email: userDetail?.userInformation?.loginId || Cookies.get('localUser'),
        itemsList: cycledIdList
      };

      console.log('ConstructBody => ', constructBody);
      const response = await undoActionAccountManager(constructBody);

      dispatch(
        setMessageStatus({
          status: true,
          message: `Successfully completed the undo Certify action for all the ${cycledIdList.length} users`
        })
      );
    } catch (error) {
      dispatch(
        setMessageStatus({
          status: false,
          message: `Undo action Failed: ${error?.response?.data?.message}`
        })
      );
    }

    dispatch(resetAccountManagerData());
  }
};

export default accountManagerSlice.reducer;
