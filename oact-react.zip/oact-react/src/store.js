import { configureStore } from '@reduxjs/toolkit';
import { LoggedUserDetailsReducer, CreateCycleReducer, 
  AccountManagerReducer, SystemOwnerReducer } from 'slices';

export default configureStore({
  reducer: {
    userDetail: LoggedUserDetailsReducer,
    createCycle: CreateCycleReducer,
    accountManager: AccountManagerReducer,
    systemOwner: SystemOwnerReducer
  }
});
