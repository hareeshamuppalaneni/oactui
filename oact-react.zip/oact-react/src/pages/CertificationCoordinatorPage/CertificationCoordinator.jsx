// import { TableWithFilter } from "components";
import React from "react";
import { CertificationCoordinator } from "containers";

import { HeaderTab, LoginNavBar, SubHeaderText } from "components";
import { AccountManager } from "containers";
import { useLocation } from "react-router-dom";

import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { fetchUserDetail, fetchCycleList, fetchApplicationList } from "slices";
import CONFIGS from "configs";

import Cookies from "js-cookie";
import _ from 'underscore';

const CertificationCoordinatorPage = () => {
  const location = useLocation();

  const dispatch = useDispatch();
  const userDetails = useSelector((state) => state.userDetail);

  useEffect(() => {
    const currentUser =
      Cookies.get("localUser") || location.state?.userDetail?.localUser;
    // If the Cookie Expiries the page should route back to login page
    if (_.isNull(Cookies.get('localUser')) || _.isUndefined(Cookies.get('localUser'))) {
      window.location.href = '/oact';
    } else {
      dispatch(fetchUserDetail(currentUser));
      dispatch(fetchCycleList(currentUser));
      dispatch(fetchApplicationList(currentUser));
      // dispatch(fetchAccountManagerTableDetails(currentUser))
    }
  }, []);

  return (
    <>
      <CertificationCoordinator />
    </>
  );
};

export default CertificationCoordinatorPage;
