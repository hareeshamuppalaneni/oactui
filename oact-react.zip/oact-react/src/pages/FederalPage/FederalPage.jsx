import React from 'react'
import FederalView from 'views/federal/FederalMain';
import { LoginNavBar } from 'components';

import { useDispatch, useSelector } from 'react-redux';

export default () => {

  const dispatch = useDispatch();
  const userDetails = useSelector((state) => state.userDetail);
  console.log("User Details => ", userDetails);
    return (
        <>
        <LoginNavBar />
        <FederalView />
      </>
    )
  };