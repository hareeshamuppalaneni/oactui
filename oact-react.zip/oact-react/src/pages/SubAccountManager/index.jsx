import React from 'react';
import { HeaderTab, LoginNavBar, SubHeaderText } from 'components';
import { SubAccountManager } from 'containers';
import { useLocation } from 'react-router-dom'

import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { fetchUserDetail } from 'slices';
import CONFIGS from 'configs';
import Cookies from 'js-cookie';

export default () => {

  const location = useLocation();

  const dispatch = useDispatch();
  const userDetails = useSelector((state) => state.userDetail);

  useEffect(() => {
    const currentUser = Cookies.get('localUser') || location.state?.userDetail?.localUser;
    // If the Cookie Expiries the page should route back to login page
    if (!currentUser) {
      window.href = '/oact';
    } else {
      dispatch(fetchUserDetail(currentUser));
    }
  }, []);


  return (
    <div>
      <LoginNavBar />
      <SubAccountManager />
    </div>
  );
};
