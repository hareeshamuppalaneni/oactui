import React from 'react';
import UploadUserData from 'views/federal/UploadUserData';
import { LoginNavBar } from 'components';

export default () => {
    return (
        <>
        <LoginNavBar />
        <UploadUserData />
      </>
    )
  };