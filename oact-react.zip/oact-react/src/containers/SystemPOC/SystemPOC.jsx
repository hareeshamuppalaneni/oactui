import React from 'react';
import { SubHeaderText } from 'components';
import { Button, GridContainer, Grid } from '@trussworks/react-uswds';
import { USER_ROLES_LABELS } from 'labels';

export default () => {
  return (
    <>
      <div className="App usa-banner__inner" style={{ display: 'block' }}>
        <GridContainer className="system-poc-grid-container">
          <Grid row>
            <Grid col={10}>
              <SubHeaderText text={USER_ROLES_LABELS.SP} />
            </Grid>
          </Grid>
        </GridContainer>
      </div>
    </>
  );
};
