import { regular } from '@fortawesome/fontawesome-svg-core/import.macro';
import { faDownload } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  Alert,
  Button,
  ButtonGroup,
  DatePicker,
  Grid,
  Modal,
  ModalFooter,
  ModalHeading,
  ModalOpenLink,
  ModalToggleButton,
  Table,
  Title
} from '@trussworks/react-uswds';
import { FILES } from 'assets';
import { TextInput } from 'components';
import { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import RenderApplicationTable  from './ApplicationTable';
import RenderAlert from './Alert';
import { CERTIFICATE_COORDINATOR_TEXTS } from 'labels';
import { Button as MainButtonModal } from 'react-bootstrap';
import { createCycleReview } from 'services';
import { fetchApplicationList, setCycleName, setEndDate, setStartDate, submitCreateCycle } from 'slices';

const gridStyles = {
  borderRadius: '0px',
  background: '#F0F0F0',
  height: ' 123px',
  padding: '20px'
};

const modalStyles = {
  height: '993px',
  width: '1340px',
  left: '274px',
  top: '53px',
  borderRadius: '0px'
};

const divStyling = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center'
};

const alertStyling = {
  padding: '20px'
};

const footerStyling = {
  padding: '20px',
  border: `1px solid #AEB0B5`,
  background: '#F0f0f0'
};

import './CreateCycle.css';



export default () => {
  const [files, setFiles] = useState([]);
  const [checkFilesUpload, setFilesUplaod] = useState([]);

  const dispatch = useDispatch();

  const createCycleState = useSelector((state) => state.createCycle);
  const { cycleName, applications, startDate, endDate, cycleStateId } = createCycleState;

  useEffect(() => {
    dispatch(fetchApplicationList());
  }, []);

  const modalRef = useRef(null);

  const tableHead = [
    { name: 'Application'},
    { name: 'System Owner'},
    { name: 'Cert. Coordinator'},
    { name: 'Account Manager'},
    { name: 'Sub Account Manager'},
    { name: 'Document'},
  ]


  return (
    <>
    <RenderAlert />
      <ModalOpenLink modalRef={modalRef}>
        <MainButtonModal variant="success">
          <span>
            <FontAwesomeIcon icon={regular('circle-play')} style={{ paddingRight: '10px' }} />
            {CERTIFICATE_COORDINATOR_TEXTS.CREATE_CYCLE}
          </span>
        </MainButtonModal>
      </ModalOpenLink>
      <Modal
        isLarge
        ref={modalRef}
        // forceAction
        aria-labelledby="modal-2-heading"
        aria-describedby="modal-2-description"
        id="example-modal-2"
        // className='theme-modal-lg-content-max-width'
      >
        <ModalHeading id="modal-2-heading">Create Review Cycle</ModalHeading>
        {startDate && endDate && cycleName ? (
          <div style={gridStyles}>
            <Grid row>
              <Grid col={5}>
                Cycle Name:
                <TextInput
                  style={{ marginTop: '.5rem' }}
                  onChange={(event) => {
                    dispatch(setCycleName(event.target.value));
                  }}
                  value={cycleName}
                />
              </Grid>
              <Grid col={3} className="start-date-container">
                {'Start Date:'}
                <DatePicker
                  onChange={(event) => dispatch(setStartDate(event))}
                  defaultValue={startDate}
                />
              </Grid>
              <Grid col={3}>
                {'Due Date:'}
                <DatePicker
                  onChange={(event) => dispatch(setEndDate(event))}
                  defaultValue={endDate}
                />
              </Grid>
            </Grid>
          </div>
        ) : null}

        <div className="alert-container" style={alertStyling}>
          <Title>Applications</Title>
          <Alert type="info" heading="Download Template" headingLevel="h4">
            For Proper injection, data should be properply formatted using OSHA template. Don't have
            a template?
            <span
              style={{
                paddingLeft: '10px'
              }}
            >
              <a href={FILES.USER_DATA_EXCEL_FILE} download="UserdataTemplate.xlsx">
                <FontAwesomeIcon icon={faDownload} />
                &nbsp;
                <span>Download Template</span>
              </a>
            </span>
            <div>
              Note: At present system is accepting properply formatted .xls files only. Use Above
              template in case you do not have formatted data.
            </div>
          </Alert>

          <Table bordered={false} style={{ margin: '1.5em 0px ', width: 'max-content' }}>
            <thead>
              <tr>
                {tableHead.map((eachHead, index) => {
                  return <th key={index}>{eachHead.name}</th>;
                })}
              </tr>
            </thead>
            <tbody>
              <RenderApplicationTable />
            </tbody>
          </Table>
        </div>

        <ModalFooter style={footerStyling}>
          <ButtonGroup>
            <ModalToggleButton modalRef={modalRef} closer unstyled>
              <Button
                onClick={(event) => dispatch(submitCreateCycle())}
              >
                Create Cycle
              </Button>
            </ModalToggleButton>
            <ModalToggleButton
              modalRef={modalRef}
              closer
              unstyled
              className="padding-105 text-center"
            >
              Cancel
            </ModalToggleButton>
          </ButtonGroup>
        </ModalFooter>
      </Modal>
    </>
  );
};
