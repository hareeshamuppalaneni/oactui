import React from 'react';
import { Alert } from '@trussworks/react-uswds';
import { useSelector } from 'react-redux';

const RenderAlert = () => {
  const createCycleSuccess = useSelector((state) => state.createCycle.createCycleSuccess);
  if (createCycleSuccess === true) {
    return (
      <>
        <Alert type="success" heading="Success status" headingLevel="h4" style={{ marginBottom : '20px '}}>
          {'Successfully Created a Cycle'}
        </Alert>
      </>
    );
  } else if (createCycleSuccess === false) {
    return (
      <>
        <Alert type="error" heading="Error status" headingLevel="h4" style={{ marginBottom : '20px '}}>
          {'Failed to Create Cycle'}
        </Alert>
      </>
    );
  } else {
    return null;
  }
};

export default RenderAlert;
