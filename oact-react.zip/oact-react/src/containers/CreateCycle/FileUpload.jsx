import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { uploadFileForCreateCycle } from 'slices'


/**
 * @author Skietech Development Team
 * @param {Int8Array} myRowIndex - Current Index of the File Upload Component
 * @returns
 */
const RenderFileUpload = ({ myRowIndex }) => {
//const RenderFileUpload = (props) => {
//     let myRowIndex = props.two.rowIndex;
    //alert("***** level 2: myRowIndex="+myRowIndex);
    //debugger;

    const cycleData = useSelector((state) => state.createCycle.cycleList)
    const excelFileName = cycleData[myRowIndex].excelFileName;

    const applicationOptions = useSelector((state) => state.createCycle.applications.options);
    const fileObject = applicationOptions[myRowIndex]?.fileObject;
    const dispatch = useDispatch();

    const airaLabel = `You have selected the file: ${fileObject?.fileName}`;

    const dispatchOnUpload = (event) => {
        event.preventDefault();
        dispatch(uploadFileForCreateCycle(event.target.files, myRowIndex))
    }

        return (
            <div className="usa-file-input">
                <div className="usa-file-input__target">
                    <div className="usa-file-input__preview-heading">Selected file
                        <span className="usa-file-input__choose">Change file</span>
                    </div><div className="usa-file-input__instructions display-none" aria-hidden="true">
                        <span className="usa-file-input__drag-text">Drag file here or </span>
                        <span className="usa-file-input__choose">choose from folder</span>
                    </div>
                    <div className="usa-file-input__preview" aria-hidden="true">
                        <img id="img_userdataimg_template__2exlsx-1666201229"
                            src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                            alt="" className="usa-file-input__preview-image usa-file-input__preview-image--excel" />
                         {excelFileName}
                        <div>
                        </div>
                    </div>
                    <div className="usa-file-input__box"></div>
                    <input id="file-input-single" className="usa-file-input__input" type="file" name="file-input-single" aria-live="polite"
                        aria-label={airaLabel} data-default-aria-label="No file selected"
                        onChange={(event) => dispatchOnUpload(event)} />
                </div>
            </div>
        )

};

export default RenderFileUpload;
