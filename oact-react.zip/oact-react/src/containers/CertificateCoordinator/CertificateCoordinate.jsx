import {Row} from 'react-bootstrap';


import UploadModal from './UploadModal';

import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {HeaderTab, LoginNavBar, SubHeaderText} from 'components';

import {Icon} from '@trussworks/react-uswds';
import {parseData} from './parser';
import {useDispatch, useSelector} from 'react-redux';

import React, {useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState} from 'react'; //############ AG GRID NEW CODE ##########
import {editCycleDetails, notifyUsers, setCCResetSelectAll, setEdit, setRecords} from 'slices';
import '@trussworks/react-uswds/lib/uswds.css';
import '@fontsource/merriweather';
import {faDownload, faEnvelope, faExclamationCircle, faExclamationTriangle} from '@fortawesome/free-solid-svg-icons';
import {FILES, IMAGES} from 'assets';
import {AgGridReact} from 'ag-grid-react';

import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import './CCStyle.css'
import {faBell} from "@fortawesome/free-regular-svg-icons";
// import CustomHeader from './customHeader';
// let fakeServer;
import CustomHeader from './customHeader';

//########################################
const Notification = Icon.Notifications;

const CertificationCoordinator = () => {
    const dispatch = useDispatch();
    const cycleData = useSelector((state) => state.createCycle.cycleList);

    useEffect(() => {

        const tempTable = parseData(cycleData, setEditData);
        dispatch(setRecords(tempTable));
        dispatch(setCCResetSelectAll());
        if (tempTable.length > 0) {
            //alert('length='+tempTable.length);
            let processedArray = [];


            for (let row of tempTable) { //todo: convert to map
                // console.log("row="+JSON.stringify(row));
                // console.log("auditData="+JSON.parse(JSON.stringify(row)));
                //debugger;
                processedArray.push({
                    "CycleId": row.Action.certificationCycleId,
                    "Action": "",
                    "Upload": "",
                    "Cycle": row.Cycle,
                    "App": row.Action.pocData.applicationCode,
                    "AppName": row.Action.pocData.applicationName,
                    "Start Date": row.Action.cycleStartDate,
                    "DueDate": row.due_Date,
                    "Days Till Due": row.Action.daysTillDueDate,
                    "Current Task": row.Action.cycleSate.descriptionText,
                    "System Owner": row.system_Owner,
                    "Coordinator": row.Coordinator,
                    "Account Manager": row.account_Manager,
                    "Sub-Account Managers": row.Action.pocData.subAccountManagerCount,
                    "auditData": row.Action.auditData,
                    "ExcelFileName": row.Action.excelFileName
                });
            }
            setRowData(processedArray);
        }
    }, [cycleData]);

    const setEditData = (element) => {
        console.log(element);
        dispatch(setEdit(element.data.Action));
    };



    // ########### AGGRID NEW CODE ###############

    let [rowData, setRowData] = useState();
    const gridRef = useRef();
    const gridStyle = useMemo(() => ({height: '100%', width: '100%'}), []);


    const ActionElements = (props) => {

        return (
            <>
                <span>  <UploadModal rowIndex={props.rowIndex}></UploadModal>   </span>
            </>
        );
    };

    const ActionIconsStyle = {
        color: '#0075BF',
        cursor: 'pointer',
        marginLeft: '20px'
    };

    const EllipsisIconsStyle = {
        ...ActionIconsStyle,
        // pointerEvents: 'none',
        cursor: 'not-allowed'
    };

    const normalDueDaysStyle = {
        // marginLeft: '20px',
        // textAlign: 'center'
    };

    const CertificationIconStyle = {
        marginLeft: '20px'
    };

    const PastDueDateIconStyle = {
        marginLeft: '20px'
        // color: 'red'
    };

    const ThreeDaysIconStyle = {
        marginLeft: '20px'
        // color: 'salmon'
    };
    const SevenDaysIconStyle = {
        marginLeft: '10px'
        // color: 'golden'
    };

    const daysTillDueStyle = (daysTillDueDate) => {
        // props.data.daysTillDueDate = -6;
        // if (Number(daysTillDueDate) < 0) {
        if(Number(daysTillDueDate) == -4) {
            return (
                <span style={{ ...normalDueDaysStyle, color: '#d54309' }}>
          {Number(daysTillDueDate)}
                    <span style={{ ...SevenDaysIconStyle, color: '#d54309' }}>
            <FontAwesomeIcon icon={faExclamationCircle} />
          </span>
        </span>
            );
        }

        // if (-7 >= Number(daysTillDueDate) && Number(daysTillDueDate) >= -6) {
        if(Number(daysTillDueDate) == -7) {
            return (
                <span style={{ ...normalDueDaysStyle, color: '#000000' }}>
          {Number(daysTillDueDate)}
                    <span style={{ ...SevenDaysIconStyle, color: '#fa9441' }}>
            <FontAwesomeIcon icon={faExclamationTriangle} />
          </span>
        </span>
            );
        }

        // if (-5 >= Number(daysTillDueDate) && Number(daysTillDueDate) > -5) {
        if(Number(daysTillDueDate) == -5) {
            return (
                <span style={{ ...normalDueDaysStyle, color: '#000000' }}>
          {Number(daysTillDueDate)}
                    <span style={{ ...SevenDaysIconStyle, color: '#ffbe2e' }}>
            <FontAwesomeIcon icon={faBell} />
          </span>
        </span>
            );
        }

        return <span style={normalDueDaysStyle}>{Number(props.data.daysTillDueDate)}</span>;
    };

    const bellRenderer = (props) => {
        return (
           <span >
              <a style={{color: 'black', textAlign:'center'}}>{props.value}&nbsp;</a>
              <a style={{color: '#ffbe2e', textAlign:'center'}}><i className="fa fa-bell" aria-hidden="true"></i></a>
            </span>
        )

    };

    const circleRenderer = (props) => {
        return (
            <span >
              <a style={{color: '#d54309', textAlign:'center'}}>{props.value}&nbsp;</a>
              <a style={{color: '#d54309', textAlign:'center'}}><i className="fa fa-exclamation-circle" aria-hidden="true"></i></a>
            </span>
        )
    };

    const flagRenderer = (props) => {
        return (
            <span >
              <a style={{color: 'black', textAlign:'center'}}>{props.value}&nbsp;</a>
              <a style={{color: '#fa9441', textAlign:'center'}}><i className="fa fa-flag" aria-hidden="true"></i></a>
            </span>
        )
    };

    const completeRenderer = (props) => {
        return (
            <span >
              <a style={{color: 'black', textAlign:'center'}}>{props.value}&nbsp;</a>
              <a style={{color: '#00a91c', textAlign:'center'}}><i className="fa  fa-check-circle" aria-hidden="true"></i></a>
            </span>
        )
    };



    //################## COLUMN DEFINTION ################
    const [columnDefs] = useState([
        {
            // field: 'selectAll',
            headerCheckboxSelection: true,
            checkboxSelection: true,
            maxWidth: 40,
            headerCheckboxSelectionFilteredOnly: true,
            // cellRendererFramework: CheckBoxrender
        },
        {
            field: 'action',
            headerName: 'Action',
            cellRendererFramework: ActionElements,
            maxWidth: 120,
            sortable: false,
            minWidth: 120
        },
        {
            field: 'CycleId',
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150
        },
        {
            field: 'ExcelFileName',
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150
        },
        {   field: 'Cycle',
            headerComponentParams: { menuIcon: 'fa-pen-square' },
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            editable: true,
            tooltipField: 'Cycle',
            valueGetter: (params) => {
                return params.data.Cycle;
            },
            valueSetter: (params) => {

                let obj = {
                    //cycleStartDate: params.data.StartDate || "",
                    certificationCycleId: params.data.CycleId || "",
                    name: params.newValue,
                    dueDate: params.data.DueDate, //########### INLINE EDIT ###############
                    auditData: params.data.auditData
                };
                // debugger;
                dispatch(editCycleDetails(obj));

            },


        },
        {field: 'App',
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            tooltipField: 'AppName'
        },
        {
            field: 'Start Date',
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            tooltipField: 'Start Date',


        },
        {
            field: 'Due Date',
            headerComponentParams: { menuIcon: 'fa-pen-square' },
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            editable: true,
            tooltipField: 'Due Date',
            valueGetter: (params) => {
                return params.data.DueDate;
            },
            valueSetter: (params) => {

                let obj = {
                    certificationCycleId: params.data.CycleId || "",
                    name: params.data.Cycle,
                    dueDate: params.newValue, //########### INLINE EDIT ###############
                    auditData: params.data.auditData
                };
                //debugger;
                dispatch(editCycleDetails(obj));

            },
        },
        {
            field: 'Days Till Due',
            sortingOrder: ['asc','desc'],
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            tooltipField: 'Days Till Due',

            cellRendererSelector : (params) => {
                const bell = { component: 'bellRenderer' };
                const flag = { component: 'flagRenderer'};
                const circle = { component: 'circleRenderer'};
                if (params.value <= 0) return circle;
                if (params.value <= 3) return flag;
                if (params.value <= 7) return bell;
            },
            cellStyle: {textAlign: 'center'}

        },
        {
            field: 'Current Task',
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            tooltipField: 'Current Task'
        },
        {
            field: 'System Owner',
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            tooltipField: 'System Owner'
        },
        {
            field: 'Coordinator',
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            tooltipField: 'Coordinator'
        },
        {
            field: 'Account Manager',
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            tooltipField: 'Account Manager'
        },
        {
            field: 'Sub-Account Managers',
            filter: 'agTextColumnFilter',
            resizable: true,
            minWidth: 150,
            tooltipField: 'Sub-Account Managers',
            cellStyle: {textAlign: 'center'}
        }


    ]);
    const defaultColDef = useMemo(() => {
        return {
            flex: 1,
            //maxWidth: 160,
            resizable: true,
            floatingFilter: true,
            sortable: true,
        };
    }, []);


    const paginationNumberFormatter = useCallback((params) => {
        return '[' + params.value.toLocaleString() + ']';
    }, []);

    const onGridReady = (params) => {
        setRowData(data);
        params.api.addEventListener('paginationChanged', (e) => {
            //Reset rows selection based on current page
            resetPaginationSelection(params);
          });
    }

    const onFirstDataRendered = useCallback((params) => {
        gridRef.current.api.paginationGoToPage(4);
    }, []);

    const onPageSizeChanged = useCallback(() => {
        var value = document.getElementById('page-size').value;
        gridRef.current.api.paginationSetPageSize(Number(value));
    }, []);


    // ############################################
    const rowSelection = 'multiple';

    const newNotifyUsers = useCallback(() => {

        let notifyArray=[];
        gridRef.current.api.forEachNode((node) => {
            //if (node.selected) alert('node.data.CycleId='+node.data.CycleId);
            if (node.selected) {
                //alert(node.data.CycleId);
                notifyArray.push(node.data.CycleId);
            }
            }
        );
        dispatch(notifyUsers(notifyArray));
    }, []);

    const containerStyle = useMemo(() => ({margin: `auto auto`, height: `60vh`, width: `100%`}), []);

    //#### BELOW OVERRIDE HEADER FOR CUSTOM ICON (Pencil), but you loose sorting
    const components = useMemo(() => {
        return {
            agColumnHeader: CustomHeader,
        };
    }, []);


    // #################### CheckBox to Select All Temp Solution
    const resetPaginationSelection = (self) => {
        console.log('self =>', self);
        //Deselect previously selected rows to reset selection
        // self.api.deselectAll();

        //Initialize pagination data
        let paginationSize = self.api.paginationGetPageSize();
        let currentPageNum = self.api.paginationGetCurrentPage();
        let totalRowsCount = self.api.getDisplayedRowCount();

        //Calculate current page row indexes
        let currentPageRowStartIndex = currentPageNum * paginationSize;
        let currentPageRowLastIndex = currentPageRowStartIndex + paginationSize;
        if (currentPageRowLastIndex > totalRowsCount) currentPageRowLastIndex = totalRowsCount;

        for (let i = 0; i < totalRowsCount; i++) {
          //Set isRowSelectable=true attribute for current page rows, and false for other page rows
          let isWithinCurrentPage = i >= currentPageRowStartIndex && i < currentPageRowLastIndex;
          self.api.getDisplayedRowAtIndex(i).setRowSelectable(isWithinCurrentPage);
        }
      };

    //   const onGridReady = (params) => {
    //     // console.log("Params =>", params);
    //     // console.log("Gridref =>", gridRef);
    //     // console.log("params.current.api =>", params.current.api);
    //     params.api.addEventListener('paginationChanged', (e) => {
    //       //Reset rows selection based on current page
    //       resetPaginationSelection(params);
    //     });
    //   };
    //######################################

    const applyPageSizeSetByUser = useCallback((params) => {
        var value = document.getElementById('page-size').value;
        gridRef.current.api.paginationSetPageSize(Number(value));
    }, []);

    return (
        <>
            <Row>
                <LoginNavBar/>
            </Row>

            <div className="App usa-banner__inner">
                <HeaderTab/>
            </div>

            <div style={{margin: `auto auto`, width: `95%`}}>

                <div className="grid-row">
                    <div className="grid-col-6">
                        <div style={{textAlign: 'left'}}>
                                <SubHeaderText text={'Certification Coordinator'}/>
                        </div>
                    </div>



                    <div className="grid-col-6">
                        <div style={{textAlign: 'right'}}>
                            <img
                                className="oact__logo-img"
                                alt="img alt text"
                                src={IMAGES.MAIN_OACT_LOGO}
                            />
                        </div>
                    </div>

                </div>
            </div>


            <div style={{margin: `auto auto`, height: `60vh`, width: `95%`}}>

                <div className="grid-row" style={{ marginBottom: '-15px'}}>
                    <div className="grid-col-4">

                        {/*<div className="grid-row" >*/}
                        <a>
                            <button className="btn example-header" onClick={newNotifyUsers}>
                                <FontAwesomeIcon icon={faEnvelope}/>
                                &nbsp;
                                <span>Notify Users</span>
                                </button>
                        </a>

                        <a href={FILES.USER_DATA_EXCEL_FILE} download="UserdataTemplate.xlsx">
                            <button className="btn example-header">
                                <FontAwesomeIcon icon={faDownload}/>
                                &nbsp;
                                <span>Download Template</span>
                            </button>
                        </a>
                        {/*</div>*/}
                    </div>


                    <div className="grid-col-8">
                        <div style={{textAlign: 'right', paddingTop: '5px'}}>
                            Page Size:&nbsp;
                            <select onChange={onPageSizeChanged} id="page-size">
                                <option value="10">
                                    10
                                </option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100" selected={true}>100</option>
                            </select>
                        </div>
                    </div>

                </div>


                <div style={containerStyle}>
                    <div className="example-wrapper">

                        <div style={gridStyle} className="ag-theme-alpine">
                            <AgGridReact
                                ref={gridRef}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}

                                frameworkComponents={{
                                    flagRenderer: flagRenderer,
                                    circleRenderer: circleRenderer,
                                    bellRenderer: bellRenderer,
                                }}

                                rowSelection={'multiple'}
                                // components={components}

                                pagination={true}
                                paginationNumberFormatter={paginationNumberFormatter}
                                onGridReady={onGridReady}
                                onFirstDataRendered={onFirstDataRendered}
                                tooltipShowDelay={0}
                                tooltipHideDelay={2000}

                                // onCellValueChanged={onCellValueChanged}
                                onFirstDataRendered={applyPageSizeSetByUser}
                            ></AgGridReact>
                        </div>
                    </div>
                </div>


            </div>

        </>
    );
};

export default CertificationCoordinator;
