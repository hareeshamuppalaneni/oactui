import React, { useCallback} from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faCheckCircle, faFileSignature } from '@fortawesome/free-solid-svg-icons';
import { setCurrentAction, setModalOpen, certifyUsers, setSelectData, certifyBulkSystemOwner } from 'slices';
import { ACCOUNT_MANAGER_ALERT_ACTIONS } from 'labels';
import './SystemOwner.css';

export default ({ gridRef }) => {
  const dispatch = useDispatch();
  const systemOwnerState = useSelector((state) => state.systemOwner);
  const onClickBulkButton = () => {
    // dispatch(setCurrentAction(ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_EDIT));
    // dispatch(setModalOpen(true));
    // dispatch(setSelectData(gridRef?.current?.api?.getSelectedRows()));

  };

  const ConditionalStyles = () => {
    if (systemOwnerState.selectedData.length === 0) {
      return {
        pointerEvents: 'none',
        cursor: 'not-allowed'
      };
    } else {
      return {};
    }
  };

  const onPageSizeChanged = useCallback(() => {
    var value = document.getElementById('page-size').value;
    console.log("Hello Owrld => ");
    console.log("Hello Owrld => ", gridRef.current.api);
    gridRef.current.api.paginationSetPageSize(Number(value));
  }, []);

  return (
    <span style={{ float: 'left'}}>
      <span
        className="system-owner-bulk-action-button-container"
        onClick={() => dispatch(certifyBulkSystemOwner())}
        style={ConditionalStyles()}
      >
        <FontAwesomeIcon
          icon={faFileSignature}
          className="system-owner-bulk-action-button-text-container"
        />
        Bulk Certification
      </span>
      {}
    </span>
  );
};
