import SystemOwner from './SystemOwner';

export default SystemOwner;