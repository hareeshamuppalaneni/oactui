import React from 'react';
import { useSelector } from 'react-redux';
import { Alert } from '@trussworks/react-uswds';
import { ACCOUNT_MANAGER_ALERT_ACTIONS } from 'labels';
import _ from 'underscore';

import './AccountManager.css'

export default () => {
  const currentAccountManagerState = useSelector((state) => state.accountManager);
  const { attestationList, selectedAttestation, messageStatus, currentAction } =
    currentAccountManagerState;

  const AlertMessage = ({ status, message }) => {
    return (
      <Alert type={status ? 'success' : 'error'} headingLevel="h4" slim>
        {message}
      </Alert>
    );
  };

  return (
    <>
      {!_.isNull(messageStatus.status) ? (
        <Alert type={messageStatus.status ? 'success' : 'error'} headingLevel="h4" slim className="account-manager-alert-container">
          {messageStatus.message}
        </Alert>
      ) : null}
    </>
  );
};
