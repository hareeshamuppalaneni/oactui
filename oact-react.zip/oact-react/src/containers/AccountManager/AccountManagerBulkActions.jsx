import React, { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faCheckCircle, faCog, faUndoAlt } from '@fortawesome/free-solid-svg-icons';
import {
  setCurrentAction,
  setModalOpen,
  certifyUsers,
  setSelectData,
  setMessageStatus,
  undoBulkUsers,
  checkForSelectedRows,
  setUndoActionModal
} from 'slices';
import { ACCOUNT_MANAGER_ALERT_ACTIONS } from 'labels';
import './AccountManager.css';

export default ({ gridRef }) => {
  const dispatch = useDispatch();
  const accountManagerState = useSelector((state) => state.accountManager);
  const onClickBulkButton = () => {
    if (accountManagerState.selectedData.length === 0) {
      dispatch(checkForSelectedRows());
    } else {
      dispatch(setCurrentAction(ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_EDIT));
      dispatch(setModalOpen(true));
    }

    // dispatch(setSelectData(gridRef?.current?.api?.getSelectedRows()));
  };

  const ConditionalStyles = () => {
    if (accountManagerState.selectedData.length === 0) {
      return {
        pointerEvents: 'none',
        cursor: 'not-allowed'
      };
    } else {
      return {};
    }
  };

  const onClickBulkUndoAction = () => {
    if (accountManagerState.selectedData.length === 0) {
      dispatch(checkForSelectedRows());
    } else {
      /**
       * Filter the Certified Data
       */
      let tempSelectedData = JSON.parse(JSON.stringify([...accountManagerState.selectedData]));

      tempSelectedData = tempSelectedData.filter((eachRow) => {
        return eachRow.stateName === 'Completed';
      });

      if (tempSelectedData.length === 0) {
        dispatch(
          setMessageStatus({
            status: false,
            message: `All the Items which are selected are still under review`
          })
        );

        setTimeout(() => {
          dispatch(setMessageStatus({ status: null, message: '' }));
        }, 3000);
      } else {
        dispatch(setSelectData(tempSelectedData));
        dispatch(setUndoActionModal(true));
      }
    }

    // let processed = true;

    // accountManagerState.selectedData.forEach((eachRow) => {
    //   if (eachRow.stateName !== 'Completed') {
    //     processed = false;
    //   }
    // });

    // if (processed === false) {
    //   dispatch(
    //     setMessageStatus({
    //       status: false,
    //       message: `You have selected one or more items that are still Under Review. Please deselect those items and try the Bulk Undo again.`
    //     })
    //   );

    //   setTimeout(() => {
    //     dispatch(setMessageStatus({ status: null, message: '' }));
    //   }, 3000);
    // } else {
    //   dispatch(undoBulkUsers());
    // }

    // if(accountManagerState.undoActionSelectedRows.length === 0)
    /**
     * You have selected one or more items that are still Under Review. Please deselect those items and try the Bulk Undo again.
     */
  };

  const onClickBulkCertifyAction = () => {
    if (accountManagerState.selectedData.length === 0) {
      dispatch(checkForSelectedRows());
    } else {
      /**
       * Filter the Certified Data
       */
      let tempSelectedData = JSON.parse(JSON.stringify([...accountManagerState.selectedData]));

      tempSelectedData = tempSelectedData.filter((eachRow) => {
        return eachRow.stateName !== 'Completed';
      });

      if (tempSelectedData.length === 0) {
        dispatch(
          setMessageStatus({
            status: false,
            message: `All the Items which are selected are already certified.`
          })
        );

        setTimeout(() => {
          dispatch(setMessageStatus({ status: null, message: '' }));
        }, 3000);
      } else {
        dispatch(setSelectData(tempSelectedData));
        dispatch(certifyUsers());
      }
    }

    // let processed = true;

    // accountManagerState.selectedData.forEach((eachRow) => {
    //   if (eachRow.stateName === 'Completed') {
    //     processed = false;
    //   }
    // });

    // if (processed === false) {
    //   dispatch(
    //     setMessageStatus({
    //       status: false,
    //       message: `You have selected one or more items that are already certified. Please deselect those items and try the Bulk Certify again.`
    //     })
    //   );

    //   setTimeout(() => {
    //     dispatch(setMessageStatus({ status: null, message: '' }));
    //   }, 3000);
    // } else {
    //   dispatch(certifyUsers());
    // }
  };

  const onPageSizeChanged = useCallback(() => {
    var value = document.getElementById('page-size').value;
    gridRef.current.api.paginationSetPageSize(Number(value));
  }, []);

  return (
    <span>
      <span
        className="account-manager-bulk-action-button-container"
        onClick={() => onClickBulkCertifyAction()}
        // style={ConditionalStyles()}
      >
        <FontAwesomeIcon
          icon={faCheckCircle}
          className="account-manager-bulk-action-button-text-container"
        />
        Bulk Certify
      </span>
      <span
        className="account-manager-bulk-action-button-container"
        onClick={() => onClickBulkButton()}
      >
        <FontAwesomeIcon
          icon={faPenToSquare}
          className="account-manager-bulk-action-button-text-container"
        />
        Bulk Edit
      </span>
      <span
        className="account-manager-bulk-action-button-container"
        onClick={() => onClickBulkUndoAction()}
      >
        <FontAwesomeIcon
          className="account-manager-bulk-action-button-text-container"
          icon={faUndoAlt}
        />{' '}
        Bulk Undo
      </span>
      {}
      {}
    </span>
  );
};
