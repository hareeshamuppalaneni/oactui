import React, { useState, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleXmark } from '@fortawesome/free-solid-svg-icons';
import { Modal, InputGroup, Form, Button } from 'react-bootstrap';
import { Alert, Dropdown, Grid, GridContainer, Textarea, Label } from '@trussworks/react-uswds';
import { AgGridReact } from 'ag-grid-react';

import {
  setEditModalComments,
  setEditModalStatus,
  setModalOpen,
  updateReviewStatus,
  certifyUsers,
  resetEditModalData
} from 'slices';
import {
  ACCOUNT_MANAGER_EDIT_LABELS,
  ACCOUNT_MANAGER_ALERT_ACTIONS,
  ACCOUNT_MANAGER_MODAL_LABELS
} from 'labels';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import './AccountManager.css';
import _ from 'underscore';

export default () => {
  const dispatch = useDispatch();
  const accountManagerState = useSelector((state) => state.accountManager);
  const { openModal, selectedData, currentAction } = accountManagerState;
  const [show, setShow] = useState(true);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [showWarning, setShowWarning] = useState(false);

  const DeSelectIcon = (props) => {
    return (
      <span
        className="edit-container-modal-deselect"
        onClick={(event) => {
          console.log('props?.data?.deSelect in ClickedEvent =>', props?.data?.deSelect);
        }}
      >
        <FontAwesomeIcon icon={faCircleXmark} />
      </span>
    );
  };

  const [columnDefs] = useState([
    // {
    //   headerName: 'Deselect',
    //   field: 'deSelect',
    //   cellRendererFramework: DeSelectIcon,
    //   sortable: false,
    //   maxWidth: 50
    // },
    { headerName: 'First Name', field: 'firstName', filter: true, maxWidth: 150 },
    { headerName: 'Last Name', field: 'lastName', filter: true, maxWidth: 150 },
    { headerName: 'Current Review Status', field: 'reviewResults', filter: true }
  ]);

  const defaultColDef = useMemo(() => ({
    // sortable: true,
    resizable: true,
    // floatingFilter: true,
    // sortable: true,
    domLayout: 'autoHeight'
  }));

  const onChangeComments = (event) => {
    dispatch(setEditModalComments(event?.target?.value));
  };

  const selectReviewStatus = (event) => {
    // We don't need to trigger onchange for default text
    if (event?.target?.value !== ACCOUNT_MANAGER_EDIT_LABELS.SELECT_STATUS_LABEL) {

      if(selectedData[0]?.reviewResults) {
        setShowWarning(true);
      }
      dispatch(setEditModalStatus(event?.target?.value));
    } else {
      dispatch(setEditModalStatus(''));
    }
  };

  const onClickUpdate = () => {
    if (ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_EDIT === currentAction) {
      dispatch(updateReviewStatus());
    } else {
      dispatch(certifyUsers());
    }
  };

  const onCloseModal = () => {
    dispatch(resetEditModalData());
    // dispatch(setModalOpen(false));
  };

  const Labels = {
    Header: ACCOUNT_MANAGER_MODAL_LABELS[currentAction]?.MAIN_HEADER || '',
    AlertHeader: ACCOUNT_MANAGER_MODAL_LABELS[currentAction]?.ALERT_HEADER || '',
    AlertMsg: ACCOUNT_MANAGER_MODAL_LABELS[currentAction]?.ALERT_MSG || '',
    DropdownLabel: ACCOUNT_MANAGER_MODAL_LABELS[currentAction]?.DROPDOWN_LABEL || '',
    CommentsLabel: ACCOUNT_MANAGER_MODAL_LABELS[currentAction]?.COMMENTS || '',
    SelectLabel: ACCOUNT_MANAGER_MODAL_LABELS[currentAction]?.SELECT_STATUS_LABEL || '',
    ButtonSave: ACCOUNT_MANAGER_MODAL_LABELS[currentAction]?.BUTTON_SAVE_LABEL || '',
    ButtonCancel: ACCOUNT_MANAGER_MODAL_LABELS[currentAction]?.BUTTON_CANCEL || ''
  };

  const RenderWarning = () => {
    if(showWarning) {
      return (
        <Alert type="warning" headingLevel="h4" slim>
        {`Are you sure you want to change the Review Result of the User ? Previous State: ${selectedData[0]?.reviewResults}`}
      </Alert>
      )
    } else {
      return null;
    }
  }

  const RenderDropdown = () => {
    if (ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_EDIT === currentAction) {
      const ReviewStatus = [
        ACCOUNT_MANAGER_EDIT_LABELS.SELECT_STATUS_LABEL,
        'Delete User',
        'Disable User',
        'Modify Permission'
      ];
      return (
        <Grid col={4}>
          <Grid row>
            <span style={{ color: 'red', fontWeight: 'bold' }}>
              <Label style={{ color: 'black', fontWeight: 'normal', display: 'inline' }}>
                {Labels.DropdownLabel}
              </Label>
              *
            </span>
            <Dropdown
              onChange={(event) => selectReviewStatus(event)}
              style={{ marginBottom: '20px' }}
              defaultValue={selectedData[0]?.reviewResults}
            >
              {ReviewStatus.map((eachStatus, index) => {
                return (
                  <option key={index} value={eachStatus}>
                    {eachStatus}
                  </option>
                );
              })}
            </Dropdown>
            {RenderWarning()}
          </Grid>
          <Grid row>
            <span style={{ color: 'red', fontWeight: 'bold' }}>
              <Label style={{ color: 'black', fontWeight: 'normal', display: 'inline' }}>
                {Labels.CommentsLabel}
              </Label>
              *
            </span>

            <Textarea
              id="input-type-text"
              name="input-type-text"
              type="text"
              onChange={(event) => onChangeComments(event)}
              value={accountManagerState?.editModal?.comments}
              defaultValue={selectedData[0]?.comments}
            />
          </Grid>
        </Grid>
      );
    } else {
      return null;
    }
  };

  // const RenderButtons = ()
  // const disableFlag =
  // const disableButtons = () => {
  //   if(ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_EDIT === currentAction) {
  //     return _.isEmpty(accountManagerState?.editModal?.comments) &&
  //     _.isEmpty(accountManagerState?.editModal?.selectedStatus) && accountManagerState?.editModal?.comments.length > 0
  //   } else {
  //     false
  //   }
  // }

  // const disableButtons = () => {
  //   return _.isEmpty(accountManagerState?.editModal?.selectedStatus);
  // };

  const disableButtons = () => {
    return (
      accountManagerState?.editModal?.comments.length === 0 ||
      _.isEmpty(accountManagerState?.editModal?.selectedStatus) ||
      accountManagerState.selectedData.length === 0
    );
  };

  // const applyPageSizeSetByUser = useCallback((params) => {
  //   var value = document.getElementById('page-size').value;
  //   gridRef.current.api.paginationSetPageSize(Number(value));
  // }, []);

  console.log('disableButtons => ', disableButtons());
  return (
    <>
      <Modal show={accountManagerState.openModal} onHide={onCloseModal} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>{Labels.Header}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {/* <GridContainer style={{ width: 'max-width' }}> */}
          <Grid row style={{ margin: '20px 0px'}}>
            <Grid col={10}>
              <Alert
                type="info"
                heading={Labels.AlertHeader}
                headingLevel="h4"
                // style={{ width: '80%' }}
              >
                {Labels.AlertMsg}
                <div>
                  (e.g. user no longer DOL employee, user transferred to other agency, etc.) in the
                  "Comments" box.
                </div>
              </Alert>
            </Grid>
          </Grid>

          <GridContainer>
            <Grid row>
              <Grid col={8}>
                <div
                  className="ag-theme-alpine"
                  style={{ height: 400, width: '550px', marginRight: '60px' }}
                >
                  <AgGridReact
                    rowData={selectedData}
                    columnDefs={columnDefs}
                    defaultColDef={defaultColDef}
                    // onColClicked={(e) => console.log("Col clicked", e.rowIndex)}
                    // onRowSelected={(e) => console.log("row selected", e.rowIndex)}
                    onRowClicked={(e) => console.log('row clicked', e)}
                    onCellClicked={(event) => console.log('Cell was clicked =>', event)}
                    //onFirstDataRendered={applyPageSizeSetByUser}
                  ></AgGridReact>
                </div>
              </Grid>
              {RenderDropdown()}
            </Grid>
          </GridContainer>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={onCloseModal}>
            {Labels.ButtonCancel}
          </Button>
          <Button variant="primary" onClick={() => onClickUpdate()} disabled={disableButtons()}>
            {Labels.ButtonSave}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};
