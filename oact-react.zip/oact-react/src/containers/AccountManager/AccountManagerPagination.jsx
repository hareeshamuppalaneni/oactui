import React, { useCallback } from 'react';

export default ({ api }) => {

  console.log("API In Pagination => ", api)
  const onPageSizeChanged = useCallback(() => {
    var value = document.getElementById('page-size').value;
    api.paginationSetPageSize(Number(value));
  }, []);
  return (
    <div className="example-header">
      Page Size:  
      <select onChange={onPageSizeChanged} id="page-size">
        <option value="10" >
          10
        </option>
        <option value="25">25</option>
        <option value="50">50</option>
        <option value="100" selected={true}>100</option>
      </select>
    </div>
  );
};
