import commonFetch from './commonFetch';

export const getCyclesList = async (emailAddress) => {
    console.log("Email =>", emailAddress);
  const cyclesList = await commonFetch({
    url: 'certification-cycles',
    method: 'get',
    params: {
      email: emailAddress
    }
  });
  console.log('Response from Cycle List Call Get Call', cyclesList);
  return cyclesList;
};
