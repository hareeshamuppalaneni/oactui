import commonFetch from './commonFetch';

export const getSystemList = async () => {
  const systemList = await commonFetch({
    url: 'access-control-hierarchies',
    method: 'get',
    params: {
      organizationType: 'System'
    }
  });
  return systemList;
};

export const getSubSystemList = async (systemId) => {
  const systemList = await commonFetch({
    url: 'access-control-hierarchies',
    method: 'get',
    params: {
      parentAccessControlHierarchyId: systemId
    }
  });
  return systemList;
};

export const getApplicationList = async (subSystemId) => {
  const applicatonList = await commonFetch({
    url: 'access-control-hierarchies',
    method: 'get',
    params: {
      parentAccessControlHierarchyId: subSystemId
    }
  });
  return applicatonList;
};

export const createCyclePost = async (createCycleData) => {
  const { agency, cycleName, startDate, endDate, systems, subSystems, applications } =
    createCycleData;
  const isoFormatStartDate = new Date(startDate);
  const isoFormatEndDate = new Date(endDate);
  console.log('ISO FORMAT =>', isoFormatStartDate);
  console.log('ISO FORMAT =>', isoFormatEndDate);
  const { selected } = applications;
  const currentSelected = selected[0];
  const constructBodyForResonse = {
    // {
    // "accessControlCycleId": 0,
    // "accessControlHierarchyId": 26,
    // "accessControlPocHierarchyId": 39,
    // "auditData": {
    //   "lastModifiedUserId": 0,
    //   "lockControlNumber": 123456
    // },
    // "cycleEndDate": null,
    // "cycleStartDate": "2022-10-07",
    // "cycleStateId": 47,
    // "descriptionText": "Cycle Test",
    // "dueDate": "2022-10-25",
    // "fiscalQuarter": "01",
    // "fiscalYear": "2023",
    // "name": "Cycle Test",
    // "organizationType": "Application"
    //   }
    accessControlCycleId: 0,
    accessControlHierarchyId: currentSelected.accessControlHierarchyId,
    accessControlPocHierarchyId: currentSelected.hierarchyPOCBag[0].accessControlHierarchyPocId,
    auditData: {
      lastModifiedUserId: 0,
      lockControlNumber: 0
    },
    certificationCycleId: 1,
    cycleEndDate: isoFormatEndDate.toISOString(),
    cycleStartDate: isoFormatStartDate.toISOString(),
    cycleStateId: 47,
    descriptionText: currentSelected.descriptionText,
    dueDate: isoFormatEndDate.toISOString(),
    fiscalQuarter: '01',
    fiscalYear: '2023',
    name: cycleName,
    organizationType: 'System'
  };

  try {
    const response = await commonFetch({
      url: 'certification-cycles',
      method: 'post',
      data: constructBodyForResonse
    });
    console.log('Response from Cycle Creation', response);
    return response;
  } catch (error) {
    console.log('Error => ', error);
  }
};

export const getCreateCycleReviewList = async (userName) => {
  const applicationDetails = await commonFetch({
    url: 'access-control-hierarchies-poc/applications',
    method: 'get',
    params: {
      email: userName
    }
  });

  console.log('Application Details =>', applicationDetails);

  return applicationDetails;
};

export const createCycleReview = async (request) => {

    try {
        const response = await commonFetch({
            url: 'certification-cycles', method: 'post', data: request
        });
        console.log("Response from Cycle Creation", response);
        return response;
    } catch (error) {
        console.log("Error from createCycleReview => ", error);
        return { error: true, errorBody: error };
    }
}


  export const notifyUsersService = async (obj) => {

  console.log(obj)
    try {
      const response = await commonFetch({ url:'notify/cycle', method: "post", data: obj });

    return response;
  } catch (error) {
    console.log('Error from createCycleReview => ', error);
    return { error: true, errorBody: error };
  }
};
export const onsubmitCertificateData = async (obj) => {
  try {
    const response = await commonFetch({ url: 'certification-cycles', method: 'put', data: obj });
    return response;
  } catch (error) {
    console.log(error);
    return error;
  }
};

export const uploadFileData = async (file, id, userId) => {
  let data = { file };
  console.log('data is', data);
  data.metadata = id.certificationCycleId;
  data.userId = userId;
  try {
    console.log("/n>>>>>> UPLOAD POST <<<<<</n");
    await commonFetch({
      url: 'uploadFile',
      method: 'post',
      data,
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    alert('Sucessfully uploaded '+file.name);
  } catch (error) {
    alert('Error occurred during uploading '+file.name+'\nPlease check your file again or contact your admin.');
    console.log(error, 'error');
  }
};
