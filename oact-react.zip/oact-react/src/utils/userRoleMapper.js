export const checkUserRoleMapper = (userRoles) => {
  return userRoles.map((eachRoleInfo) => {
    return eachRoleInfo?.userRoleName || null;
  });
};

export const roleMapperToPage = (eachRole) => {
  if (eachRole === 'SP' || eachRole === 'SA' || eachRole === ' CC') {
    return 'CC';
  }

  if (eachRole === 'SAM' || eachRole === 'AM') {
    return 'AM';
  }

  return eachRole;
};
