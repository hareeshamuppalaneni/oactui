import React from 'react';
import { Button } from 'react-bootstrap';

export default ({ onClick, text, style = { background: "#005ea2" }, className, variant = "primary", children }) => {
    return (
        <Button className={className} variant={variant} onClick={onClick} style={style} disabled={false}>
           {text}
           {children}
        </Button>
    )

}