import React from 'react';
// import Form from 'react-bootstrap/Form';
// import InputGroup from 'react-bootstrap/InputGroup';
import { TextInput } from '@trussworks/react-uswds';

const TextBox = (props) => {
    return (
        <TextInput id="input-type-text" name="input-type-text" type="text" style={{ minWidth: '220px', marginTop: '1.5em' }} {...props} />
    )
};

export default TextBox;