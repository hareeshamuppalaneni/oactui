import React, { useState } from "react";
import { Table, TextInput, Icon, Checkbox } from "@trussworks/react-uswds";
import "./TableWithFilter.css";
import { useEffect } from "react";
import { FileInput } from "@trussworks/react-uswds";
import RenderFileUpload from "containers/CreateCycle/FileUpload";
let sortIndex;

function TableFilter({
  tableHead,
  tableData,
  onSearchFilter,
  sortData,
  ActionElement,
  DocumentElement,
  setSelectValues,
  selectedData,
}) {
  const SortArrow = Icon.SortArrow;
  const upWard = Icon.ArrowUpward;

  return (
    <Table bordered={false} compact id="table-filter-container" scrollable>
      <thead className="table-filter-head-container">
        <tr>
          <th>
            <Checkbox
              onChange={(event) => {
                setSelectValues([]);
              }}
              id="all"
              name="all"
            />
          </th>
          {tableHead.map((eachHead, index) => {
            return (
              <th className="table-filter-head-container-col" key={index}>
                {eachHead}
                <SortArrow
                  onClick={() => onSearchFilter("sort", index)}
                ></SortArrow>
              </th>
            );
          })}
        </tr>
      </thead>
      <tbody>
        <tr>
          <td></td>
          {tableHead.map((eachHead, index1) => {
            if (eachHead === "Action") {
              return <td key={index1}></td>;
            } else if (eachHead === "Documents (ADD)") {
              return <td key={index1}></td>;
            } else if (eachHead === "Upload") {
              return <td></td>;
            } else {
              return (
                <td key={index1}>
                  <TextInput
                    onChange={(event) =>
                      onSearchFilter(event.target.value, index1)
                    }
                  />
                </td>
              );
            }
          })}
        </tr>

        {tableData &&
          tableData.length > 0 &&
          tableData.map((eachRow, rowIndex) => {
            const formattedArray = [...Object.values(eachRow)];
            return (
              <tr key={rowIndex}>
                <td>
                  <Checkbox
                    id={rowIndex}
                    name={rowIndex}
                    onChange={(event) => {
                      setSelectValues(rowIndex);
                    }}
                    checked={selectedData[rowIndex] || false}
                  />
                </td>
                {formattedArray.map((eachData, dataIndex) => {
                  // To Display Actions Elements
                  if (tableHead[dataIndex] === "Action") {
                    return <ActionElement key={dataIndex} data={eachRow} />;
                  }
                  if (tableHead[dataIndex] === "Upload") {
                    return (
                      <div
                        style={{
                          width: "250px",
                          marginTop: "-10px",
                          marginLeft: "-10px",
                          position: "relative",
                        }}
                      >




                        <RenderFileUpload
                          currentIndex={rowIndex}
                        ></RenderFileUpload>






                      </div>
                    );
                  }

                  if (tableHead[dataIndex] === "Documents (ADD)") {
                    return <DocumentElement key={dataIndex} />;
                  }
                  return (
                    <td>
                      <div
                        className="table-filter-body-container-data-text"
                        key={dataIndex}
                      >
                        {eachData}
                      </div>
                    </td>
                  );
                })}
              </tr>
            );
          })}
      </tbody>
    </Table>
  );
}

export default TableFilter;
