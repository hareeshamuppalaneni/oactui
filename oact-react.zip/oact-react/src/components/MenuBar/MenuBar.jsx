import React, { useState } from "react";
import { NavMenuButton } from "@trussworks/react-uswds";
import { Header } from "@trussworks/react-uswds";
import { Search } from "@trussworks/react-uswds";

export default function MenuBar() {
  const [expanded, setExpanded] = useState(false);

  const [isOpen, setIsOpen] = useState([false]);

  const onClick = () => setExpanded((prvExpanded) => !prvExpanded);

  return (
    <>
      <div className="navMenu">
        <div className={`usa-overlay ${expanded ? "is-visible" : ""}`}></div>
        <Header extended={true}>
          <div className="usa-navbar">
            <NavMenuButton onClick={onClick} label="Menu" />
          </div>


            <div className="grid-row">
              <div className="grid-col-6">
                <div>
                  <h1 className="search-tagline">
                    Occupational Safety and Health Administration.
                  </h1>
                </div>
              </div>
              <div className="grid-col-6">
              </div>
            </div>


          <div className="nav-link-div">
            <div className="grid-container nav-item-div">
              <a href="/oact/" key="three" className="usa-nav__link">
                {/* <span>Home</span> */}
              </a>
              {/* <a
                href="/oact/federal/certificationcoordinator"
                key="three"
                className="usa-nav__link"
              >
                <span>Certification Coordinator</span>
              </a> */}
              {/* <a href="/" key="three" className="usa-nav__link">
                <span>System Owner</span>
              </a>
              <a href="/federal/UploadUserData" key="three" className="usa-nav__link">
                <span>Upload User Data</span>
              </a> */}
            </div>
          </div>
        </Header>
      </div>
    </>
  );
}
