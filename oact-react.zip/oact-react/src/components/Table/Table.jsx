// import React, { useState, useEffect } from "react";
// import BootstrapTable from "react-bootstrap-table-next";
// import { Button } from "@trussworks/react-uswds";
// import classes from "./Table.module.css";
// import {
//   Pen,
//   BookmarkPlus,
//   Bell,
//   Upload,
//   Check,
//   EnvelopeExclamationFill,
//   Exclamation,
//   Flag,
//   FiletypeXlsx,
//   CloudSun,
// } from "react-bootstrap-icons";
// import paginationFactory from "react-bootstrap-table2-paginator";
// import filterFactory, {
//   selectFilter,
//   textFilter,
// } from "react-bootstrap-table2-filter";
// const formatTask = (cell, row) => {
//   console.log(cell);
//   let val = selectOptionsCurrenTTask.filter((e) => e.value === cell);
//   let cellValue = val != undefined ? val[0].label : "";

//   let cellTag =
//     cellValue == "Completed" ? (
//       <a style={{ color: "blue" }}>Completed</a>
//     ) : cellValue == "Scheduled" ? (
//       <>
//         <Check />
//         Scheduled
//       </>
//     ) : (
//       ""
//     );
//   return cellTag == "" ? cell : cellTag;
// };
// const formatDueDays = (cell, row) => {
//   let cellTag =
//     cell >= 50 ? (
//       <>
//         <a style={{ color: "red" }}>
//           {" "}
//           <Exclamation />
//           {cell} days overdue
//         </a>
//       </>
//     ) : cell >= 20 && cell < 50 ? (
//       <>
//         <a style={{ color: "orange" }}>
//           {" "}
//           <Flag />
//           {cell} days overdue
//         </a>
//       </>
//     ) : (
//       <>
//         {" "}
//         <a style={{ color: "orange" }}>
//           {" "}
//           <Bell />
//           {cell} days overdue
//         </a>
//       </>
//     );
//   return cellTag == "" ? cell : cellTag;
// };
// const selectOptions = [
//   {
//     value: "DOL",
//     label: "DOL",
//   },
//   {
//     value: "OSHA",
//     label: "OSHA",
//   },
//   {
//     value: "MSHA",
//     label: "MSHA",
//   },
// ];
// const selectOptionsOffice = [
//   {
//     value: "OAS",
//     label: "OAS",
//   },
//   {
//     value: "OOC",
//     label: "OOC",
//   },
//   {
//     value: "OIS",
//     label: "OIS",
//   },
//   {
//     value: "DAP",
//     label: "DAP",
//   },
//   {
//     value: "DCSP",
//     label: "DCSP",
//   },
//   {
//     value: "DOC",
//     label: "DOC",
//   },
//   {
//     value: "OAS",
//     label: "OAS",
//   },
//   {
//     value: "DSG",
//     label: "DSG",
//   },
//   {
//     value: "DTSEM",
//     label: "DTSEM",
//   },
// ];
// const selectOptionsSystem = [
//   {
//     value: "ITA",
//     label: "ITA",
//   },
//   {
//     value: "DTSEM GSS",
//     label: "DTSEM GSS",
//   },
//   {
//     value: "OIS 2.0",
//     label: "OIS 2.0",
//   },
//   {
//     value: "OTIS",
//     label: "OTIS",
//   },
// ];
// const selectOptionsApplication = [
//   {
//     value: "MAO",
//     label: "MAO",
//   },
//   {
//     value: "DTE Admin",
//     label: "DTE Admin",
//   },
//   {
//     value: "eCorrespondence Administration",
//     label: "eCorrespondence Administration",
//   },
//   {
//     value: "Extranet Administration",
//     label: "Extranet Administration",
//   },
//   {
//     value: "FinTrack",
//     label: "FinTrack",
//   },
//   {
//     value: "Injury Tracking Application",
//     label: "Injury Tracking Application",
//   },
//   {
//     value: "Maritime Crane",
//     label: "Maritime Crane",
//   },
//   {
//     value: "O-ACT",
//     label: "O-ACT",
//   },
//   {
//     value: "OIS",
//     label: "OIS",
//   },
//   {
//     value: "OSHAPedia",
//     label: "OSHAPedia",
//   },
//   {
//     value: "SitePro",
//     label: "SitePro",
//   },
//   {
//     value: "TESA",
//     label: "TESA",
//   },
// ];
// const selectOptionsCurrenTTask = [
//   {
//     value: "Completed",
//     label: "Completed",
//   },
//   {
//     value: "Scheduled",
//     label: "Scheduled",
//   },
//   {
//     value: "w/Account Manager",
//     label: "w/Account Manager",
//   },
//   {
//     value: "w/Sub-Account Manager",
//     label: "w/Sub-Account Manager",
//   },
//   {
//     value: "w/System Owner",
//     label: "w/System Owner",
//   },
// ];

// // Array options
// // const selectOptionsArr = [
// //   {
// //     value: 0,
// //     label: "DOL",
// //   },
// //   {
// //     value: 1,
// //     label: "MSHA",
// //   },
// //   {
// //     value: 2,
// //     label: "OSHA",
// //   },
// // ];

// const columns = [
//   {
//     dataField: "id",
//     text: "Agency",
//     formatter: (cell) =>
//       selectOptions.filter((opt) => opt.value === cell)[0] != undefined
//         ? selectOptions.filter((opt) => opt.value === cell)[0].label
//         : "",
//     filter: selectFilter({
//       options: selectOptions,
//       getFilter: (filter) => {},
//     }),
//   },
//   {
//     dataField: "name",
//     text: "Office",
//     formatter: (cell) =>
//       selectOptionsOffice.filter((opt) => opt.value === cell)[0] != undefined
//         ? selectOptionsOffice.filter((opt) => opt.value === cell)[0].label
//         : "",
//     filter: selectFilter({
//       options: selectOptionsOffice,
//       getFilter: (filter) => {},
//     }),
//   },
//   {
//     dataField: "cycle",
//     text: "Cycle",
//     sort: true,
//     filter: textFilter({
//       placeholder: "Cycle",
//     }),
//   },
//   {
//     dataField: "system",
//     text: "System",
//     formatter: (cell) =>
//       selectOptionsSystem.filter((opt) => opt.value === cell)[0] != undefined
//         ? selectOptionsSystem.filter((opt) => opt.value === cell)[0].label
//         : "",
//     filter: selectFilter({
//       options: selectOptionsSystem,
//       getFilter: (filter) => {},
//     }),
//   },
//   {
//     dataField: "application",
//     text: "Application",
//     formatter: (cell) =>
//       selectOptionsApplication.filter((opt) => opt.value === cell)[0] !=
//       undefined
//         ? selectOptionsApplication.filter((opt) => opt.value === cell)[0].label
//         : "",
//     filter: selectFilter({
//       options: selectOptionsApplication,
//       getFilter: (filter) => {},
//     }),
//   },
//   {
//     dataField: "system_Owner",
//     text: "System Owner",
//     sort: true,
//     filter: textFilter({
//       placeholder: "System Owner",
//     }),
//   },
//   {
//     dataField: "Coordinator",
//     text: "Coordinator",
//     sort: true,
//     filter: textFilter({
//       placeholder: "placeholder",
//     }),
//   },
//   {
//     dataField: "account_Manager",
//     text: "Account Manager",
//     sort: true,
//     filter: textFilter({
//       placeholder: "Account Manager",
//     }),
//   },
//   {
//     dataField: "sub_account_Managers",
//     text: "Sub Account Managers",
//     sort: true,
//     filter: textFilter({
//       placeholder: "Sub Account Managers",
//     }),
//   },
//   {
//     dataField: "start_Date",
//     text: "Start Date",
//     sort: true,
//     filter: textFilter({ placeholder: "MM/DD/YYYY" }),
//   },
//   {
//     dataField: "due_Date",
//     text: "Due Date",
//     sort: true,
//     filter: textFilter({
//       placeholder: "MM/DD/YYYY",
//     }),
//   },
//   {
//     dataField: "days_due",
//     text: "Days till Due",
//     sort: true,
//     formatter: formatDueDays,
//     filter: textFilter({
//       placeholder: "#",
//     }),
//   },
//   {
//     dataField: "current_task",
//     text: "Current Task",
//     sort: true,
//     formatter: formatTask,
//     filter: selectFilter({
//       options: selectOptionsCurrenTTask,
//       getFilter: (filter) => {},
//     }),
//   },
//   { dataField: "action", text: "Action" },
// ];

// const products = [
//   {
//     id: "OSHA",
//     name: "OAS",
//     cycle: "Hero",
//     system: "ITA",
//     application: "MAO",
//     system_Owner: "Chris Mace",
//     Coordinator: "Cheryl Younger",
//     account_Manager: "Franz Probst",
//     sub_account_Managers: 3,
//     start_Date: "11 / 10 / 2021",
//     due_Date: "12 / 03 / 2021",
//     current_task: "Completed",
//     days_due: 54,
//     action: (
//       <button
//         onClick={() => {
//           console.log("refresh");
//         }}
//       >
//         refresh
//       </button>
//     ),
//   },
//   {
//     id: "OSHA",
//     name: "OAS",
//     cycle: "villian",
//     system: "ITA",
//     application: "MAO",
//     system_Owner: "Max Andrews",
//     Coordinator: "Cheryl Younger",
//     account_Manager: "Deidre Williams",
//     sub_account_Managers: 6,
//     start_Date: "05 / 20 / 2022",
//     due_Date: "06 / 30 / 2022",
//     current_task: "w/Account Manager",
//     days_due: 24,
//     action: (
//       <button
//         onClick={() => {
//           console.log("add");
//         }}
//       >
//         add
//       </button>
//     ),
//   },
//   {
//     id: "OSHA",
//     name: "OAS",
//     cycle: "villian",
//     system: "ITA",
//     application: "MAO",
//     system_Owner: "Max Andrews",
//     Coordinator: "Kristi Dearing	",
//     account_Manager: "Nancy Szeto",
//     sub_account_Managers: 50,
//     start_Date: "8 / 01 / 2022",
//     due_Date: "09 / 13 / 2022",
//     current_task: "w/Account Manager",
//     days_due: 7,
//     action: (
//       <button
//         onClick={() => {
//           console.log("add");
//         }}
//       >
//         add
//       </button>
//     ),
//   },
//   {
//     id: "DOL",
//     name: "OAS",
//     cycle: "villian",
//     system: "ITA",
//     application: "MAO",
//     system_Owner: "Chris Mace	",
//     current_task: "Scheduled",
//     Coordinator: "Kristi Dearing",
//     account_Manager: "Kristi Dearing",
//     sub_account_Managers: 0,
//     start_Date: "10 / 01 / 2022",
//     due_Date: "10 / 31 / 2022",
//     days_due: 54,
//     action: (
//       <button
//         onClick={() => {
//           console.log("add");
//         }}
//       >
//         add
//       </button>
//     ),
//   },
// ];

// export default function Table(data) {
//   // const customTotal = (from, to, size) => (
//   //   {data.length>0 && (<span className="react-bootstrap-table-pagination-total">
//   //     Showing {from} to {to} of {size} Results
//   //   </span>)}
//   // );
//   const options = {
//     paginationSize: 4,
//     pageStartIndex: 0,
//     // alwaysShowAllBtns: true, // Always show next and previous button
//     // withFirstAndLast: false, // Hide the going to First and Last page button
//     // hideSizePerPage: true, // Hide the sizePerPage dropdown always
//     // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
//     firstPageText: "First",
//     prePageText: "Back",
//     nextPageText: "Next",
//     lastPageText: "Last",
//     nextPageTitle: "First page",
//     prePageTitle: "Pre page",
//     firstPageTitle: "Next page",
//     lastPageTitle: "Last page",
//     showTotal: true,
//     // paginationTotalRenderer: customTotal,
//     disablePageTitle: true,
//     sizePerPageList: [
//       {
//         text: "10",
//         value: 10,
//       },
//       {
//         text: "20",
//         value: 20,
//       },
//       {
//         text: "50",
//         value: 50,
//       },
//       {
//         text: "100",
//         value: 100,
//       },
//     ], // A numeric array is also available. the purpose of above example is custom the text
//   };
//   return (
//     <BootstrapTable
//       keyField="id"
//       data={data}
//       columns={columns}
//       selectRow={{ mode: "checkbox" }}
//       tabIndexCell
//       filter={filterFactory()}
//       headerClasses={classes.header}
//       condensed
//       pagination={paginationFactory(options)}
//       noDataIndication={"no results found"}
//     />
//   );
// }
// // products.map((e) => {
// //   let color =
// //     e.current_task == "Scheduled"
// //       ? "blue"
// //       : e.days_due >= 50
// //       ? "red"
// //       : e.days_due >= 20 && e.days_due < 50
// //       ? "orange"
// //       : "#FFD580";
// //   if (e.current_task == "Completed") {
// //     e.action = (
// //       <div style={{ justifyContent: "space-between" }}>
// //         <a style={{ color: "green" }}>Submitted</a>
// //         <br />
// //         <br />
// //         <button
// //           style={{
// //             alignItems: "center",
// //             justifyContent: "center",

// //             borderRadius: "10px",
// //           }}
// //           onClick={() => {
// //             console.log("add");
// //           }}
// //         >
// //           <CloudSun /> Certificate
// //         </button>

// //         <br />
// //         <br />
// //         <button
// //           style={{ borderRadius: "10px" }}
// //           onClick={() => {
// //             console.log("add");
// //           }}
// //         >
// //           <FiletypeXlsx /> XLSX
// //         </button>
// //       </div>
// //     );
// //   } else {
// //     e.action = (
// //       <div>
// //         <Button
// //           style={{
// //             backgroundColor: "blue",
// //             color: "white",
// //             borderRadius: "10px",
// //             fontSize: "13px",
// //             fontWeight: 400,
// //           }}
// //           onClick={() => {
// //             console.log("add");
// //           }}
// //         >
// //           <span>
// //             {" "}
// //             <Pen /> Edit Cycle
// //           </span>
// //         </Button>
// //         <br />
// //         <br />
// //         <Button
// //           style={{
// //             backgroundColor: "#61DBFB",
// //             color: "white",
// //             borderRadius: "10px",
// //             borderRadius: "10px",
// //             fontSize: "13px",
// //             fontWeight: 400,
// //           }}
// //           onClick={() => {
// //             console.log("add");
// //           }}
// //         >
// //           <BookmarkPlus /> Add Manager
// //         </Button>
// //         <br />
// //         <br />
// //         <Button
// //           style={{
// //             backgroundColor: color,
// //             color: "white",
// //             borderRadius: "10px",
// //             borderRadius: "10px",
// //             fontSize: "13px",
// //             fontWeight: 400,
// //           }}
// //           onClick={() => {
// //             console.log("add");
// //           }}
// //         >
// //           <Bell />
// //           Send Reminder
// //         </Button>

// //         {e.current_task == "Scheduled" ? (
// //           <>
// //             {" "}
// //             <br />
// //             <br />
// //             <Button
// //               style={{
// //                 backgroundColor: "green",
// //                 color: "white",
// //                 borderRadius: "10px",
// //                 borderRadius: "10px",
// //                 fontSize: "13px",
// //                 fontWeight: 400,
// //               }}
// //               onClick={() => {
// //                 console.log("add");
// //               }}
// //             >
// //               <Upload />
// //               Upload Data
// //             </Button>
// //           </>
// //         ) : null}

// //         {e.days_due <= 7 ? (
// //           <>
// //             {" "}
// //             <br />
// //             <br />
// //             <button
// //               style={{
// //                 borderRadius: "10px",
// //                 borderRadius: "10px",
// //                 fontSize: "13px",
// //                 fontWeight: 400,
// //               }}
// //               onClick={() => {
// //                 console.log("add");
// //               }}
// //             >
// //               <FiletypeXlsx /> XLSX
// //             </button>
// //           </>
// //         ) : null}
// //       </div>
// //     );
// //   }
// //   return e;
// // })
