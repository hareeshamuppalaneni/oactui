import React, { useState } from "react";
import { Dropdown, Radio } from '@trussworks/react-uswds'
// import BootstrapSelect from 'react-bootstrap-select-dropdown';
// import DropdownMultiselect from "react-multiselect-dropdown-bootstrap";
// import Mutliselect from 'react-bootstrap-multiselect';

const options = [
    {
        "labelKey": "optionItem1",
        "value": "Option item 1"
    },
    {
        "labelKey": "optionItem2",
        "value": "Option item 2"
    }
]
// import Multiselect from 'react-bootstrap-multiselect';
// import './MultiSelect.css';
// import { Col, Form } from "react-bootstrap";
// import { Checkbox } from "@trussworks/react-uswds";
// import '@trussworks/react-uswds/lib/uswds.css'

// export default function MutliSelect({ defaultText = 'Select', menuItems = [], style = {}, onSelect, className = "usa-form", selectClassName = "usa-select" }) {
//   const [field, setField] = useState([]);

//   return (
//     // <Form.Group as={Col} controlId="my_multiselect_field">
//     //   <Form.Label>My multiselect</Form.Label>
//     //   <Form.Control as="select" multiple value={field} onChange={e => setField([].slice.call(e.target.selectedOptions).map(item => item.value))}>
//     //     <option value="field1">Field 1</option>
//     //     <option value="field2">Field 2</option>
//     //     <option value="field3">Field 3</option>
//     //   </Form.Control>
//     // </Form.Group>
//         <form style={{ minWidth: '200px', ...style }} onChange={onSelect} className={className}>
//         <select className={selectClassName} name="options" id="options">
//             {/* <Checkbox id="checkbox" name="checkbox" label="My Checkbox" tile><option value>{defaultText}</option></Checkbox> */}

//         <option value>{defaultText}</option>
//         {menuItems.map((eachItem, index) => {
//             return <option value={eachItem}>
//                 <Checkbox id="checkbox" name="checkbox" label="My Checkbox" tile />
//                 </option> 
//             // return 
//             // return (<option key={index} value={eachItem}>{eachItem}</option>)
//           })}
//     </select>
//      </form> 
//   );
// };

const MultiSelect = ({ style, handleChange }) => {
    return (
        <>
            {/* <Dropdown id="input-dropdown" name="input-dropdown" style={{ minWidth: '200px' }}>
                <option>
                    <Radio
                        id="input-radio"
                        name="input-radio"
                        label="My Radio Button"
                        defaultChecked
                    />
                </option>

                <option>- Select - </option>
                <option value="value1">Option A</option>
                <option value="value2">Option B</option>
                <option value="value3">Option C</option>
            </Dropdown> */}
            {/* <DropdownMultiselect
                options={["Australia", "Canada", "USA", "Poland", "Spain", "France"]}
                name="countries"
            /> */}
            {/* <Mutliselect data={[{value:'One',selected:true},{value:'Two'}]} multiple /> */}
            <BootstrapSelect options={options} onChange={handleChange} isMultiSelect showTick/>

            {/* <select id="example-getting-started"  className="selectpicker" multiple>
    <option value="cheese">Cheese</option>
    <option value="tomatoes">Tomatoes</option>
    <option value="mozarella">Mozzarella</option>
    <option value="mushrooms">Mushrooms</option>
    <option value="pepperoni">Pepperoni</option>
    <option value="onions">Onions</option>
</select> */}


        </>

    );
};

export default MultiSelect;