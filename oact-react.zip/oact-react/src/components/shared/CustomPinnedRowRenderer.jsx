import React, { Component } from 'react';

export default function CustomPinnedRowRenderer (params) {
  return (
    <a
      onClick={() => { 
        if (params.showModal) {
          params.showModal(params);
        }
      }} 
      style={params.style}
    >
      {params.value}
    </a>
  );
}