
// Images
import DOL_LOGO from './images/DOL-MasterLogo_BLUE.png';
import OCAT_LOGO from './images/oact-logo.jpeg';
import MAIN_OACT_LOGO from './images/OACT_logo.png'

// Files
import USER_DATA_EXCEL_FILE from './files/userdata.xlsx'

export const IMAGES = {
    DOL_LOGO,
    OCAT_LOGO,
    MAIN_OACT_LOGO
};

export const FILES = {
    USER_DATA_EXCEL_FILE
}