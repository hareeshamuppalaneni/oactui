export const CERTIFICATE_COORDINATOR_TEXTS = {
    REVIEW_CYCLE: 'Certification Coordinator',
    CREATE_CYCLE: 'Create Review Cycle'
};

