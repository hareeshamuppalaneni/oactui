export const ACCOUNT_MANAGER_LABELS = Object.freeze({
  MAIN_HEADER: 'Account Manager',
  DROPDOWN_LABEL: 'Available applications to attest',
  NO_OPTION_FOR_DROPDOWN: 'No Application Available to attest',
  BUTTON_TEXT: 'Sign Attestation Certificate',
  BULK_CERTIFY: 'Bulk Certify',
  BULK_EDIT: 'Bulk Edit',
  CUSTOMIZE_COLS: 'Customize Columns'
});



export const ACCOUNT_MANAGER_EDIT_LABELS = Object.freeze({
  MAIN_HEADER: 'Edit Users',
  ALERT_HEADER: 'Edit Review Status',
  ALERT_MSG: 'Set review status of the selected users, You can optionally add components',
  DROPDOWN_LABEL: '*Review Result',
  COMMENTS: 'Comments',
  SELECT_STATUS_LABEL: 'Select Status'
});

export const ACCOUNT_MANAGER_ALERT_ACTIONS = Object.freeze({
  ATTESTATION: 'ATTESTATION',
  BULK_EDIT: 'BULK_EDIT',
  BULK_CERTIFY: 'BULK_CERTIFY'
});

export const ACCOUNT_MANAGER_SUCCESS_LABELS = Object.freeze({
  [ACCOUNT_MANAGER_ALERT_ACTIONS.ATTESTATION]: Object.freeze({
    HEADING: 'Attestation Completed',
    TEXT: 'Successfully Attestation Process Completed for: '
  }),
  [ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_EDIT]: Object.freeze({
    HEADING: 'Edit Completed',
    TEXT: 'Successfully Edited users with review status'
  }),
  [ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_CERTIFY]: Object.freeze({
    HEADING: 'Notifying Completed',
    TEXT: 'Successfully Certified '
  })
});

export const ACCOUNT_MANAGER_MODAL_LABELS = Object.freeze({
    [ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_EDIT]: Object.freeze({
      MAIN_HEADER: 'Edit Users',
      ALERT_HEADER: 'Edit Review Status',
      ALERT_MSG: `Certify users by selecting a "Review Result" and explain the selection.`,
      DROPDOWN_LABEL: 'Review Result',
      COMMENTS: 'Comments',
      SELECT_STATUS_LABEL: 'Select Status',
      BUTTON_SAVE_LABEL: 'Update Review Status',
      BUTTON_CANCEL: 'Cancel'
    }),
    [ACCOUNT_MANAGER_ALERT_ACTIONS.BULK_CERTIFY]: Object.freeze({
      MAIN_HEADER: 'Certify',
      ALERT_HEADER: 'Certify Application',
      ALERT_MSG: 'Application with be Certified',
      BUTTON_SAVE_LABEL: 'Certify Application',
      BUTTON_CANCEL: 'Cancel'
      // DROPDOWN_LABEL: 'Set review status for selected users to',
      // COMMENTS: 'Comments',
      // SELECT_STATUS_LABEL: 'Select Status'
    })
  });
