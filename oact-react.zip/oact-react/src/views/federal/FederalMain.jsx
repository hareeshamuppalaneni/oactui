
import React, { useCallback, useMemo, useRef, useState } from 'react';
import '@trussworks/react-uswds/lib/uswds.css'
import "@fontsource/merriweather";
import './federal.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faDownload } from '@fortawesome/free-solid-svg-icons'
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import CustomPinnedRowRenderer from '../../components/shared/CustomPinnedRowRenderer';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

const createData = (count, prefix) => {
  var result = [];

  for (var i = 0; i < count; i++) {
    result.push({
      athlete: prefix + ' Athlete ' + i,
      age: prefix + ' Age ' + i,
      country: prefix + ' Country ' + i,
      year: prefix + ' Year ' + i,
      date: prefix + ' Date ' + i,
      sport: prefix + ' Sport ' + i,
    });
  }
  return result;
};

export default function FederalMain() {
  const gridRef = useRef();

  const gridStyle = useMemo(() => ({ height: '100%', width: '100%' }), []);

  const [
    rowData,
    setRowData
  ] = useState();

  const [
    show,
    setShow
  ] = useState(false);

  const handleClose = () => setShow(false);

  const showModal = (data) => {
    console.log(data);
    setShow(true);
  };

  const [columnDefs, setColumnDefs] = useState([
    {
      field: 'athlete',
      cellRendererSelector: (params) => {
        return {
          component: CustomPinnedRowRenderer,
          params: {
            style: { color: 'blue' },
            showModal: (data) => showModal(data)
          },
        };
      },
    },
    {
      field: 'age',
      cellRendererSelector: (params) => {
        if (params.node.rowPinned) {
          return {
            component: CustomPinnedRowRenderer,
            params: {
              style: { 'font-style': 'italic' },
            },
          };
        } else {
          return undefined;
        }
      },
    },
    { field: 'country' },
    { field: 'year' },
    { field: 'date' },
    { field: 'sport' },
  ]);

  const defaultColDef = useMemo(() => {
    return {
      flex: 1,
      sortable: true,
      filter: true,
      resizable: true,
    };
  }, []);

  const getRowStyle = useCallback((params) => {
    if (params.node.rowPinned) {
      return { 'font-weight': 'bold' };
    }
  }, []);

  const pinnedTopRowData = useMemo(() => {
    return createData(1, 'Top');
  }, []);

  const pinnedBottomRowData = useMemo(() => {
    return createData(1, 'Bottom');
  }, []);

  const onGridReady = useCallback((params) => {
    fetch('https://www.ag-grid.com/example-assets/olympic-winners.json')
      .then((resp) => resp.json())
      .then((data) => setRowData(data));
  }, []);

  const onPinnedRowTopCount = useCallback(() => {
    var headerRowsToFloat = document.getElementById('top-row-count').value;
    var count = Number(headerRowsToFloat);
    var rows = createData(count, 'Top');
    gridRef.current.api.setPinnedTopRowData(rows);
  }, []);

  const onPinnedRowBottomCount = useCallback(() => {
    var footerRowsToFloat = document.getElementById('bottom-row-count').value;
    var count = Number(footerRowsToFloat);
    var rows = createData(count, 'Bottom');
    gridRef.current.api.setPinnedBottomRowData(rows);
  }, []);

  const onBtnExport = useCallback(() => {
    gridRef.current.api.exportDataAsCsv();
  }, []);

  const applyPageSizeSetByUser = useCallback((params) => {
    var value = document.getElementById('page-size').value;
    gridRef.current.api.paginationSetPageSize(Number(value));
  }, []);

  return (
    <div className="App ag-grid-container usa-banner__inner">
      <div>
        <button
          onClick={onBtnExport}
          className="btn btn-light"
          style={{ margin: "0 0 10px 10px" }}
        >
          <FontAwesomeIcon icon={faDownload} />
          &nbsp;
          <span>Download as CSV</span>
        </button>
      </div>
      <div style={gridStyle} className="ag-theme-alpine">
        <AgGridReact
          ref={gridRef}
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          getRowStyle={getRowStyle}
          onGridReady={onGridReady}
          onFirstDataRendered={applyPageSizeSetByUser}
        ></AgGridReact>
      </div>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>Woohoo, you're reading this text in a modal!</Modal.Body>
        <Modal.Footer>
          <Button variant="link" onClick={handleClose} style={{ color: "#005ea2", textDecorationLine: 'none' }}>
            <span>Close</span>
          </Button>
          <Button variant="primary" onClick={handleClose} style={{ background: "#005ea2" }}>
            <span>Save Changes</span>
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
