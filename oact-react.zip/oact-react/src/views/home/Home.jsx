import '@trussworks/react-uswds/lib/uswds.css';
import '@fontsource/merriweather';
import { Alert, Button } from '@trussworks/react-uswds';
import { Table } from '../../components';
import './home.css';
import { useEffect, useState } from 'react';
import CONFIGS from 'configs';
import Cookies from 'js-cookie';
import { useDispatch, useSelector } from 'react-redux';

import { fetchUserDetail, setLocalUser } from 'slices';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { IMAGES } from 'assets';

/***
 * For Local Development
 */
import { Button as LocalButton } from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import configs from 'configs';
import { USER_ROLES } from 'labels';

export default function Home() {
  let navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  /***
   * For Local Development
   */
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  // const wholeStore = useSelector((state) => state);

  const userDetails = useSelector((state) => state.userDetail);

  const dispatch = useDispatch();

  /***
   * For Local Development
   */
  const onClickLocalModal = () => {
    dispatch(fetchUserDetail(userDetails.localUser));
    // var inFifteenMinutes = new Date(new Date().getTime() + 15 * 60 * 1000);
    Cookies.set('localUser', userDetails.localUser, {
      expires: 1 / 48 // Half an Hour Expiry Refs: https://github.com/js-cookie/js-cookie/wiki/Frequently-Asked-Questions#expire-cookies-in-less-than-a-day
    });
    const emailThroughCookie = Cookies.get('localUser');
    handleClose();
    const userDetail = {
      ...userDetails,
      localUser: userDetails.localUser
    };
    navigate(configs.ROUTES.NAVIGATOR, { state: { userDetail } });
  };

  const onClickLoginModule = () => {
    const checkParamExist = searchParams.get('byPass');
    const lowerEnv =
      process.env.REACT_APP_ENVIRONMENT === 'LOCAL' || process.env.REACT_APP_ENVIRONMENT === 'DEV';
    if (process.env.REACT_APP_ENVIRONMENT === 'DEV' && checkParamExist) {
      handleShow();
    } else if (process.env.REACT_APP_ENVIRONMENT === 'LOCAL') {
      handleShow();
    } else {
      const userDetail = {
        localUser: userDetails.localUser
      };
      // Whatever we need to do, if we want to invoke the LoginAUthModule and SSO
      // navigate('/auth/ping/login', { state: { userDetail } });
      // window.location = '/auth/ping/login';
      window.location = '/auth/ping/login';
    }
    // if (CONFIGS.CURRENT_ENV === 'LOCAL' || checkParamExist) {
    //   handleShow();
    // } else {
    //   const userDetail = {
    //     localUser: userDetails.localUser
    //   };
    //   // Whatever we need to do, if we want to invoke the LoginAUthModule and SSO
    //   // navigate('/auth/ping/login', { state: { userDetail } });
    //   // window.location = '/auth/ping/login';
    //   window.location = '/auth/ping/login';
    // }
  };

  useEffect(() => {
    const emailThroughCookie = Cookies.get('appcookie');
    console.log('App Cookie => ', emailThroughCookie);
    const emailThroughQuery = searchParams.get('email');
    const checkIfAnyUserExist = emailThroughQuery || emailThroughCookie;

    // var inFifteenMinutes = new Date(new Date().getTime() + 15 * 60 * 1000);
    Cookies.set('localUser', checkIfAnyUserExist, {
      expires: 1 / 48 // Half an Hour Expiry Refs: https://github.com/js-cookie/js-cookie/wiki/Frequently-Asked-Questions#expire-cookies-in-less-than-a-day
    });
    if (checkIfAnyUserExist) {
      dispatch(fetchUserDetail(checkIfAnyUserExist));
      const userDetail = {
        ...userDetails,
        localUser: checkIfAnyUserExist
      };
      navigate(configs.ROUTES.NAVIGATOR, { state: { userDetail } });
    }
  }, [userDetails]);

  return (
    <div className="App">
      <header className="App-header"></header>
      <div className="grid-container">
      <div className="grid-row row">
      <div className="grid-col-5 left-section col-md-5">
      <h3 className="sub-header-text-container">OSHA Account Certification Tool</h3>
        </div>
        <div className="grid-col-7 col-md-7 right-section">
     
          <div className='home-oact-logo'><img className="oact__logo-img" alt="img alt text" src={IMAGES.MAIN_OACT_LOGO} /></div>
        </div>
        </div>
        <div className="grid-row row">
          {/* <div className="grid-col-12 page-title">
            <h2>Welcome to OSHA Account Certification Tool (O-ACT)</h2>
          </div> */}
          
          <div className="grid-col-5 left-section col-md-5">
            
            <Button type="primary" className="btn-login" onClick={() => onClickLoginModule()}>
              <span title="Login with SSO">Federal User Login</span>
            </Button>
            {/* <Button type="primary" className="btn-login">
              Non-Federal User Login
            </Button> */}
            <Alert type="warning" headingLevel="h4" slim>
              <strong>Need an account or have questions?</strong>
              <p>
                <span>Email: </span>
                <a
                  href="emailTo: OSHAApplications@dol.gov"
                  title="Email OSHA Applications Team"
                >
                  OSHAApplications@dol.gov
                </a>
              </p>
            </Alert>
          </div>
          <div className="grid-col-7 col-md-7 right-section">
          
            <Alert type="info" headingLevel="h4" slim>
              <p>
                You are about to access a U.S. Government computer/information system. Access to
                this system is restricted to authorized users only. Unauthorized access, use, or
                modification to this computer system or of the data contained herein, or in transit
                to/from this system, may constittute a violation of Title 18, United States Code,
                Section 1030 and other federal or state criminal civil laws. These systems and
                equipment are subject to monitoring to ensure proper performance and applicable
                security features or procedures. Such monitoring may result in the acquisition,
                recording, and analysis of all data being communicated, transmitted, processes, or
                stored in this system by a user.
              </p>
              <p>
                If monitoring reveals possible misuse or criminal activity, notice of such may be
                provided to supervisory personnel and law enforcement officials as evidence.
              </p>
              <p>
                Anyone who accesses a Federal computer system without authorization or exceeds their
                access authority, and by any means of such conduct obtains, alters, damages,
                destroys, or discloses information, or prevents authorized use of information on the
                computer, may be subject to fine or imprisonment or both.
              </p>
              <p>
                Your use of this system indicates understanding that you are personally responsible
                for your use and any misuse of your access including your system account and
                password. Use further indicates understanding that by accessing a U.S. Government
                information system that you must comply with th prescribed policies and procedures.
                Lastly, your use shall serve as acknowledgement of receipt of, your understanding of
                your responsibilities, and your willingness to comply with the rules of behavior for
                this system.
              </p>
            </Alert>
          </div>
          <div>
            <br />
          </div>
        </div>
      </div>
      {/**
       * For Local Testing Only
       */}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>For Local Testing Only</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <InputGroup
            className="mb-3"
            onChange={(event) => {
              dispatch(setLocalUser(event.target.value));
            }}
          >
            <Form.Control
              placeholder="Please enter full email address for testing"
              aria-label="Please enter full email address for testing"
              aria-describedby="basic-addon2"
            />
            <InputGroup.Text id="basic-addon2"></InputGroup.Text>
          </InputGroup>
        </Modal.Body>
        <Modal.Footer>
          <LocalButton variant="secondary" onClick={handleClose}>
            Cancel
          </LocalButton>
          <LocalButton variant="primary" onClick={() => onClickLocalModal()}>
            Save Changes
          </LocalButton>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
