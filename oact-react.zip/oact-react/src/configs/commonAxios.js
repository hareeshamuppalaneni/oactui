import axios from 'axios';
import CONFIGS from 'configs'

export default axios.create({
  baseURL:  process.env.REACT_APP_API_ENDPOINT,
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json"
  },
  // Set Timeout based on API latency
  timeout: 1000000, // Increased for local testing
  // `transformResponse` allows changes to the response data to be made before
  // it is passed to then/catch
  // transformResponse: [function (data) {
  //   // Do whatever you want to transform the data
  //   console.log("Data response =>", data)
  //   return data;
  // }],
});
