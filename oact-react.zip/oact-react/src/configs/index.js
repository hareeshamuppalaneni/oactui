
console.log("process.env.CURRENT_ENV =>", process.env.REACT_APP_ENVIRONMENT);
console.log("process.env.APP_API_ENDPOINT =>", process.env.REACT_APP_API_ENDPOINT);
import ROUTES from './routes';
export default {
    API_BASE_URL: process.env.REACT_APP_API_ENDPOINT,
    CURRENT_ENV: process.env.REACT_APP_ENVIRONMENT,
    ROUTES
};