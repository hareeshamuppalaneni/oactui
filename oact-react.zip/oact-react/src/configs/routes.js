export default {
    HOME:  '/oact/',
    FEDERAL: '/oact/federal',
    FILE_UPLOAD: '/oact/federal/uploaduserdata',
    SUB_ACCOUNT_MANAGER: '/oact/federal/subaccountmanager',
    SYSTEM_ADMIN: '/oact/federal/systemadmin',
    CERTIFICATION_COORDINATOR: '/oact/federal/certificationcoordinator',
    ACCOUNT_MANAGER: '/oact/federal/accountmanager',
    SYSTEM_OWNER: '/oact/federal/systemowner',
    SYSTEM_POC: '/oact/federal/systempoc',
    NAVIGATOR: '/oact/navigator'
}